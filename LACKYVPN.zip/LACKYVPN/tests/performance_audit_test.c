/**
 * LACKYVPN - Performance Audit System Test Suite
 * ==============================================
 * 
 * Comprehensive testing for the Performance Optimization
 * & Security Audit Module of LACKYVPN.
 * 
 * Features:
 * - Performance audit system initialization testing
 * - Metric collection and analysis validation
 * - Security audit functionality testing
 * - Compliance checking verification
 * - Optimization recommendation testing
 * - Report generation validation
 * - Thread safety and concurrency testing
 * 
 * Security Level: CLASSIFIED
 * Built by: Lackadaisical Security
 */

#include "../core/audit/performance_audit.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <assert.h>

#define TEST_ASSERT(condition, message) \
    do { \
        if (!(condition)) { \
            printf("FAIL: %s\n", message); \
            return false; \
        } else { \
            printf("PASS: %s\n", message); \
        } \
    } while(0)

#define TEST_SUITE_START(name) \
    printf("\n=== %s ===\n", name); \
    bool suite_success = true

#define TEST_SUITE_END() \
    printf("Suite result: %s\n", suite_success ? "PASS" : "FAIL"); \
    return suite_success

// Test statistics
static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

// Test helper functions
static bool run_test(const char* test_name, bool(*test_func)(void));
static void print_test_summary(void);
static lackyvpn_audit_config_t create_test_config(void);

// Individual test functions
static bool test_audit_initialization(void);
static bool test_metric_collection(void);
static bool test_performance_monitoring(void);
static bool test_security_audit(void);
static bool test_compliance_checking(void);
static bool test_optimization_recommendations(void);
static bool test_benchmark_execution(void);
static bool test_report_generation(void);
static bool test_thread_safety(void);
static bool test_resource_monitoring(void);
static bool test_statistics_calculation(void);
static bool test_health_status(void);

// Stress testing
static bool test_high_load_performance(void);
static bool test_memory_leak_detection(void);
static bool test_concurrent_access(void);

/**
 * Main test execution
 */
int main(int argc, char* argv[]) {
    printf("LACKYVPN Performance Audit System Test Suite\n");
    printf("=============================================\n");
    printf("Security Level: CLASSIFIED\n");
    printf("Starting comprehensive audit system testing...\n\n");

    time_t start_time = time(NULL);

    // Core functionality tests
    run_test("Audit System Initialization", test_audit_initialization);
    run_test("Metric Collection", test_metric_collection);
    run_test("Performance Monitoring", test_performance_monitoring);
    run_test("Security Audit", test_security_audit);
    run_test("Compliance Checking", test_compliance_checking);
    run_test("Optimization Recommendations", test_optimization_recommendations);
    run_test("Benchmark Execution", test_benchmark_execution);
    run_test("Report Generation", test_report_generation);
    run_test("Thread Safety", test_thread_safety);
    run_test("Resource Monitoring", test_resource_monitoring);
    run_test("Statistics Calculation", test_statistics_calculation);
    run_test("Health Status", test_health_status);

    // Stress tests
    run_test("High Load Performance", test_high_load_performance);
    run_test("Memory Leak Detection", test_memory_leak_detection);
    run_test("Concurrent Access", test_concurrent_access);

    time_t end_time = time(NULL);

    printf("\n");
    print_test_summary();
    printf("Total test execution time: %lld seconds\n", (long long)(end_time - start_time));

    return (g_tests_failed == 0) ? 0 : 1;
}

/**
 * Test audit system initialization and cleanup
 */
static bool test_audit_initialization(void) {
    TEST_SUITE_START("Audit System Initialization");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();

    // Test initialization
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Audit system initialization");
    TEST_ASSERT(ctx.is_initialized, "Context initialization flag set");
    TEST_ASSERT(ctx.initialization_time > 0, "Initialization time recorded");

    // Test invalid parameters
    result = lackyvpn_audit_init(NULL, &config);
    TEST_ASSERT(result != LACKYVPN_AUDIT_SUCCESS, "Null context handling");

    result = lackyvpn_audit_init(&ctx, NULL);
    TEST_ASSERT(result != LACKYVPN_AUDIT_SUCCESS, "Null config handling");

    // Test cleanup
    lackyvpn_audit_cleanup(&ctx);
    TEST_ASSERT(!ctx.is_initialized, "Context cleanup");

    TEST_SUITE_END();
}

/**
 * Test metric collection and management
 */
static bool test_metric_collection(void) {
    TEST_SUITE_START("Metric Collection");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Create test metric
    lackyvpn_performance_metric_t metric = {0};
    metric.type = LACKYVPN_METRIC_CPU_USAGE;
    strcpy(metric.name, "Test CPU Usage");
    strcpy(metric.description, "Test CPU utilization metric");
    metric.value = 45.5;
    metric.threshold = 80.0;

    // Test adding metric
    result = lackyvpn_audit_add_metric(&ctx, &metric);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Metric addition");
    TEST_ASSERT(ctx.metric_count == 1, "Metric count increment");

    // Test updating existing metric
    metric.value = 55.5;
    result = lackyvpn_audit_add_metric(&ctx, &metric);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Metric update");
    TEST_ASSERT(ctx.metric_count == 1, "Metric count unchanged on update");

    // Verify metric statistics
    lackyvpn_performance_metric_t* stored_metric = &ctx.metrics[0];
    TEST_ASSERT(stored_metric->sample_count == 2, "Sample count tracking");
    TEST_ASSERT(stored_metric->min_value == 45.5, "Minimum value tracking");
    TEST_ASSERT(stored_metric->max_value == 55.5, "Maximum value tracking");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test performance monitoring functionality
 */
static bool test_performance_monitoring(void) {
    TEST_SUITE_START("Performance Monitoring");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Test resource usage collection
    lackyvpn_resource_usage_t usage;
    result = lackyvpn_audit_get_resource_usage(&ctx, &usage);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Resource usage collection");
    TEST_ASSERT(usage.measurement_time > 0, "Measurement timestamp");
    TEST_ASSERT(usage.cpu_cores > 0, "CPU core detection");

    // Test performance audit
    result = lackyvpn_audit_performance(&ctx, LACKYVPN_AUDIT_ALL);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Performance audit execution");
    TEST_ASSERT(ctx.total_audits_performed > 0, "Audit counter increment");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test security audit functionality
 */
static bool test_security_audit(void) {
    TEST_SUITE_START("Security Audit");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Test security issue addition
    lackyvpn_security_issue_t issue = {0};
    issue.issue_id = 1;
    strcpy(issue.title, "Test Security Issue");
    strcpy(issue.description, "Test security vulnerability");
    issue.severity = LACKYVPN_SEVERITY_MEDIUM;
    issue.category = LACKYVPN_AUDIT_SECURITY;
    strcpy(issue.affected_component, "Test Component");
    strcpy(issue.recommendation, "Fix the test issue");
    
    // Add the issue to audit context
    result = lackyvpn_audit_add_issue(&ctx, &issue);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Security issue addition");
    TEST_ASSERT(ctx.issue_count == 1, "Issue count increment");

    // Test security audit execution
    result = lackyvpn_audit_security(&ctx, SECURITY_LEVEL_COMPREHENSIVE);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Security audit execution");

    // Test issue resolution
    result = lackyvpn_audit_resolve_issue(&ctx, 1);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Issue resolution");
    TEST_ASSERT(ctx.resolved_issue_count == 1, "Resolved issue counter");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test compliance checking functionality
 */
static bool test_compliance_checking(void) {
    TEST_SUITE_START("Compliance Checking");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Test FIPS compliance check
    result = lackyvpn_audit_fips_compliance(&ctx);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "FIPS compliance check");

    // Test Common Criteria compliance check
    result = lackyvpn_audit_common_criteria_compliance(&ctx);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Common Criteria compliance check");

    // Test generic compliance check
    result = lackyvpn_audit_compliance_check(&ctx, "FIPS 140-2");
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Generic compliance check");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test optimization recommendation system
 */
static bool test_optimization_recommendations(void) {
    TEST_SUITE_START("Optimization Recommendations");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Add a metric that exceeds threshold to trigger recommendations
    lackyvpn_performance_metric_t metric = {0};
    metric.type = LACKYVPN_METRIC_CPU_USAGE;
    strcpy(metric.name, "High CPU Usage");
    metric.value = 95.0;  // Exceeds threshold
    metric.threshold = 80.0;
    
    result = lackyvpn_audit_add_metric(&ctx, &metric);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "High threshold metric addition");

    // Generate recommendations
    result = lackyvpn_audit_generate_recommendations(&ctx);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Recommendation generation");

    // Test optimization application
    result = lackyvpn_audit_apply_optimizations(&ctx, LACKYVPN_OPTIMIZATION_ALL);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Optimization application");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test benchmark execution
 */
static bool test_benchmark_execution(void) {
    TEST_SUITE_START("Benchmark Execution");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Test benchmark suite execution
    result = lackyvpn_audit_run_benchmarks(&ctx);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Benchmark suite execution");
    TEST_ASSERT(ctx.last_benchmark_time > 0, "Benchmark timestamp recording");

    // Test specific crypto benchmark
    result = lackyvpn_audit_benchmark_crypto(&ctx, "AES-256", 1000);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Crypto benchmark execution");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test report generation
 */
static bool test_report_generation(void) {
    TEST_SUITE_START("Report Generation");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Add some test data
    lackyvpn_performance_metric_t metric = {0};
    metric.type = LACKYVPN_METRIC_MEMORY_USAGE;
    strcpy(metric.name, "Memory Usage");
    metric.value = 65.0;
    metric.threshold = 85.0;
    lackyvpn_audit_add_metric(&ctx, &metric);

    // Generate comprehensive report
    char report_buffer[8192];
    result = lackyvpn_audit_generate_report(&ctx, report_buffer, sizeof(report_buffer));
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Report generation");
    TEST_ASSERT(strlen(report_buffer) > 0, "Report content generation");
    TEST_ASSERT(strstr(report_buffer, "LACKYVPN COMPREHENSIVE AUDIT REPORT") != NULL, "Report header");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test thread safety
 */
static bool test_thread_safety(void) {
    TEST_SUITE_START("Thread Safety");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    config.enable_continuous_monitoring = true;
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Start monitoring threads
    result = lackyvpn_audit_start(&ctx);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Monitoring thread start");
    TEST_ASSERT(ctx.is_monitoring, "Monitoring status flag");

    // Let it run for a short time
    Sleep(2000);

    // Stop monitoring
    result = lackyvpn_audit_stop(&ctx);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Monitoring thread stop");
    TEST_ASSERT(!ctx.is_monitoring, "Monitoring status reset");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test resource monitoring accuracy
 */
static bool test_resource_monitoring(void) {
    TEST_SUITE_START("Resource Monitoring");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Test multiple resource measurements
    for (int i = 0; i < 5; i++) {
        lackyvpn_resource_usage_t usage;
        result = lackyvpn_audit_get_resource_usage(&ctx, &usage);
        TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Resource measurement iteration");
        TEST_ASSERT(usage.memory_total_bytes > 0, "Memory detection");
        TEST_ASSERT(usage.cpu_cores > 0, "CPU core detection");
        
        Sleep(100); // Small delay between measurements
    }

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test statistics calculation
 */
static bool test_statistics_calculation(void) {
    TEST_SUITE_START("Statistics Calculation");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Add test data
    lackyvpn_performance_metric_t metric = {0};
    metric.type = LACKYVPN_METRIC_CPU_USAGE;
    strcpy(metric.name, "CPU Usage");
    metric.value = 50.0;
    metric.threshold = 80.0;
    lackyvpn_audit_add_metric(&ctx, &metric);

    // Calculate scores
    double security_score = lackyvpn_audit_calculate_security_score(&ctx);
    double performance_score = lackyvpn_audit_calculate_performance_score(&ctx);
    
    TEST_ASSERT(security_score >= 0.0 && security_score <= 100.0, "Security score range");
    TEST_ASSERT(performance_score >= 0.0 && performance_score <= 100.0, "Performance score range");

    // Test security requirements check
    bool meets_requirements = lackyvpn_audit_meets_security_requirements(&ctx, SECURITY_LEVEL_STANDARD);
    TEST_ASSERT(meets_requirements == true || meets_requirements == false, "Security requirements check");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test health status reporting
 */
static bool test_health_status(void) {
    TEST_SUITE_START("Health Status");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Test health status retrieval
    bool is_healthy;
    char status_message[256];
    result = lackyvpn_audit_get_health_status(&ctx, &is_healthy, status_message, sizeof(status_message));
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Health status retrieval");
    TEST_ASSERT(strlen(status_message) > 0, "Status message generation");

    // Test statistics retrieval
    uint64_t total_audits, total_issues, resolved_issues;
    double avg_performance;
    time_t last_audit;
    
    result = lackyvpn_audit_get_statistics(&ctx, &total_audits, &total_issues, 
        &resolved_issues, &avg_performance, &last_audit);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Statistics retrieval");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test high-load performance
 */
static bool test_high_load_performance(void) {
    TEST_SUITE_START("High Load Performance");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // Add many metrics rapidly
    time_t start_time = time(NULL);
    for (int i = 0; i < 100 && ctx.metric_count < LACKYVPN_AUDIT_MAX_METRICS; i++) {
        lackyvpn_performance_metric_t metric = {0};
        metric.type = LACKYVPN_METRIC_CPU_USAGE;
        snprintf(metric.name, sizeof(metric.name), "Test Metric %d", i);
        metric.value = (double)(rand() % 100);
        metric.threshold = 80.0;
        
        result = lackyvpn_audit_add_metric(&ctx, &metric);
        TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "High-load metric addition");
    }
    
    time_t end_time = time(NULL);
    TEST_ASSERT((end_time - start_time) < 5, "High-load performance within limits");

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

/**
 * Test memory leak detection
 */
static bool test_memory_leak_detection(void) {
    TEST_SUITE_START("Memory Leak Detection");

    // Test multiple initialization/cleanup cycles
    for (int i = 0; i < 10; i++) {
        lackyvpn_audit_context_t ctx;
        lackyvpn_audit_config_t config = create_test_config();
        
        lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
        TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Cycle initialization");
        
        // Add some data
        lackyvpn_performance_metric_t metric = {0};
        metric.type = LACKYVPN_METRIC_MEMORY_USAGE;
        strcpy(metric.name, "Test Memory");
        metric.value = 50.0;
        metric.threshold = 85.0;
        lackyvpn_audit_add_metric(&ctx, &metric);
        
        lackyvpn_audit_cleanup(&ctx);
    }

    TEST_ASSERT(true, "Memory leak test completed");
    TEST_SUITE_END();
}

/**
 * Test concurrent access
 */
static bool test_concurrent_access(void) {
    TEST_SUITE_START("Concurrent Access");

    lackyvpn_audit_context_t ctx;
    lackyvpn_audit_config_t config = create_test_config();
    
    lackyvpn_audit_result_t result = lackyvpn_audit_init(&ctx, &config);
    TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Context initialization");

    // This test would ideally spawn multiple threads, but for simplicity
    // we'll simulate concurrent access with rapid sequential operations
    for (int i = 0; i < 50; i++) {
        lackyvpn_performance_metric_t metric = {0};
        metric.type = LACKYVPN_METRIC_CPU_USAGE;
        strcpy(metric.name, "Concurrent Test");
        metric.value = (double)(i % 100);
        metric.threshold = 80.0;
        
        result = lackyvpn_audit_add_metric(&ctx, &metric);
        TEST_ASSERT(result == LACKYVPN_AUDIT_SUCCESS, "Concurrent metric addition");
        
        if (i % 10 == 0) {
            lackyvpn_audit_performance(&ctx, LACKYVPN_AUDIT_PERFORMANCE);
        }
    }

    lackyvpn_audit_cleanup(&ctx);
    TEST_SUITE_END();
}

// ========== HELPER FUNCTIONS ==========

static bool run_test(const char* test_name, bool(*test_func)(void)) {
    printf("Running test: %s\n", test_name);
    g_tests_run++;
    
    bool result = test_func();
    if (result) {
        g_tests_passed++;
        printf("✓ PASSED: %s\n\n", test_name);
    } else {
        g_tests_failed++;
        printf("✗ FAILED: %s\n\n", test_name);
    }
    
    return result;
}

static void print_test_summary(void) {
    printf("=== TEST SUMMARY ===\n");
    printf("Tests Run:    %d\n", g_tests_run);
    printf("Tests Passed: %d\n", g_tests_passed);
    printf("Tests Failed: %d\n", g_tests_failed);
    printf("Success Rate: %.1f%%\n", 
        g_tests_run > 0 ? ((double)g_tests_passed / g_tests_run * 100.0) : 0.0);
    printf("Overall Result: %s\n", g_tests_failed == 0 ? "SUCCESS" : "FAILURE");
}

static lackyvpn_audit_config_t create_test_config(void) {
    lackyvpn_audit_config_t config = {0};
    config.audit_categories = LACKYVPN_AUDIT_ALL;
    config.security_level = SECURITY_LEVEL_STANDARD;
    config.enable_continuous_monitoring = false; // Disabled for most tests
    config.enable_automated_optimization = false;
    config.enable_benchmark_suite = false;
    config.enable_compliance_checking = true;
    config.monitoring_interval_ms = 1000;
    config.benchmark_interval_hours = 24;
    config.audit_retention_days = 30;
    strcpy(config.report_output_path, "test_reports");
    
    return config;
}
