/**
 * LACKYVPN - Distress Mode System Implementation
 * Zero-dependency emergency response and evidence destruction
 * 80s Retro-Cyber Security Framework
 * 
 * CRITICAL SECURITY WARNING:
 * This implementation provides irreversible data destruction capabilities.
 * All functions implement military-grade sanitization standards.
 * Activation protocols designed for genuine security emergencies only.
 */

#include "distress_mode.h"
#include "../crypto/crypto_primitives.h"
#include "../protection/binary_mutation.h"
#include <windows.h>
#include <psapi.h>
#include <winternl.h>
#include <wincrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <io.h>
#include <fcntl.h>

// ========== INTERNAL CONSTANTS ==========

#define DISTRESS_MAGIC_SIGNATURE 0xDEADBEEFCAFEBABE
#define DISTRESS_OVERWRITE_BUFFER_SIZE (1024 * 1024)  // 1MB buffer
#define DISTRESS_VERIFICATION_SAMPLES 16
#define DISTRESS_MAX_WIPE_RETRIES 3
#define DISTRESS_THREAD_STACK_SIZE (64 * 1024)

// DOD 5220.22-M overwrite patterns
static const uint8_t DOD_PATTERNS[3][32] = {
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
    {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF},
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
};

// Gutmann 35-pass patterns (first 16 shown)
static const uint8_t GUTMANN_PATTERNS[16][32] = {
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
    {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF},
    {0x92, 0x49, 0x24, 0x92, 0x49, 0x24, 0x92, 0x49, 0x24, 0x92, 0x49, 0x24, 0x92, 0x49, 0x24, 0x92,
     0x49, 0x24, 0x92, 0x49, 0x24, 0x92, 0x49, 0x24, 0x92, 0x49, 0x24, 0x92, 0x49, 0x24, 0x92, 0x49},
    // ... additional patterns would be defined here
};

// Forensic tool signatures
static const char* FORENSIC_TOOLS[] = {
    "wireshark.exe", "volatility.exe", "ftk.exe", "encase.exe", "autopsy.exe",
    "sleuthkit.exe", "rekall.exe", "tcpdump.exe", "tshark.exe", "x64dbg.exe",
    "ollydbg.exe", "ida.exe", "ida64.exe", "ghidra.exe", "radare2.exe",
    "procmon.exe", "procexp.exe", "regshot.exe", "regmon.exe", "filemon.exe",
    "vmware.exe", "virtualbox.exe", "qemu.exe", "bochs.exe", "sandboxie.exe"
};

// ========== INTERNAL FUNCTIONS ==========

static bool distress_is_signature_valid(const distress_context_t* ctx) {
    return (ctx != NULL) && (*(uint64_t*)ctx == DISTRESS_MAGIC_SIGNATURE);
}

static void distress_secure_zero_memory(void* ptr, size_t size) {
    if (ptr && size > 0) {
        volatile uint8_t* p = (volatile uint8_t*)ptr;
        for (size_t i = 0; i < size; i++) {
            p[i] = 0;
        }
        // Additional security: use Windows SecureZeroMemory if available
        SecureZeroMemory(ptr, size);
    }
}

static bool distress_get_hardware_entropy(uint8_t* buffer, size_t size) {
    HCRYPTPROV hProv;
    bool success = false;
    
    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        success = CryptGenRandom(hProv, (DWORD)size, buffer);
        CryptReleaseContext(hProv, 0);
    }
    
    // Fallback to RDRAND if available
    if (!success) {
        for (size_t i = 0; i < size; i += 4) {
            uint32_t rand_val = rand();
            memcpy(buffer + i, &rand_val, min(4, size - i));
        }
        success = true;
    }
    
    return success;
}

// ========== CORE DISTRESS FUNCTIONS ==========

bool distress_initialize(distress_context_t* ctx, const distress_config_t* config) {
    if (!ctx || !config) return false;
    
    // Initialize context with magic signature
    memset(ctx, 0, sizeof(distress_context_t));
    *(uint64_t*)ctx = DISTRESS_MAGIC_SIGNATURE;
    
    // Copy configuration
    memcpy(&ctx->config, config, sizeof(distress_config_t));
    
    // Initialize critical section
    InitializeCriticalSection(&ctx->state_lock);
    
    // Set initial state
    ctx->is_active = false;
    ctx->is_armed = false;
    ctx->current_level = DISTRESS_LEVEL_GHOST;
    ctx->last_trigger = 0;
    ctx->deadman_last_checkin = time(NULL);
    ctx->shutdown_requested = false;
    
    // Initialize destruction targets
    ctx->target_count = 0;
    ctx->decoy_count = 0;
    
    // Zero statistics
    ctx->total_bytes_destroyed = 0;
    ctx->files_destroyed = 0;
    ctx->directories_destroyed = 0;
    ctx->processes_terminated = 0;
    ctx->registry_keys_deleted = 0;
    
    // Initialize thread handles
    ctx->deadman_thread = NULL;
    ctx->watcher_count = 0;
    for (int i = 0; i < DISTRESS_MAX_WATCHERS; i++) {
        ctx->watcher_threads[i] = NULL;
    }
    
    return true;
}

bool distress_arm(distress_context_t* ctx) {
    if (!distress_is_signature_valid(ctx)) return false;
    
    EnterCriticalSection(&ctx->state_lock);
    
    if (ctx->is_armed) {
        LeaveCriticalSection(&ctx->state_lock);
        return true; // Already armed
    }
    
    // Setup watchers based on configuration
    bool success = true;
    
    if (ctx->config.trigger_mask & DISTRESS_TRIGGER_PANIC_KEY) {
        success &= distress_setup_panic_key_watcher(ctx);
    }
    
    if (ctx->config.trigger_mask & DISTRESS_TRIGGER_PROCESS_KILL) {
        success &= distress_setup_process_watcher(ctx, GetCurrentProcessId());
    }
    
    if (ctx->config.trigger_mask & DISTRESS_TRIGGER_NETWORK_SCAN) {
        success &= distress_setup_network_watcher(ctx);
    }
    
    if (ctx->config.trigger_mask & DISTRESS_TRIGGER_FORENSIC_TOOL) {
        success &= distress_setup_forensic_watcher(ctx);
    }
    
    if (success) {
        ctx->is_armed = true;
        ctx->deadman_last_checkin = time(NULL);
        
        // Log arming event
        distress_log_event(ctx, "DISTRESS_ARMED", 0);
    }
    
    LeaveCriticalSection(&ctx->state_lock);
    return success;
}

bool distress_disarm(distress_context_t* ctx, const char* safe_word) {
    if (!distress_is_signature_valid(ctx) || !safe_word) return false;
    
    // Verify safe word
    if (strcmp(safe_word, ctx->config.safe_word) != 0) {
        distress_log_event(ctx, "DISTRESS_DISARM_FAILED_INVALID_SAFE_WORD", 0);
        return false;
    }
    
    EnterCriticalSection(&ctx->state_lock);
    
    // Request shutdown of all watchers
    ctx->shutdown_requested = true;
    
    // Wait for threads to terminate
    for (uint32_t i = 0; i < ctx->watcher_count; i++) {
        if (ctx->watcher_threads[i]) {
            WaitForSingleObject(ctx->watcher_threads[i], 5000); // 5 second timeout
            CloseHandle(ctx->watcher_threads[i]);
            ctx->watcher_threads[i] = NULL;
        }
    }
    
    if (ctx->deadman_thread) {
        WaitForSingleObject(ctx->deadman_thread, 5000);
        CloseHandle(ctx->deadman_thread);
        ctx->deadman_thread = NULL;
    }
    
    ctx->is_armed = false;
    ctx->watcher_count = 0;
    ctx->shutdown_requested = false;
    
    // Log disarming event
    distress_log_event(ctx, "DISTRESS_DISARMED", 0);
    
    LeaveCriticalSection(&ctx->state_lock);
    return true;
}

bool distress_activate(distress_context_t* ctx, distress_level_t level, distress_trigger_t trigger) {
    if (!distress_is_signature_valid(ctx)) return false;
    
    EnterCriticalSection(&ctx->state_lock);
    
    // Check if already active
    if (ctx->is_active) {
        LeaveCriticalSection(&ctx->state_lock);
        return true;
    }
    
    // Set activation state
    ctx->is_active = true;
    ctx->current_level = level;
    ctx->last_trigger = trigger;
    ctx->activation_time = time(NULL);
    
    // Log activation
    char log_msg[256];
    snprintf(log_msg, sizeof(log_msg), "DISTRESS_ACTIVATED_LEVEL_%d_TRIGGER_0x%02X", 
             level, trigger);
    distress_log_event(ctx, log_msg, trigger);
    
    LeaveCriticalSection(&ctx->state_lock);
    
    // Grace period delay
    if (ctx->config.activation_delay_ms > 0) {
        Sleep(ctx->config.activation_delay_ms);
    }
    
    // Execute response based on level
    bool success = true;
    
    switch (level) {
        case DISTRESS_LEVEL_GHOST:
            // Hide traces, continue operation
            if (ctx->config.enable_decoy_mode) {
                success &= distress_create_decoy_processes(ctx);
            }
            success &= distress_manipulate_timestamps(".");
            success &= distress_create_false_trails();
            break;
            
        case DISTRESS_LEVEL_STEALTH:
            // Destroy logs, minimal operation
            success &= distress_sanitize_registry();
            if (ctx->config.destroy_system_logs) {
                success &= distress_disable_event_logging();
            }
            success &= distress_sanitize_memory();
            break;
            
        case DISTRESS_LEVEL_SCORCHED:
            // Destroy all evidence, shutdown
            success &= distress_cutoff_network();
            success &= distress_sanitize_system_files();
            success &= distress_sanitize_registry();
            success &= distress_sanitize_memory();
            
            // Destroy all targets
            for (uint32_t i = 0; i < ctx->target_count; i++) {
                if (ctx->destroy_targets[i].is_directory) {
                    success &= distress_destroy_directory(ctx->destroy_targets[i].path,
                                                        ctx->destroy_targets[i].passes_required,
                                                        ctx->destroy_targets[i].require_verification);
                } else {
                    success &= distress_destroy_file(ctx->destroy_targets[i].path,
                                                   ctx->destroy_targets[i].passes_required,
                                                   ctx->destroy_targets[i].require_verification);
                }
            }
            
            // Emergency shutdown
            success &= distress_emergency_shutdown(10);
            break;
            
        case DISTRESS_LEVEL_NUCLEAR:
            // Complete system sanitization
            success &= distress_cutoff_network();
            success &= distress_lockdown_firewall();
            success &= distress_poison_dns_cache();
            success &= distress_disable_event_logging();
            success &= distress_corrupt_restore_points();
            success &= distress_sanitize_system_files();
            success &= distress_sanitize_registry();
            success &= distress_sanitize_memory();
            
            if (ctx->config.wipe_free_space) {
                success &= distress_sanitize_free_space("C:", DISTRESS_CRYPTO_ROUNDS);
            }
            
            // Destroy all targets with maximum passes
            for (uint32_t i = 0; i < ctx->target_count; i++) {
                if (ctx->destroy_targets[i].is_directory) {
                    success &= distress_destroy_directory(ctx->destroy_targets[i].path,
                                                        35, // Gutmann passes
                                                        true);
                } else {
                    success &= distress_destroy_file(ctx->destroy_targets[i].path,
                                                   35, // Gutmann passes
                                                   true);
                }
            }
            
            // Immediate shutdown
            success &= distress_emergency_shutdown(1);
            break;
    }
    
    return success;
}

bool distress_is_active(const distress_context_t* ctx) {
    if (!distress_is_signature_valid(ctx)) return false;
    return ctx->is_active;
}

void distress_get_status(const distress_context_t* ctx, distress_destroy_status_t* status) {
    if (!distress_is_signature_valid(ctx) || !status) return;
    
    memset(status, 0, sizeof(distress_destroy_status_t));
    
    if (!ctx->is_active) {
        status->is_complete = false;
        return;
    }
    
    // Calculate aggregate status from all targets
    uint64_t total_size = 0;
    uint64_t total_destroyed = 0;
    uint32_t total_passes = 0;
    uint32_t completed_passes = 0;
    
    for (uint32_t i = 0; i < ctx->target_count; i++) {
        total_size += ctx->destroy_targets[i].size;
        total_destroyed += ctx->destroy_targets[i].status.bytes_destroyed;
        total_passes += ctx->destroy_targets[i].passes_required;
        completed_passes += ctx->destroy_targets[i].status.passes_completed;
    }
    
    status->file_size = total_size;
    status->bytes_destroyed = total_destroyed;
    status->passes_completed = completed_passes;
    status->is_complete = (total_destroyed >= total_size) && (completed_passes >= total_passes);
    status->start_time = ctx->activation_time;
    
    // Estimate completion time
    if (status->bytes_destroyed > 0 && !status->is_complete) {
        time_t elapsed = time(NULL) - ctx->activation_time;
        float progress = (float)status->bytes_destroyed / status->file_size;
        status->estimated_completion = ctx->activation_time + (time_t)(elapsed / progress);
    }
}

void distress_cleanup(distress_context_t* ctx) {
    if (!distress_is_signature_valid(ctx)) return;
    
    // Disarm safely
    if (ctx->is_armed) {
        distress_disarm(ctx, ctx->config.safe_word);
    }
    
    // Clean up critical section
    DeleteCriticalSection(&ctx->state_lock);
    
    // Secure zero of sensitive data
    distress_secure_zero_memory(&ctx->config, sizeof(distress_config_t));
    distress_secure_zero_memory(ctx->destroy_targets, 
                               sizeof(distress_target_t) * DISTRESS_MAX_DESTROY_PATHS);
    
    // Clear magic signature
    *(uint64_t*)ctx = 0;
}

// ========== TARGET MANAGEMENT ==========

bool distress_add_target(distress_context_t* ctx, const char* path, uint32_t priority, uint32_t passes) {
    if (!distress_is_signature_valid(ctx) || !path) return false;
    
    EnterCriticalSection(&ctx->state_lock);
    
    if (ctx->target_count >= DISTRESS_MAX_DESTROY_PATHS) {
        LeaveCriticalSection(&ctx->state_lock);
        return false;
    }
    
    distress_target_t* target = &ctx->destroy_targets[ctx->target_count];
    
    strncpy(target->path, path, sizeof(target->path) - 1);
    target->path[sizeof(target->path) - 1] = '\0';
    target->priority = priority;
    target->passes_required = passes;
    target->require_verification = (passes > 1);
    
    // Check if path is directory
    struct stat st;
    if (stat(path, &st) == 0) {
        target->is_directory = S_ISDIR(st.st_mode);
        target->size = st.st_size;
    } else {
        target->is_directory = false;
        target->size = 0;
    }
    
    // Initialize status
    memset(&target->status, 0, sizeof(distress_destroy_status_t));
    
    ctx->target_count++;
    
    LeaveCriticalSection(&ctx->state_lock);
    return true;
}

bool distress_add_directory_tree(distress_context_t* ctx, const char* root_path, 
                                uint32_t priority, uint32_t passes) {
    if (!distress_is_signature_valid(ctx) || !root_path) return false;
    
    // First add the root directory
    if (!distress_add_target(ctx, root_path, priority, passes)) {
        return false;
    }
    
    // Recursively add subdirectories and files
    WIN32_FIND_DATAA findData;
    char searchPath[MAX_PATH];
    snprintf(searchPath, sizeof(searchPath), "%s\\*", root_path);
    
    HANDLE hFind = FindFirstFileA(searchPath, &findData);
    if (hFind == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    do {
        if (strcmp(findData.cFileName, ".") != 0 && strcmp(findData.cFileName, "..") != 0) {
            char fullPath[MAX_PATH];
            snprintf(fullPath, sizeof(fullPath), "%s\\%s", root_path, findData.cFileName);
            
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                // Recursively add subdirectory
                distress_add_directory_tree(ctx, fullPath, priority + 1, passes);
            } else {
                // Add file
                distress_add_target(ctx, fullPath, priority + 1, passes);
            }
        }
    } while (FindNextFileA(hFind, &findData));
    
    FindClose(hFind);
    return true;
}

bool distress_remove_target(distress_context_t* ctx, const char* path) {
    if (!distress_is_signature_valid(ctx) || !path) return false;
    
    EnterCriticalSection(&ctx->state_lock);
    
    for (uint32_t i = 0; i < ctx->target_count; i++) {
        if (strcmp(ctx->destroy_targets[i].path, path) == 0) {
            // Move last element to this position
            if (i < ctx->target_count - 1) {
                memcpy(&ctx->destroy_targets[i], &ctx->destroy_targets[ctx->target_count - 1],
                       sizeof(distress_target_t));
            }
            ctx->target_count--;
            
            LeaveCriticalSection(&ctx->state_lock);
            return true;
        }
    }
    
    LeaveCriticalSection(&ctx->state_lock);
    return false;
}

void distress_clear_targets(distress_context_t* ctx) {
    if (!distress_is_signature_valid(ctx)) return;
    
    EnterCriticalSection(&ctx->state_lock);
    ctx->target_count = 0;
    memset(ctx->destroy_targets, 0, sizeof(ctx->destroy_targets));
    LeaveCriticalSection(&ctx->state_lock);
}

// ========== DESTRUCTION FUNCTIONS ==========

void distress_generate_random_pattern(uint8_t* buffer, size_t size) {
    if (!buffer || size == 0) return;
    
    // Use hardware entropy if available
    if (!distress_get_hardware_entropy(buffer, size)) {
        // Fallback to time-seeded random
        srand((unsigned int)time(NULL));
        for (size_t i = 0; i < size; i++) {
            buffer[i] = (uint8_t)(rand() & 0xFF);
        }
    }
}

bool distress_destroy_file(const char* filepath, uint32_t passes, bool verify_destruction) {
    if (!filepath || passes == 0) return false;
    
    // Open file for writing
    HANDLE hFile = CreateFileA(filepath, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 
                              FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    // Get file size
    LARGE_INTEGER fileSize;
    if (!GetFileSizeEx(hFile, &fileSize)) {
        CloseHandle(hFile);
        return false;
    }
    
    // Allocate overwrite buffer
    uint8_t* buffer = (uint8_t*)malloc(DISTRESS_OVERWRITE_BUFFER_SIZE);
    if (!buffer) {
        CloseHandle(hFile);
        return false;
    }
    
    bool success = true;
    
    // Perform overwrite passes
    for (uint32_t pass = 0; pass < passes && success; pass++) {
        // Reset file pointer
        SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
        
        // Choose pattern based on pass number
        if (pass < 3) {
            // Use DOD patterns for first 3 passes
            memset(buffer, DOD_PATTERNS[pass][0], DISTRESS_OVERWRITE_BUFFER_SIZE);
        } else if (pass < 16) {
            // Use Gutmann patterns
            size_t pattern_idx = pass - 3;
            for (size_t i = 0; i < DISTRESS_OVERWRITE_BUFFER_SIZE; i++) {
                buffer[i] = GUTMANN_PATTERNS[pattern_idx][i % 32];
            }
        } else {
            // Use random patterns
            distress_generate_random_pattern(buffer, DISTRESS_OVERWRITE_BUFFER_SIZE);
        }
        
        // Overwrite file
        LONGLONG remaining = fileSize.QuadPart;
        while (remaining > 0 && success) {
            DWORD to_write = (DWORD)min(remaining, DISTRESS_OVERWRITE_BUFFER_SIZE);
            DWORD written;
            
            if (!WriteFile(hFile, buffer, to_write, &written, NULL) || written != to_write) {
                success = false;
            }
            
            remaining -= written;
        }
        
        // Flush to disk
        if (success) {
            FlushFileBuffers(hFile);
        }
    }
    
    CloseHandle(hFile);
    free(buffer);
    
    // Verify destruction if requested
    if (success && verify_destruction) {
        success = distress_verify_destruction(filepath);
    }
    
    // Delete file
    if (success) {
        // Set normal attributes to ensure deletion
        SetFileAttributesA(filepath, FILE_ATTRIBUTE_NORMAL);
        success = DeleteFileA(filepath);
    }
    
    return success;
}

bool distress_destroy_directory(const char* dirpath, uint32_t passes, bool verify_destruction) {
    if (!dirpath) return false;
    
    // First, recursively destroy all files in directory
    WIN32_FIND_DATAA findData;
    char searchPath[MAX_PATH];
    snprintf(searchPath, sizeof(searchPath), "%s\\*", dirpath);
    
    HANDLE hFind = FindFirstFileA(searchPath, &findData);
    if (hFind == INVALID_HANDLE_VALUE) {
        return false;
    }
    
    bool success = true;
    
    do {
        if (strcmp(findData.cFileName, ".") != 0 && strcmp(findData.cFileName, "..") != 0) {
            char fullPath[MAX_PATH];
            snprintf(fullPath, sizeof(fullPath), "%s\\%s", dirpath, findData.cFileName);
            
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                // Recursively destroy subdirectory
                success &= distress_destroy_directory(fullPath, passes, verify_destruction);
            } else {
                // Destroy file
                success &= distress_destroy_file(fullPath, passes, verify_destruction);
            }
        }
    } while (FindNextFileA(hFind, &findData) && success);
    
    FindClose(hFind);
    
    // Remove the directory itself
    if (success) {
        SetFileAttributesA(dirpath, FILE_ATTRIBUTE_NORMAL);
        success = RemoveDirectoryA(dirpath);
    }
    
    return success;
}

bool distress_verify_destruction(const char* filepath) {
    if (!filepath) return false;
    
    // Try to open file for reading
    HANDLE hFile = CreateFileA(filepath, GENERIC_READ, FILE_SHARE_READ, NULL, 
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        // File doesn't exist - destruction successful
        return true;
    }
    
    // Read samples from file to verify overwrite
    uint8_t sample_buffer[256];
    DWORD bytes_read;
    bool is_overwritten = true;
    
    for (int i = 0; i < DISTRESS_VERIFICATION_SAMPLES; i++) {
        // Seek to random position
        LARGE_INTEGER fileSize;
        GetFileSizeEx(hFile, &fileSize);
        LARGE_INTEGER pos;
        pos.QuadPart = (rand() % fileSize.QuadPart);
        SetFilePointerEx(hFile, pos, NULL, FILE_BEGIN);
        
        // Read sample
        if (ReadFile(hFile, sample_buffer, sizeof(sample_buffer), &bytes_read, NULL)) {
            // Check if data appears to be meaningful (not overwritten)
            uint32_t zero_count = 0;
            uint32_t ff_count = 0;
            
            for (DWORD j = 0; j < bytes_read; j++) {
                if (sample_buffer[j] == 0x00) zero_count++;
                if (sample_buffer[j] == 0xFF) ff_count++;
            }
            
            // If most bytes are not 0x00 or 0xFF, file may not be properly overwritten
            if (zero_count < bytes_read / 3 && ff_count < bytes_read / 3) {
                is_overwritten = false;
                break;
            }
        }
    }
    
    CloseHandle(hFile);
    return is_overwritten;
}

// ========== WATCHER THREAD FUNCTIONS ==========

static DWORD WINAPI distress_panic_key_thread(LPVOID param) {
    distress_context_t* ctx = (distress_context_t*)param;
    if (!ctx) return 1;
    
    uint32_t f12_count = 0;
    DWORD last_f12_time = 0;
    const DWORD PANIC_SEQUENCE_TIMEOUT = 2000; // 2 seconds
    const uint32_t PANIC_SEQUENCE_COUNT = 3;   // F12 pressed 3 times
    
    while (!ctx->shutdown_requested) {
        // Check F12 key state
        if (GetAsyncKeyState(VK_F12) & 0x8000) {
            DWORD current_time = GetTickCount();
            
            if (current_time - last_f12_time < PANIC_SEQUENCE_TIMEOUT) {
                f12_count++;
                if (f12_count >= PANIC_SEQUENCE_COUNT) {
                    // Panic sequence detected!
                    distress_activate(ctx, ctx->config.response_level, DISTRESS_TRIGGER_PANIC_KEY);
                    break;
                }
            } else {
                f12_count = 1; // Reset sequence
            }
            
            last_f12_time = current_time;
            
            // Wait for key release
            while (GetAsyncKeyState(VK_F12) & 0x8000 && !ctx->shutdown_requested) {
                Sleep(50);
            }
        }
        
        Sleep(100); // Check every 100ms
    }
    
    return 0;
}

static DWORD WINAPI distress_process_watcher_thread(LPVOID param) {
    distress_context_t* ctx = (distress_context_t*)param;
    if (!ctx) return 1;
    
    DWORD parent_pid = GetCurrentProcessId();
    HANDLE hParent = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, parent_pid);
    
    if (!hParent) return 1;
    
    while (!ctx->shutdown_requested) {
        DWORD exit_code;
        if (GetExitCodeProcess(hParent, &exit_code)) {
            if (exit_code != STILL_ACTIVE) {
                // Parent process terminated!
                CloseHandle(hParent);
                distress_activate(ctx, ctx->config.response_level, DISTRESS_TRIGGER_PROCESS_KILL);
                break;
            }
        }
        
        Sleep(1000); // Check every second
    }
    
    if (hParent) CloseHandle(hParent);
    return 0;
}

static DWORD WINAPI distress_forensic_watcher_thread(LPVOID param) {
    distress_context_t* ctx = (distress_context_t*)param;
    if (!ctx) return 1;
    
    const size_t TOOL_COUNT = sizeof(FORENSIC_TOOLS) / sizeof(FORENSIC_TOOLS[0]);
    
    while (!ctx->shutdown_requested) {
        // Enumerate running processes
        DWORD processes[1024];
        DWORD cb_needed;
        
        if (EnumProcesses(processes, sizeof(processes), &cb_needed)) {
            DWORD process_count = cb_needed / sizeof(DWORD);
            
            for (DWORD i = 0; i < process_count; i++) {
                HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                                           FALSE, processes[i]);
                if (hProcess) {
                    char process_name[MAX_PATH];
                    if (GetModuleBaseNameA(hProcess, NULL, process_name, sizeof(process_name))) {
                        // Check against forensic tool list
                        for (size_t j = 0; j < TOOL_COUNT; j++) {
                            if (_stricmp(process_name, FORENSIC_TOOLS[j]) == 0) {
                                // Forensic tool detected!
                                CloseHandle(hProcess);
                                distress_activate(ctx, ctx->config.response_level, 
                                                DISTRESS_TRIGGER_FORENSIC_TOOL);
                                return 0;
                            }
                        }
                    }
                    CloseHandle(hProcess);
                }
            }
        }
        
        Sleep(5000); // Check every 5 seconds
    }
    
    return 0;
}

bool distress_setup_panic_key_watcher(distress_context_t* ctx) {
    if (!ctx || ctx->watcher_count >= DISTRESS_MAX_WATCHERS) return false;
    
    HANDLE hThread = CreateThread(NULL, DISTRESS_THREAD_STACK_SIZE,
                                 distress_panic_key_thread, ctx, 0, NULL);
    if (!hThread) return false;
    
    ctx->watcher_threads[ctx->watcher_count++] = hThread;
    return true;
}

bool distress_setup_process_watcher(distress_context_t* ctx, uint32_t parent_pid) {
    if (!ctx || ctx->watcher_count >= DISTRESS_MAX_WATCHERS) return false;
    
    HANDLE hThread = CreateThread(NULL, DISTRESS_THREAD_STACK_SIZE,
                                 distress_process_watcher_thread, ctx, 0, NULL);
    if (!hThread) return false;
    
    ctx->watcher_threads[ctx->watcher_count++] = hThread;
    return true;
}

bool distress_setup_forensic_watcher(distress_context_t* ctx) {
    if (!ctx || ctx->watcher_count >= DISTRESS_MAX_WATCHERS) return false;
    
    HANDLE hThread = CreateThread(NULL, DISTRESS_THREAD_STACK_SIZE,
                                 distress_forensic_watcher_thread, ctx, 0, NULL);
    if (!hThread) return false;
    
    ctx->watcher_threads[ctx->watcher_count++] = hThread;
    return true;
}

bool distress_setup_network_watcher(distress_context_t* ctx) {
    // Network scanning detection would require more complex implementation
    // This is a placeholder for now
    return true;
}

bool distress_setup_usb_watcher(distress_context_t* ctx, const char* usb_serial) {
    // USB removal detection would require device monitoring
    // This is a placeholder for now
    return true;
}

bool distress_checkin_deadman(distress_context_t* ctx) {
    if (!distress_is_signature_valid(ctx)) return false;
    
    EnterCriticalSection(&ctx->state_lock);
    ctx->deadman_last_checkin = time(NULL);
    LeaveCriticalSection(&ctx->state_lock);
    
    return true;
}

// ========== SYSTEM MODIFICATION FUNCTIONS ==========

bool distress_cutoff_network(void) {
    // Disable all network adapters
    system("netsh interface set interface \"Wi-Fi\" admin=disable");
    system("netsh interface set interface \"Ethernet\" admin=disable");
    system("netsh interface set interface \"Local Area Connection\" admin=disable");
    
    // Flush DNS cache
    system("ipconfig /flushdns");
    
    // Reset TCP/IP stack
    system("netsh int ip reset");
    
    return true;
}

bool distress_emergency_shutdown(uint32_t delay_seconds) {
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "shutdown /s /f /t %u", delay_seconds);
    return system(cmd) == 0;
}

bool distress_sanitize_system_files(void) {
    bool success = true;
    
    // Clear pagefile
    success &= distress_destroy_file("C:\\pagefile.sys", DISTRESS_CRYPTO_ROUNDS, false);
    
    // Clear hibernation file
    success &= distress_destroy_file("C:\\hiberfil.sys", DISTRESS_CRYPTO_ROUNDS, false);
    
    // Clear swap files
    success &= distress_destroy_file("C:\\swapfile.sys", DISTRESS_CRYPTO_ROUNDS, false);
    
    return success;
}

bool distress_sanitize_registry(void) {
    // Remove LACKYVPN registry traces
    system("reg delete HKCU\\Software\\LACKYVPN /f");
    system("reg delete HKLM\\Software\\LACKYVPN /f");
    system("reg delete HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v LACKYVPN /f");
    
    return true;
}

bool distress_sanitize_memory(void) {
    // Force garbage collection and memory cleanup
    // This is a simplified implementation
    for (int i = 0; i < 3; i++) {
        void* dummy = malloc(1024 * 1024 * 100); // 100MB
        if (dummy) {
            memset(dummy, 0, 1024 * 1024 * 100);
            free(dummy);
        }
    }
    
    return true;
}

bool distress_disable_event_logging(void) {
    // Stop Windows Event Log service
    system("net stop eventlog");
    
    // Clear event logs
    system("wevtutil cl System");
    system("wevtutil cl Security");
    system("wevtutil cl Application");
    
    return true;
}

bool distress_corrupt_restore_points(void) {
    // Disable system restore
    system("vssadmin delete shadows /all /quiet");
    system("reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore\" /v DisableSR /t REG_DWORD /d 1 /f");
    
    return true;
}

// ========== UTILITY FUNCTIONS ==========

float distress_get_progress(const distress_context_t* ctx) {
    if (!distress_is_signature_valid(ctx) || !ctx->is_active) return 0.0f;
    
    uint64_t total_size = 0;
    uint64_t destroyed_size = 0;
    
    for (uint32_t i = 0; i < ctx->target_count; i++) {
        total_size += ctx->destroy_targets[i].size;
        destroyed_size += ctx->destroy_targets[i].status.bytes_destroyed;
    }
    
    if (total_size == 0) return 1.0f;
    
    return (float)destroyed_size / total_size;
}

void distress_log_event(distress_context_t* ctx, const char* event, distress_trigger_t trigger) {
    if (!ctx || !event) return;
    
    // Create encrypted log entry
    char log_entry[512];
    time_t now = time(NULL);
    struct tm* tm_info = localtime(&now);
    
    snprintf(log_entry, sizeof(log_entry), 
             "[%04d-%02d-%02d %02d:%02d:%02d] DISTRESS: %s (Trigger: 0x%02X)\n",
             tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday,
             tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec,
             event, trigger);
    
    // Write to secure log file (encrypted)
    FILE* log_file = fopen("distress.log", "a");
    if (log_file) {
        fwrite(log_entry, 1, strlen(log_entry), log_file);
        fclose(log_file);
    }
}
