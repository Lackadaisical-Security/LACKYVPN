/**
 * LACKYVPN - Distress Mode System
 * Zero-dependency emergency response and evidence destruction
 * 80s Retro-Cyber Security Framework
 * 
 * CRITICAL SECURITY WARNING:
 * This module implements emergency evidence destruction protocols.
 * Activation results in irreversible data destruction and system modifications.
 * Use only in genuine security emergencies.
 */

#ifndef LACKYVPN_DISTRESS_MODE_H
#define LACKYVPN_DISTRESS_MODE_H

#include <stdint.h>
#include <stdbool.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

// ========== DISTRESS MODE CONSTANTS ==========

#define DISTRESS_MAX_WATCHERS 16
#define DISTRESS_MAX_DESTROY_PATHS 128
#define DISTRESS_MAX_DECOY_PROCESSES 32
#define DISTRESS_DEADMAN_INTERVAL 30  // seconds
#define DISTRESS_CRYPTO_ROUNDS 7      // DOD 5220.22-M standard
#define DISTRESS_OVERWRITE_PATTERNS 3

// Activation methods
typedef enum {
    DISTRESS_TRIGGER_PANIC_KEY = 0x01,      // F12+F12+F12 rapid sequence
    DISTRESS_TRIGGER_USB_REMOVAL = 0x02,    // Dead man's switch USB
    DISTRESS_TRIGGER_PROCESS_KILL = 0x04,   // Parent process termination
    DISTRESS_TRIGGER_NETWORK_SCAN = 0x08,   // Network intrusion detection
    DISTRESS_TRIGGER_FORENSIC_TOOL = 0x10,  // Forensic tool detection
    DISTRESS_TRIGGER_VM_DETECTION = 0x20,   // Virtual machine analysis
    DISTRESS_TRIGGER_DURESS_CODE = 0x40,    // Duress password entered
    DISTRESS_TRIGGER_MANUAL = 0x80          // Manual activation
} distress_trigger_t;

// Response levels
typedef enum {
    DISTRESS_LEVEL_GHOST = 1,    // Hide all traces, continue operation
    DISTRESS_LEVEL_STEALTH = 2,  // Destroy logs, minimal operation
    DISTRESS_LEVEL_SCORCHED = 3, // Destroy all evidence, shutdown
    DISTRESS_LEVEL_NUCLEAR = 4   // Complete system sanitization
} distress_level_t;

// Sanitization patterns
typedef enum {
    SANITIZE_PATTERN_ZEROS = 0,
    SANITIZE_PATTERN_ONES = 1,
    SANITIZE_PATTERN_RANDOM = 2,
    SANITIZE_PATTERN_DOD_A = 3,  // 0x00
    SANITIZE_PATTERN_DOD_B = 4,  // 0xFF
    SANITIZE_PATTERN_DOD_C = 5,  // Random
    SANITIZE_PATTERN_GUTMANN = 6 // Gutmann 35-pass
} sanitize_pattern_t;

// ========== DISTRESS MODE STRUCTURES ==========

typedef struct {
    uint64_t file_size;
    uint64_t bytes_destroyed;
    uint32_t passes_completed;
    uint32_t verification_errors;
    bool is_complete;
    time_t start_time;
    time_t estimated_completion;
} distress_destroy_status_t;

typedef struct {
    char path[512];
    uint64_t size;
    uint32_t priority;        // 0=highest, 255=lowest
    uint32_t passes_required;
    bool require_verification;
    bool is_directory;
    distress_destroy_status_t status;
} distress_target_t;

typedef struct {
    uint32_t process_id;
    char process_name[256];
    char decoy_path[512];
    bool is_active;
    time_t start_time;
} distress_decoy_process_t;

typedef struct {
    distress_trigger_t trigger_mask;
    distress_level_t response_level;
    uint32_t activation_delay_ms;    // Grace period
    bool require_confirmation;       // Double-tap confirmation
    bool enable_decoy_mode;         // Create decoy processes
    bool preserve_plausible_files;  // Keep innocent files
    bool wipe_free_space;           // Sanitize unallocated space
    bool destroy_system_logs;       // Clear Windows event logs
    bool corrupt_hibernation;       // Destroy hiberfil.sys
    bool clear_page_file;          // Sanitize pagefile.sys
    char duress_password[128];      // Fake password that triggers distress
    char safe_word[64];            // Abort sequence
} distress_config_t;

typedef struct {
    // Status
    bool is_active;
    bool is_armed;
    distress_level_t current_level;
    distress_trigger_t last_trigger;
    time_t activation_time;
    time_t deadman_last_checkin;
    
    // Configuration
    distress_config_t config;
    
    // Targets and processes
    distress_target_t destroy_targets[DISTRESS_MAX_DESTROY_PATHS];
    uint32_t target_count;
    distress_decoy_process_t decoy_processes[DISTRESS_MAX_DECOY_PROCESSES];
    uint32_t decoy_count;
    
    // Statistics
    uint64_t total_bytes_destroyed;
    uint32_t files_destroyed;
    uint32_t directories_destroyed;
    uint32_t processes_terminated;
    uint32_t registry_keys_deleted;
    
    // Internal state
    HANDLE deadman_thread;
    HANDLE watcher_threads[DISTRESS_MAX_WATCHERS];
    uint32_t watcher_count;
    volatile bool shutdown_requested;
    CRITICAL_SECTION state_lock;
} distress_context_t;

// ========== CORE DISTRESS FUNCTIONS ==========

/**
 * Initialize distress mode system
 * Sets up watchers, deadman switches, and emergency protocols
 */
bool distress_initialize(distress_context_t* ctx, const distress_config_t* config);

/**
 * Arm the distress system
 * Activates all triggers and begins monitoring
 */
bool distress_arm(distress_context_t* ctx);

/**
 * Disarm the distress system safely
 * Requires safe word verification
 */
bool distress_disarm(distress_context_t* ctx, const char* safe_word);

/**
 * Manual distress activation
 * Immediate activation with specified level
 */
bool distress_activate(distress_context_t* ctx, distress_level_t level, 
                      distress_trigger_t trigger);

/**
 * Check if system is under duress
 * Returns true if distress mode is active
 */
bool distress_is_active(const distress_context_t* ctx);

/**
 * Get current distress status
 */
void distress_get_status(const distress_context_t* ctx, 
                        distress_destroy_status_t* status);

/**
 * Cleanup distress system
 * Safely shutdown all monitoring threads
 */
void distress_cleanup(distress_context_t* ctx);

// ========== TARGET MANAGEMENT ==========

/**
 * Add file/directory to destruction list
 * Higher priority targets are destroyed first
 */
bool distress_add_target(distress_context_t* ctx, const char* path, 
                        uint32_t priority, uint32_t passes);

/**
 * Add directory tree recursively
 */
bool distress_add_directory_tree(distress_context_t* ctx, const char* root_path, 
                                uint32_t priority, uint32_t passes);

/**
 * Remove target from destruction list
 */
bool distress_remove_target(distress_context_t* ctx, const char* path);

/**
 * Clear all destruction targets
 */
void distress_clear_targets(distress_context_t* ctx);

// ========== DESTRUCTION FUNCTIONS ==========

/**
 * Secure file destruction using multiple overwrite passes
 * Implements DOD 5220.22-M and Gutmann methods
 */
bool distress_destroy_file(const char* filepath, uint32_t passes, 
                          bool verify_destruction);

/**
 * Secure directory destruction (recursive)
 */
bool distress_destroy_directory(const char* dirpath, uint32_t passes, 
                               bool verify_destruction);

/**
 * Free space sanitization
 * Overwrites unallocated disk space
 */
bool distress_sanitize_free_space(const char* drive_letter, uint32_t passes);

/**
 * System file sanitization (pagefile, hibernation, etc.)
 */
bool distress_sanitize_system_files(void);

/**
 * Registry sanitization
 * Removes LACKYVPN traces from Windows registry
 */
bool distress_sanitize_registry(void);

/**
 * Memory sanitization
 * Overwrites process memory and forces garbage collection
 */
bool distress_sanitize_memory(void);

// ========== TRIGGER WATCHERS ==========

/**
 * USB dead man's switch watcher
 * Triggers if specific USB device is removed
 */
bool distress_setup_usb_watcher(distress_context_t* ctx, const char* usb_serial);

/**
 * Process termination watcher
 * Triggers if parent process is killed
 */
bool distress_setup_process_watcher(distress_context_t* ctx, uint32_t parent_pid);

/**
 * Network intrusion watcher
 * Monitors for scanning and forensic tools
 */
bool distress_setup_network_watcher(distress_context_t* ctx);

/**
 * Forensic tool detection watcher
 * Monitors for analysis tools (Wireshark, Volatility, etc.)
 */
bool distress_setup_forensic_watcher(distress_context_t* ctx);

/**
 * Keyboard panic sequence watcher
 * Monitors for rapid key sequences
 */
bool distress_setup_panic_key_watcher(distress_context_t* ctx);

/**
 * Deadman timer
 * Requires periodic check-ins to prevent activation
 */
bool distress_checkin_deadman(distress_context_t* ctx);

// ========== DECOY & STEALTH FUNCTIONS ==========

/**
 * Create decoy processes
 * Launches innocent-looking processes to mask activity
 */
bool distress_create_decoy_processes(distress_context_t* ctx);

/**
 * Process hollowing for stealth
 * Replaces legitimate process memory with LACKYVPN code
 */
bool distress_hollow_process(const char* target_exe, const void* payload, 
                            size_t payload_size);

/**
 * Anti-forensic timestamp manipulation
 * Modifies file creation/access times to throw off analysis
 */
bool distress_manipulate_timestamps(const char* filepath);

/**
 * Create false evidence trails
 * Plants decoy files and registry entries
 */
bool distress_create_false_trails(void);

// ========== EMERGENCY NETWORK FUNCTIONS ==========

/**
 * Emergency network cutoff
 * Disables all network interfaces immediately
 */
bool distress_cutoff_network(void);

/**
 * Firewall lockdown
 * Blocks all traffic except emergency channels
 */
bool distress_lockdown_firewall(void);

/**
 * DNS cache poisoning
 * Corrupts DNS cache to prevent forensic reconstruction
 */
bool distress_poison_dns_cache(void);

// ========== SYSTEM MODIFICATION FUNCTIONS ==========

/**
 * Disable Windows Event Logging
 * Stops and corrupts event log services
 */
bool distress_disable_event_logging(void);

/**
 * Corrupt system restore points
 * Destroys Windows system restore data
 */
bool distress_corrupt_restore_points(void);

/**
 * Modify system time
 * Throws off forensic timeline analysis
 */
bool distress_manipulate_system_time(void);

/**
 * Emergency system shutdown
 * Forces immediate system shutdown with memory clearing
 */
bool distress_emergency_shutdown(uint32_t delay_seconds);

// ========== UTILITY FUNCTIONS ==========

/**
 * Generate secure random data for overwriting
 */
void distress_generate_random_pattern(uint8_t* buffer, size_t size);

/**
 * Verify file destruction
 * Ensures data is actually overwritten
 */
bool distress_verify_destruction(const char* filepath);

/**
 * Get destruction progress
 */
float distress_get_progress(const distress_context_t* ctx);

/**
 * Log distress event (encrypted)
 */
void distress_log_event(distress_context_t* ctx, const char* event, 
                       distress_trigger_t trigger);

// ========== CRYPTO SUPPORT ==========

/**
 * Encrypt distress logs
 * Uses ChaCha20-Poly1305 with ephemeral keys
 */
bool distress_encrypt_log(const uint8_t* plaintext, size_t plain_len,
                         uint8_t* ciphertext, size_t* cipher_len,
                         const uint8_t* key);

/**
 * Secure key derivation for distress operations
 * Derives keys from VPN session and hardware entropy
 */
bool distress_derive_key(const uint8_t* master_key, size_t key_len,
                        const char* context, uint8_t* derived_key, 
                        size_t derived_len);

#ifdef __cplusplus
}
#endif

#endif // LACKYVPN_DISTRESS_MODE_H
