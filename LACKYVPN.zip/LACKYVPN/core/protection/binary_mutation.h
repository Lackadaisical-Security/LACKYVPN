/*
 * LACKYVPN Advanced Binary Mutation & Anti-Reverse Engineering Module
 * ==================================================================
 * 
 * Advanced protection against reverse engineering, binary analysis,
 * and code tampering. Includes runtime binary mutation, anti-debugging,
 * anti-VM detection, and code obfuscation.
 * 
 * Features:
 * - Runtime binary mutation
 * - Anti-debugging techniques
 * - Anti-VM and sandbox detection
 * - Code flow obfuscation
 * - Anti-static analysis
 * - Integrity verification
 * - Decoy code injection
 * 
 * Security Level: CLASSIFIED
 * Built by: Lackadaisical Security
 */

#ifndef BINARY_MUTATION_H
#define BINARY_MUTATION_H

#include <stdint.h>
#include <windows.h>
#include "../crypto/crypto_primitives.h"

// Mutation engine constants
#define MUTATION_BLOCK_SIZE         64
#define MUTATION_KEY_SIZE           32
#define MUTATION_SIGNATURE_SIZE     16
#define MAX_MUTATION_VARIANTS       256
#define ANTI_DEBUG_CHECK_INTERVAL   1000  // milliseconds

// Protection levels
typedef enum {
    PROTECTION_LEVEL_BASIC = 1,
    PROTECTION_LEVEL_ENHANCED = 2,
    PROTECTION_LEVEL_PARANOID = 3,
    PROTECTION_LEVEL_CLASSIFIED = 4
} protection_level_t;

// Mutation strategies
typedef enum {
    MUTATION_STRATEGY_NONE = 0,
    MUTATION_STRATEGY_XOR_ROTATE = 1,
    MUTATION_STRATEGY_POLYMORPHIC = 2,
    MUTATION_STRATEGY_METAMORPHIC = 3,
    MUTATION_STRATEGY_HYBRID = 4
} mutation_strategy_t;

// Anti-analysis techniques
typedef enum {
    ANTI_ANALYSIS_NONE = 0x00,
    ANTI_ANALYSIS_DEBUGGER = 0x01,
    ANTI_ANALYSIS_VM = 0x02,
    ANTI_ANALYSIS_SANDBOX = 0x04,
    ANTI_ANALYSIS_EMULATOR = 0x08,
    ANTI_ANALYSIS_PROFILER = 0x10,
    ANTI_ANALYSIS_DISASSEMBLER = 0x20,
    ANTI_ANALYSIS_ALL = 0xFF
} anti_analysis_flags_t;

// Code block mutation context
typedef struct {
    uint8_t* original_code;         // Original code block
    uint8_t* mutated_code;          // Mutated code block
    size_t code_size;               // Size of code block
    uint32_t mutation_key;          // Mutation key
    uint32_t variant_id;            // Current variant ID
    uint8_t signature[MUTATION_SIGNATURE_SIZE]; // Block signature
    BOOLEAN is_active;              // Block is currently active
} mutation_block_t;

// Binary mutation engine context
typedef struct {
    HMODULE base_module;            // Base module handle
    uint8_t* code_section;          // Pointer to code section
    size_t code_section_size;       // Size of code section
    mutation_block_t* blocks;       // Array of mutation blocks
    size_t block_count;             // Number of mutation blocks
    mutation_strategy_t strategy;   // Current mutation strategy
    uint32_t mutation_counter;      // Mutation counter
    uint64_t last_mutation_time;    // Last mutation timestamp
    BOOLEAN mutation_active;        // Mutation engine active
    
    // Anti-analysis contexts
    HANDLE anti_debug_thread;       // Anti-debugging thread
    uint32_t vm_detection_score;    // VM detection score
    BOOLEAN protection_active;      // Protection mechanisms active
    
    // Decoy and obfuscation
    uint8_t* decoy_functions;       // Decoy function pool
    size_t decoy_count;             // Number of decoy functions
    uint32_t obfuscation_mask;      // Code obfuscation mask
} binary_mutation_ctx_t;

// Anti-debugging detection structure
typedef struct {
    BOOLEAN debugger_present;
    BOOLEAN remote_debugger;
    BOOLEAN kernel_debugger;
    BOOLEAN hardware_breakpoints;
    BOOLEAN software_breakpoints;
    BOOLEAN single_step_flag;
    uint32_t detection_count;
} anti_debug_state_t;

// VM/Sandbox detection structure
typedef struct {
    BOOLEAN vm_detected;
    BOOLEAN sandbox_detected;
    BOOLEAN emulator_detected;
    uint32_t vm_indicators;
    uint32_t sandbox_indicators;
    char vm_vendor[64];
} vm_detection_state_t;

// Function prototypes
BOOLEAN binary_mutation_init(binary_mutation_ctx_t* ctx, protection_level_t level);
BOOLEAN binary_mutation_start(binary_mutation_ctx_t* ctx, mutation_strategy_t strategy);
BOOLEAN binary_mutation_stop(binary_mutation_ctx_t* ctx);
BOOLEAN binary_mutation_mutate_block(binary_mutation_ctx_t* ctx, size_t block_id);
BOOLEAN binary_mutation_restore_block(binary_mutation_ctx_t* ctx, size_t block_id);
void binary_mutation_cleanup(binary_mutation_ctx_t* ctx);

// Code mutation functions
BOOLEAN create_mutation_blocks(binary_mutation_ctx_t* ctx);
BOOLEAN apply_xor_rotation_mutation(mutation_block_t* block, uint32_t key);
BOOLEAN apply_polymorphic_mutation(mutation_block_t* block);
BOOLEAN apply_metamorphic_mutation(mutation_block_t* block);
BOOLEAN verify_block_integrity(mutation_block_t* block);

// Anti-debugging functions
BOOLEAN anti_debug_init(binary_mutation_ctx_t* ctx);
BOOLEAN anti_debug_check_all(anti_debug_state_t* state);
BOOLEAN anti_debug_check_peb(void);
BOOLEAN anti_debug_check_heap_flags(void);
BOOLEAN anti_debug_check_ntglobalflag(void);
BOOLEAN anti_debug_check_hardware_breakpoints(void);
BOOLEAN anti_debug_check_software_breakpoints(void);
BOOLEAN anti_debug_check_timing(void);
BOOLEAN anti_debug_check_exceptions(void);
DWORD WINAPI anti_debug_thread(LPVOID param);

// Anti-VM detection functions
BOOLEAN anti_vm_init(binary_mutation_ctx_t* ctx);
BOOLEAN anti_vm_detect_all(vm_detection_state_t* state);
BOOLEAN anti_vm_check_registry(void);
BOOLEAN anti_vm_check_files(void);
BOOLEAN anti_vm_check_processes(void);
BOOLEAN anti_vm_check_devices(void);
BOOLEAN anti_vm_check_mac_addresses(void);
BOOLEAN anti_vm_check_timing(void);
BOOLEAN anti_vm_check_cpu_features(void);
BOOLEAN anti_vm_check_memory_artifacts(void);

// Code obfuscation functions
BOOLEAN obfuscate_code_flow(binary_mutation_ctx_t* ctx);
BOOLEAN inject_decoy_functions(binary_mutation_ctx_t* ctx);
BOOLEAN scramble_function_order(binary_mutation_ctx_t* ctx);
BOOLEAN insert_junk_code(binary_mutation_ctx_t* ctx);

// Integrity verification
BOOLEAN verify_module_integrity(binary_mutation_ctx_t* ctx);
BOOLEAN calculate_section_hash(uint8_t* section, size_t size, uint8_t* hash);
BOOLEAN detect_code_modification(binary_mutation_ctx_t* ctx);

// Protection response functions
BOOLEAN trigger_protection_response(binary_mutation_ctx_t* ctx, uint32_t threat_level);
BOOLEAN execute_emergency_termination(void);
BOOLEAN activate_decoy_mode(binary_mutation_ctx_t* ctx);
BOOLEAN corrupt_analysis_tools(void);

// Utility functions
BOOLEAN is_running_under_debugger(void);
BOOLEAN is_running_in_vm(void);
BOOLEAN is_analysis_tool_present(void);
uint32_t calculate_protection_score(binary_mutation_ctx_t* ctx);

#endif // BINARY_MUTATION_H
