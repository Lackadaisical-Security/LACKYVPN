/*
 * LACKYVPN System Hardening Implementation
 * =======================================
 * 
 * Core system security lockdown implementation
 * Security Level: CLASSIFIED
 */

#include "system_hardening.h"
#include <stdio.h>
#include <stdlib.h>
#include <iphlpapi.h>

#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wininet.lib")

// Initialize the hardening engine
BOOLEAN init_hardening_engine(hardening_engine_t* engine, uint32_t flags) {
    if (!engine) return FALSE;
    
    memset(engine, 0, sizeof(hardening_engine_t));
    engine->hardening_flags = flags;
    
    // Set secure DNS servers (Quad9, Cloudflare, OpenDNS, Google)
    strcpy_s(engine->secure_dns_servers[0], 16, "9.9.9.9");
    strcpy_s(engine->secure_dns_servers[1], 16, "1.1.1.1");
    strcpy_s(engine->secure_dns_servers[2], 16, "208.67.222.222");
    strcpy_s(engine->secure_dns_servers[3], 16, "8.8.8.8");
    
    // Enumerate network adapters
    PIP_ADAPTER_INFO adapter_info = NULL;
    ULONG buffer_size = 0;
    
    // Get required buffer size
    GetAdaptersInfo(NULL, &buffer_size);
    adapter_info = (PIP_ADAPTER_INFO)malloc(buffer_size);
    
    if (adapter_info && GetAdaptersInfo(adapter_info, &buffer_size) == NO_ERROR) {
        PIP_ADAPTER_INFO current = adapter_info;
        engine->adapter_count = 0;
        
        while (current && engine->adapter_count < 16) {
            network_adapter_t* adapter = &engine->adapters[engine->adapter_count];
            
            strcpy_s(adapter->adapter_name, 256, current->AdapterName);
            strcpy_s(adapter->original_ip, 16, current->IpAddressList.IpAddress.String);
            
            // Format MAC address
            sprintf_s(adapter->original_mac, 18, "%02X:%02X:%02X:%02X:%02X:%02X",
                     current->Address[0], current->Address[1], current->Address[2],
                     current->Address[3], current->Address[4], current->Address[5]);
            
            adapter->is_vpn_adapter = (strstr(current->Description, "TAP") != NULL ||
                                     strstr(current->Description, "VPN") != NULL);
            
            engine->adapter_count++;
            current = current->Next;
        }
    }
    
    if (adapter_info) free(adapter_info);
    return TRUE;
}

// Apply comprehensive system hardening
BOOLEAN apply_system_hardening(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    BOOLEAN success = TRUE;
    
    // Apply each hardening measure based on flags
    if (engine->hardening_flags & HARDEN_DNS_LEAKS) {
        success &= secure_dns_configuration(engine);
    }
    
    if (engine->hardening_flags & HARDEN_SMB_NETBIOS) {
        success &= disable_smb_netbios(engine);
    }
    
    if (engine->hardening_flags & HARDEN_WPAD_DISABLE) {
        success &= disable_wpad_autodiscovery(engine);
    }
    
    if (engine->hardening_flags & HARDEN_MAC_RANDOMIZE) {
        success &= randomize_mac_addresses(engine);
    }
    
    if (engine->hardening_flags & HARDEN_FIREWALL_RULES) {
        success &= create_firewall_rules(engine);
    }
    
    if (engine->hardening_flags & HARDEN_REGISTRY_LOCK) {
        success &= lock_registry_keys(engine);
    }
    
    if (engine->hardening_flags & HARDEN_TPM_VERIFY) {
        success &= verify_tpm_security(engine);
    }
    
    if (engine->hardening_flags & HARDEN_UEFI_CHECK) {
        success &= check_uefi_integrity(engine);
    }
    
    // Configure kill switch as final step
    success &= configure_kill_switch(engine);
    
    return success;
}

// Secure DNS configuration to prevent leaks
BOOLEAN secure_dns_configuration(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Disable Windows DNS client service temporarily
    SC_HANDLE scm = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (!scm) return FALSE;
    
    SC_HANDLE dns_service = OpenService(scm, L"Dnscache", SERVICE_ALL_ACCESS);
    if (dns_service) {
        SERVICE_STATUS status;
        ControlService(dns_service, SERVICE_CONTROL_STOP, &status);
        CloseServiceHandle(dns_service);
    }
    
    // Flush DNS cache
    system("ipconfig /flushdns");
    
    // Set secure DNS servers via registry
    HKEY key;
    const char* reg_path = "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters";
    
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, reg_path, 0, KEY_SET_VALUE, &key) == ERROR_SUCCESS) {
        // Set primary DNS servers
        char dns_list[64];
        sprintf_s(dns_list, 64, "%s,%s", engine->secure_dns_servers[0], engine->secure_dns_servers[1]);
        
        RegSetValueExA(key, "NameServer", 0, REG_SZ, (BYTE*)dns_list, (DWORD)strlen(dns_list) + 1);
        
        // Disable DNS over HTTPS for control
        DWORD disable_doh = 1;
        RegSetValueExA(key, "DisableDOH", 0, REG_DWORD, (BYTE*)&disable_doh, sizeof(DWORD));
        
        RegCloseKey(key);
    }
    
    // Restart DNS service with new configuration
    if (dns_service) {
        StartService(dns_service, 0, NULL);
    }
    
    CloseServiceHandle(scm);
    engine->dns_secured = TRUE;
    
    return TRUE;
}

// Disable SMB and NetBIOS to prevent leaks
BOOLEAN disable_smb_netbios(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Disable NetBIOS over TCP/IP
    HKEY key;
    const char* reg_path = "SYSTEM\\CurrentControlSet\\Services\\NetBT\\Parameters\\Interfaces";
    
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, reg_path, 0, KEY_ENUMERATE_SUB_KEYS, &key) == ERROR_SUCCESS) {
        DWORD index = 0;
        char subkey_name[256];
        DWORD name_size = 256;
        
        while (RegEnumKeyExA(key, index, subkey_name, &name_size, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
            char full_path[512];
            sprintf_s(full_path, 512, "%s\\%s", reg_path, subkey_name);
            
            HKEY interface_key;
            if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, full_path, 0, KEY_SET_VALUE, &interface_key) == ERROR_SUCCESS) {
                // Disable NetBIOS (2 = disable)
                DWORD disable_netbios = 2;
                RegSetValueExA(interface_key, "NetbiosOptions", 0, REG_DWORD, 
                              (BYTE*)&disable_netbios, sizeof(DWORD));
                RegCloseKey(interface_key);
            }
            
            index++;
            name_size = 256;
        }
        
        RegCloseKey(key);
    }
    
    // Disable SMB1 protocol
    system("dism /online /Disable-Feature /FeatureName:SMB1Protocol /NoRestart");
    
    return TRUE;
}

// Disable WPAD auto-discovery
BOOLEAN disable_wpad_autodiscovery(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    HKEY key;
    const char* reg_path = "SYSTEM\\CurrentControlSet\\Services\\WinHttpAutoProxySvc";
    
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, reg_path, 0, KEY_SET_VALUE, &key) == ERROR_SUCCESS) {
        // Disable WPAD service
        DWORD start_type = 4; // SERVICE_DISABLED
        RegSetValueExA(key, "Start", 0, REG_DWORD, (BYTE*)&start_type, sizeof(DWORD));
        RegCloseKey(key);
    }
    
    // Disable automatic proxy detection in Internet Explorer
    const char* ie_reg_path = "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
    if (RegOpenKeyExA(HKEY_CURRENT_USER, ie_reg_path, 0, KEY_SET_VALUE, &key) == ERROR_SUCCESS) {
        DWORD auto_detect = 0;
        RegSetValueExA(key, "AutoDetect", 0, REG_DWORD, (BYTE*)&auto_detect, sizeof(DWORD));
        RegCloseKey(key);
    }
    
    return TRUE;
}

// Randomize MAC addresses for privacy
BOOLEAN randomize_mac_addresses(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    srand((unsigned int)time(NULL));
    
    for (uint32_t i = 0; i < engine->adapter_count; i++) {
        network_adapter_t* adapter = &engine->adapters[i];
        
        // Don't randomize VPN adapters
        if (adapter->is_vpn_adapter) continue;
        
        // Generate random MAC with locally administered bit set
        uint8_t new_mac[6];
        new_mac[0] = 0x02 | (rand() & 0xFC); // Locally administered
        for (int j = 1; j < 6; j++) {
            new_mac[j] = rand() & 0xFF;
        }
        
        sprintf_s(adapter->randomized_mac, 18, "%02X:%02X:%02X:%02X:%02X:%02X",
                 new_mac[0], new_mac[1], new_mac[2], new_mac[3], new_mac[4], new_mac[5]);
        
        // Apply MAC address change via registry (requires admin privileges)
        char reg_path[512];
        sprintf_s(reg_path, 512, "SYSTEM\\CurrentControlSet\\Control\\Class\\{4D36E972-E325-11CE-BFC1-08002BE10318}\\%04d", i);
        
        HKEY key;
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, reg_path, 0, KEY_SET_VALUE, &key) == ERROR_SUCCESS) {
            char mac_string[13];
            sprintf_s(mac_string, 13, "%02X%02X%02X%02X%02X%02X",
                     new_mac[0], new_mac[1], new_mac[2], new_mac[3], new_mac[4], new_mac[5]);
            
            RegSetValueExA(key, "NetworkAddress", 0, REG_SZ, (BYTE*)mac_string, 13);
            RegCloseKey(key);
        }
    }
    
    return TRUE;
}

// Configure VPN kill switch
BOOLEAN configure_kill_switch(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Create Windows Firewall rules to block all traffic except VPN
    char cmd[512];
    
    // Block all outbound traffic by default
    sprintf_s(cmd, 512, "netsh advfirewall set allprofiles firewallpolicy blockinbound,blockoutbound");
    system(cmd);
    
    // Allow VPN application
    sprintf_s(cmd, 512, "netsh advfirewall firewall add rule name=\"LACKYVPN_Allow\" dir=out action=allow program=\"%%ProgramFiles%%\\LACKYVPN\\lackyvpn.exe\"");
    system(cmd);
    
    // Allow local network communication
    sprintf_s(cmd, 512, "netsh advfirewall firewall add rule name=\"LACKYVPN_Local\" dir=out action=allow remoteip=10.0.0.0/8,172.16.0.0/12,192.168.0.0/16");
    system(cmd);
    
    engine->kill_switch_active = TRUE;
    engine->firewall_configured = TRUE;
    
    return TRUE;
}

// Verify TPM security module
BOOLEAN verify_tpm_security(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Check TPM presence and status
    HKEY key;
    const char* tpm_reg_path = "SYSTEM\\CurrentControlSet\\Services\\TPM";
    
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, tpm_reg_path, 0, KEY_READ, &key) == ERROR_SUCCESS) {
        // TPM is present - verify it's enabled and accessible
        RegCloseKey(key);
        
        // Additional TPM verification would go here
        // This might include checking TPM 2.0 capabilities, attestation, etc.
        
        return TRUE;
    }
    
    return FALSE; // No TPM found
}

// Check UEFI integrity
BOOLEAN check_uefi_integrity(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Verify Secure Boot status
    HKEY key;
    const char* secureboot_path = "SYSTEM\\CurrentControlSet\\Control\\SecureBoot\\State";
    
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, secureboot_path, 0, KEY_READ, &key) == ERROR_SUCCESS) {
        DWORD secure_boot_enabled;
        DWORD data_size = sizeof(DWORD);
        
        if (RegQueryValueExA(key, "UEFISecureBootEnabled", NULL, NULL, 
                           (BYTE*)&secure_boot_enabled, &data_size) == ERROR_SUCCESS) {
            RegCloseKey(key);
            return (secure_boot_enabled == 1);
        }
        
        RegCloseKey(key);
    }
    
    return FALSE;
}

// Lock critical registry keys
BOOLEAN lock_registry_keys(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // This would implement registry key protection
    // Preventing unauthorized modifications to network settings
    
    return TRUE;
}

// Create comprehensive firewall rules
BOOLEAN create_firewall_rules(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Already implemented in configure_kill_switch
    return configure_kill_switch(engine);
}

// Monitor for network leaks
BOOLEAN monitor_network_leaks(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    BOOLEAN leaks_detected = FALSE;
    
    leaks_detected |= detect_dns_leak(engine);
    leaks_detected |= detect_webrtc_leak(engine);
    leaks_detected |= detect_ipv6_leak(engine);
    
    if (leaks_detected) {
        // Activate emergency procedures
        emergency_network_shutdown(engine);
    }
    
    return !leaks_detected;
}

// Detect DNS leaks
BOOLEAN detect_dns_leak(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Implementation would check if DNS queries are going through VPN
    // This is a placeholder for the actual leak detection logic
    
    return FALSE; // No leak detected
}

// Emergency network shutdown
BOOLEAN emergency_network_shutdown(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Immediately block all network traffic
    system("netsh interface set interface \"Wi-Fi\" admin=disable");
    system("netsh interface set interface \"Ethernet\" admin=disable");
    
    return TRUE;
}

// Restore system state
BOOLEAN restore_system_state(hardening_engine_t* engine) {
    if (!engine) return FALSE;
    
    // Restore original DNS settings
    if (engine->dns_secured) {
        HKEY key;
        const char* reg_path = "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters";
        
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, reg_path, 0, KEY_SET_VALUE, &key) == ERROR_SUCCESS) {
            RegDeleteValueA(key, "NameServer");
            RegCloseKey(key);
        }
    }
    
    // Restore firewall settings
    if (engine->firewall_configured) {
        system("netsh advfirewall reset");
    }
    
    // Restore MAC addresses
    for (uint32_t i = 0; i < engine->adapter_count; i++) {
        // Restore original MAC addresses if changed
        // Implementation would reverse the MAC randomization
    }
    
    return TRUE;
}

// Clean destruction
void destroy_hardening_engine(hardening_engine_t* engine) {
    if (!engine) return;
    
    // Restore system state before destruction
    restore_system_state(engine);
    
    // Terminate monitoring thread if running
    if (engine->hardening_thread) {
        TerminateThread(engine->hardening_thread, 0);
        CloseHandle(engine->hardening_thread);
    }
    
    // Securely wipe engine data
    SecureZeroMemory(engine, sizeof(hardening_engine_t));
}
