/*
 * LACKYVPN System Hardening Engine
 * ================================
 * 
 * Comprehensive system lockdown before VPN initialization
 * Prevents DNS leaks, secures network stack, implements kill-switch
 * 
 * Security Level: CLASSIFIED
 * Built by: Lackadaisical Security
 */

#ifndef SYSTEM_HARDENING_H
#define SYSTEM_HARDENING_H

#include <windows.h>
#include <wininet.h>
#include <iphlpapi.h>
#include <ws2tcpip.h>

// System hardening flags
#define HARDEN_DNS_LEAKS         0x0001
#define HARDEN_SMB_NETBIOS       0x0002
#define HARDEN_WPAD_DISABLE      0x0004
#define HARDEN_MAC_RANDOMIZE     0x0008
#define HARDEN_FIREWALL_RULES    0x0010
#define HARDEN_REGISTRY_LOCK     0x0020
#define HARDEN_TPM_VERIFY        0x0040
#define HARDEN_UEFI_CHECK        0x0080

// Network interface information
typedef struct {
    char adapter_name[256];
    char original_mac[18];
    char randomized_mac[18];
    char original_ip[16];
    char vpn_ip[16];
    BOOLEAN is_vpn_adapter;
    BOOLEAN is_hardened;
} network_adapter_t;

// System hardening context
typedef struct {
    uint32_t hardening_flags;
    network_adapter_t adapters[16];
    uint32_t adapter_count;
    BOOLEAN kill_switch_active;
    BOOLEAN dns_secured;
    BOOLEAN firewall_configured;
    HANDLE hardening_thread;
    char secure_dns_servers[4][16]; // Quad9, Cloudflare, etc.
} hardening_engine_t;

// Function prototypes
BOOLEAN init_hardening_engine(hardening_engine_t* engine, uint32_t flags);
BOOLEAN apply_system_hardening(hardening_engine_t* engine);
BOOLEAN secure_dns_configuration(hardening_engine_t* engine);
BOOLEAN disable_smb_netbios(hardening_engine_t* engine);
BOOLEAN disable_wpad_autodiscovery(hardening_engine_t* engine);
BOOLEAN randomize_mac_addresses(hardening_engine_t* engine);
BOOLEAN configure_kill_switch(hardening_engine_t* engine);
BOOLEAN verify_tpm_security(hardening_engine_t* engine);
BOOLEAN check_uefi_integrity(hardening_engine_t* engine);
BOOLEAN lock_registry_keys(hardening_engine_t* engine);
BOOLEAN create_firewall_rules(hardening_engine_t* engine);
BOOLEAN monitor_network_leaks(hardening_engine_t* engine);
BOOLEAN restore_system_state(hardening_engine_t* engine);
void destroy_hardening_engine(hardening_engine_t* engine);

// Network monitoring
BOOLEAN detect_dns_leak(hardening_engine_t* engine);
BOOLEAN detect_webrtc_leak(hardening_engine_t* engine);
BOOLEAN detect_ipv6_leak(hardening_engine_t* engine);

// Emergency procedures
BOOLEAN emergency_network_shutdown(hardening_engine_t* engine);
BOOLEAN activate_kill_switch(hardening_engine_t* engine);

// TPM/UEFI security
BOOLEAN verify_hardware_trust_base(hardening_engine_t* engine);

#endif // SYSTEM_HARDENING_H
