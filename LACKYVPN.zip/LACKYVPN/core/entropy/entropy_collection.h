/**
 * LACKYVPN - Advanced Entropy Collection & Secure RNG Header
 * ==========================================================
 * 
 * Production-ready entropy collection system with multiple sources,
 * health monitoring, and cryptographically secure random number generation.
 * 
 * Entropy Sources:
 * - Hardware RNG (Intel RDRAND/RDSEED, AMD TrueRNG)
 * - Windows Crypto API (CryptGenRandom, BCryptGenRandom)
 * - High-resolution timing jitter
 * - System state collection (memory, CPU, disk, network)
 * - User interaction patterns
 * - Environmental noise (temperature, voltage fluctuations)
 * - Thread scheduling entropy
 * - Interrupt timing variations
 * 
 * Security Features:
 * - Entropy health monitoring and validation
 * - Catastrophic failure detection and recovery
 * - Forward secrecy through continuous reseeding
 * - Anti-replay protection
 * - Secure memory wiping
 * - Hardware acceleration detection
 * - FIPS 140-2 compliance readiness
 * 
 * Security Level: CLASSIFIED
 * Built by: Lackadaisical Security
 */

#ifndef LACKYVPN_ENTROPY_COLLECTION_H
#define LACKYVPN_ENTROPY_COLLECTION_H

#include <windows.h>
#include <stdint.h>
#include <stdbool.h>
#include <bcrypt.h>

#ifdef __cplusplus
extern "C" {
#endif

// ========== CONSTANTS ==========

#define LACKYVPN_ENTROPY_POOL_SIZE 4096        // 4KB entropy pool
#define LACKYVPN_ENTROPY_MIN_THRESHOLD 256     // Minimum entropy bits required
#define LACKYVPN_ENTROPY_RESEED_THRESHOLD 1024 // Reseed when below this
#define LACKYVPN_ENTROPY_MAX_REQUEST 1048576   // 1MB maximum single request
#define LACKYVPN_ENTROPY_HEALTH_SAMPLES 100    // Samples for health testing
#define LACKYVPN_ENTROPY_COLLECTOR_COUNT 16    // Number of entropy collectors

// Hardware RNG support
#define LACKYVPN_ENTROPY_RDRAND_AVAILABLE 0x01
#define LACKYVPN_ENTROPY_RDSEED_AVAILABLE 0x02
#define LACKYVPN_ENTROPY_BCrypt_AVAILABLE 0x04
#define LACKYVPN_ENTROPY_WINCRYPTO_AVAILABLE 0x08

// Entropy source types
#define LACKYVPN_ENTROPY_SOURCE_HARDWARE 0x01
#define LACKYVPN_ENTROPY_SOURCE_SYSTEM 0x02
#define LACKYVPN_ENTROPY_SOURCE_TIMING 0x04
#define LACKYVPN_ENTROPY_SOURCE_USER 0x08
#define LACKYVPN_ENTROPY_SOURCE_NETWORK 0x10
#define LACKYVPN_ENTROPY_SOURCE_ENVIRONMENTAL 0x20

// Health test constants
#define LACKYVPN_ENTROPY_REPETITION_CUTOFF 6
#define LACKYVPN_ENTROPY_ADAPTIVE_CUTOFF 325
#define LACKYVPN_ENTROPY_MIN_ENTROPY_RATE 0.5f

// ========== ENUMERATIONS ==========

typedef enum {
    LACKYVPN_ENTROPY_SUCCESS = 0,
    LACKYVPN_ENTROPY_ERROR_INIT = -1,
    LACKYVPN_ENTROPY_ERROR_INSUFFICIENT = -2,
    LACKYVPN_ENTROPY_ERROR_HEALTH_FAILED = -3,
    LACKYVPN_ENTROPY_ERROR_HARDWARE = -4,
    LACKYVPN_ENTROPY_ERROR_MEMORY = -5,
    LACKYVPN_ENTROPY_ERROR_CATASTROPHIC = -6,
    LACKYVPN_ENTROPY_ERROR_TIMEOUT = -7,
    LACKYVPN_ENTROPY_ERROR_INVALID_SIZE = -8
} lackyvpn_entropy_result_t;

typedef enum {
    LACKYVPN_ENTROPY_HEALTH_EXCELLENT = 0,
    LACKYVPN_ENTROPY_HEALTH_GOOD = 1,
    LACKYVPN_ENTROPY_HEALTH_WARNING = 2,
    LACKYVPN_ENTROPY_HEALTH_CRITICAL = 3,
    LACKYVPN_ENTROPY_HEALTH_FAILED = 4
} lackyvpn_entropy_health_t;

typedef enum {
    LACKYVPN_ENTROPY_STATE_UNINITIALIZED = 0,
    LACKYVPN_ENTROPY_STATE_INITIALIZING = 1,
    LACKYVPN_ENTROPY_STATE_SEEDED = 2,
    LACKYVPN_ENTROPY_STATE_OPERATIONAL = 3,
    LACKYVPN_ENTROPY_STATE_WARNING = 4,
    LACKYVPN_ENTROPY_STATE_CRITICAL = 5,
    LACKYVPN_ENTROPY_STATE_FAILED = 6
} lackyvpn_entropy_state_t;

// ========== STRUCTURES ==========

// Entropy source collector
typedef struct {
    uint32_t source_id;
    uint32_t source_type;
    char name[64];
    bool is_available;
    bool is_active;
    uint64_t bytes_collected;
    uint64_t collection_count;
    float entropy_rate;
    time_t last_collection;
    uint32_t failure_count;
    uint32_t consecutive_failures;
    
    // Health statistics
    uint32_t repetition_failures;
    uint32_t adaptive_failures;
    float min_entropy_rate;
    float max_entropy_rate;
    float avg_entropy_rate;
    
    // Collector-specific data
    void* collector_data;
    
    // Function pointers
    lackyvpn_entropy_result_t (*collect_entropy)(void* data, uint8_t* buffer, size_t size, float* entropy_rate);
    void (*cleanup)(void* data);
    
} lackyvpn_entropy_collector_t;

// Entropy pool structure
typedef struct {
    uint8_t pool[LACKYVPN_ENTROPY_POOL_SIZE];
    uint32_t pool_index;
    uint32_t entropy_bits;
    uint64_t total_entropy_added;
    uint64_t total_entropy_extracted;
    time_t last_reseed;
    uint32_t reseed_count;
    CRITICAL_SECTION pool_lock;
} lackyvpn_entropy_pool_t;

// Hardware RNG context
typedef struct {
    bool rdrand_available;
    bool rdseed_available;
    bool bcrypt_available;
    bool wincrypto_available;
    uint32_t hardware_capabilities;
    
    // BCrypt provider handles
    BCRYPT_ALG_HANDLE bcrypt_rng_handle;
    HCRYPTPROV wincrypto_handle;
    
    // Performance counters
    uint64_t rdrand_calls;
    uint64_t rdseed_calls;
    uint64_t bcrypt_calls;
    uint64_t wincrypto_calls;
    
    uint64_t rdrand_failures;
    uint64_t rdseed_failures;
    uint64_t bcrypt_failures;
    uint64_t wincrypto_failures;
    
} lackyvpn_entropy_hardware_t;

// Health testing context
typedef struct {
    // Statistical tests
    uint32_t repetition_count;
    uint32_t adaptive_proportion_count;
    uint8_t last_sample;
    uint32_t window_size;
    
    // Test results
    bool repetition_test_passed;
    bool adaptive_test_passed;
    bool health_tests_enabled;
    
    // Continuous monitoring
    float current_entropy_rate;
    float min_entropy_rate;
    float max_entropy_rate;
    uint32_t total_samples;
    uint32_t failed_samples;
    
    // Thresholds
    uint32_t repetition_cutoff;
    uint32_t adaptive_cutoff;
    float min_entropy_threshold;
    
} lackyvpn_entropy_health_t;

// Main entropy collection context
typedef struct {
    // System state
    lackyvpn_entropy_state_t state;
    bool is_initialized;
    bool is_operational;
    time_t initialization_time;
    
    // Entropy pool
    lackyvpn_entropy_pool_t entropy_pool;
    
    // Hardware RNG
    lackyvpn_entropy_hardware_t hardware;
    
    // Entropy collectors
    lackyvpn_entropy_collector_t collectors[LACKYVPN_ENTROPY_COLLECTOR_COUNT];
    uint32_t collector_count;
    uint32_t active_collectors;
    
    // Health monitoring
    lackyvpn_entropy_health_t health_monitor;
    lackyvpn_entropy_health_t overall_health;
    
    // Performance and statistics
    uint64_t total_requests;
    uint64_t total_bytes_generated;
    uint64_t failed_requests;
    time_t last_health_check;
    
    // Security settings
    bool require_hardware_entropy;
    bool enable_health_tests;
    bool enable_continuous_monitoring;
    uint32_t min_entropy_sources;
    uint32_t catastrophic_failure_threshold;
    
    // Threading and synchronization
    HANDLE collection_thread;
    HANDLE health_monitor_thread;
    HANDLE shutdown_event;
    bool threads_running;
    CRITICAL_SECTION entropy_lock;
    
} lackyvpn_entropy_context_t;

// Entropy source initialization parameters
typedef struct {
    uint32_t source_type;
    char name[64];
    bool required;
    uint32_t collection_interval_ms;
    uint32_t max_failure_count;
    void* init_params;
} lackyvpn_entropy_source_config_t;

// ========== CORE FUNCTIONS ==========

/**
 * Initialize entropy collection system
 */
lackyvpn_entropy_result_t lackyvpn_entropy_init(lackyvpn_entropy_context_t* ctx);

/**
 * Start entropy collection threads and services
 */
lackyvpn_entropy_result_t lackyvpn_entropy_start(lackyvpn_entropy_context_t* ctx);

/**
 * Stop entropy collection and cleanup
 */
lackyvpn_entropy_result_t lackyvpn_entropy_stop(lackyvpn_entropy_context_t* ctx);

/**
 * Cleanup entropy context
 */
void lackyvpn_entropy_cleanup(lackyvpn_entropy_context_t* ctx);

// ========== RANDOM NUMBER GENERATION ==========

/**
 * Generate cryptographically secure random bytes
 */
lackyvpn_entropy_result_t lackyvpn_entropy_generate(lackyvpn_entropy_context_t* ctx, 
    uint8_t* buffer, size_t size);

/**
 * Generate random bytes with specific entropy requirements
 */
lackyvpn_entropy_result_t lackyvpn_entropy_generate_with_requirement(lackyvpn_entropy_context_t* ctx, 
    uint8_t* buffer, size_t size, uint32_t min_entropy_bits);

/**
 * Generate random integer in range [0, max)
 */
lackyvpn_entropy_result_t lackyvpn_entropy_generate_range(lackyvpn_entropy_context_t* ctx, 
    uint32_t max, uint32_t* result);

/**
 * Generate random bytes using only hardware sources
 */
lackyvpn_entropy_result_t lackyvpn_entropy_generate_hardware_only(lackyvpn_entropy_context_t* ctx, 
    uint8_t* buffer, size_t size);

// ========== ENTROPY COLLECTION ==========

/**
 * Add entropy to the pool from external source
 */
lackyvpn_entropy_result_t lackyvpn_entropy_add_data(lackyvpn_entropy_context_t* ctx, 
    const uint8_t* data, size_t size, float entropy_estimate);

/**
 * Force immediate entropy collection from all sources
 */
lackyvpn_entropy_result_t lackyvpn_entropy_collect_immediate(lackyvpn_entropy_context_t* ctx);

/**
 * Reseed entropy pool with fresh entropy
 */
lackyvpn_entropy_result_t lackyvpn_entropy_reseed(lackyvpn_entropy_context_t* ctx);

// ========== ENTROPY SOURCES ==========

/**
 * Register custom entropy source
 */
lackyvpn_entropy_result_t lackyvpn_entropy_register_source(lackyvpn_entropy_context_t* ctx, 
    const lackyvpn_entropy_source_config_t* config,
    lackyvpn_entropy_result_t (*collector)(void*, uint8_t*, size_t, float*),
    void (*cleanup)(void*), void* source_data);

/**
 * Enable/disable specific entropy source
 */
lackyvpn_entropy_result_t lackyvpn_entropy_set_source_active(lackyvpn_entropy_context_t* ctx, 
    uint32_t source_id, bool active);

/**
 * Get entropy source statistics
 */
lackyvpn_entropy_result_t lackyvpn_entropy_get_source_stats(lackyvpn_entropy_context_t* ctx, 
    uint32_t source_id, lackyvpn_entropy_collector_t* stats);

// ========== HEALTH MONITORING ==========

/**
 * Perform comprehensive health check
 */
lackyvpn_entropy_result_t lackyvpn_entropy_health_check(lackyvpn_entropy_context_t* ctx, 
    lackyvpn_entropy_health_t* health_status);

/**
 * Enable/disable continuous health monitoring
 */
lackyvpn_entropy_result_t lackyvpn_entropy_set_health_monitoring(lackyvpn_entropy_context_t* ctx, 
    bool enable);

/**
 * Get detailed health report
 */
lackyvpn_entropy_result_t lackyvpn_entropy_get_health_report(lackyvpn_entropy_context_t* ctx, 
    char* report_buffer, size_t buffer_size);

// ========== HARDWARE RNG ==========

/**
 * Detect available hardware RNG capabilities
 */
lackyvpn_entropy_result_t lackyvpn_entropy_detect_hardware(lackyvpn_entropy_context_t* ctx);

/**
 * Test hardware RNG functionality
 */
lackyvpn_entropy_result_t lackyvpn_entropy_test_hardware(lackyvpn_entropy_context_t* ctx, 
    uint32_t test_size);

/**
 * Get hardware RNG statistics
 */
lackyvpn_entropy_result_t lackyvpn_entropy_get_hardware_stats(lackyvpn_entropy_context_t* ctx, 
    lackyvpn_entropy_hardware_t* hardware_stats);

// ========== UTILITY FUNCTIONS ==========

/**
 * Get entropy pool status
 */
lackyvpn_entropy_result_t lackyvpn_entropy_get_pool_status(lackyvpn_entropy_context_t* ctx, 
    uint32_t* available_entropy, uint32_t* pool_usage);

/**
 * Get comprehensive system statistics
 */
lackyvpn_entropy_result_t lackyvpn_entropy_get_statistics(lackyvpn_entropy_context_t* ctx, 
    uint64_t* total_requests, uint64_t* total_bytes, uint64_t* failed_requests,
    uint32_t* active_sources, time_t* last_reseed);

/**
 * Estimate entropy rate of data
 */
float lackyvpn_entropy_estimate_entropy(const uint8_t* data, size_t size);

/**
 * Secure memory clearing
 */
void lackyvpn_entropy_secure_zero(void* ptr, size_t size);

/**
 * Test entropy quality
 */
bool lackyvpn_entropy_test_quality(const uint8_t* data, size_t size, float* entropy_rate);

// ========== BUILT-IN ENTROPY COLLECTORS ==========

/**
 * Hardware RNG collector (RDRAND/RDSEED)
 */
lackyvpn_entropy_result_t lackyvpn_entropy_collect_hardware(void* data, uint8_t* buffer, size_t size, float* entropy_rate);

/**
 * System timing jitter collector
 */
lackyvpn_entropy_result_t lackyvpn_entropy_collect_timing(void* data, uint8_t* buffer, size_t size, float* entropy_rate);

/**
 * System state collector (memory, CPU, etc.)
 */
lackyvpn_entropy_result_t lackyvpn_entropy_collect_system_state(void* data, uint8_t* buffer, size_t size, float* entropy_rate);

/**
 * Network timing collector
 */
lackyvpn_entropy_result_t lackyvpn_entropy_collect_network_timing(void* data, uint8_t* buffer, size_t size, float* entropy_rate);

/**
 * Thread scheduling entropy collector
 */
lackyvpn_entropy_result_t lackyvpn_entropy_collect_thread_scheduling(void* data, uint8_t* buffer, size_t size, float* entropy_rate);

/**
 * User interaction pattern collector
 */
lackyvpn_entropy_result_t lackyvpn_entropy_collect_user_interaction(void* data, uint8_t* buffer, size_t size, float* entropy_rate);

#ifdef __cplusplus
}
#endif

#endif // LACKYVPN_ENTROPY_COLLECTION_H
