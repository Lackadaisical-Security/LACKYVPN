/*
 * LACKYVPN Cryptographic Primitives Library
 * ========================================
 * 
 * Zero-dependency cryptographic implementations for LACKYVPN.
 * Includes Classical, Quantum, Quantum-Resistant, and Quantum-Safe algorithms.
 * 
 * Security Level: CLASSIFIED
 * Implementation: Assembly/C optimized
 * Built by: Lackadaisical Security
 */

#ifndef CRYPTO_PRIMITIVES_H
#define CRYPTO_PRIMITIVES_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

// Crypto context sizes and constants
#define LACKYVPN_AES_BLOCK_SIZE     16
#define LACKYVPN_AES_KEY_SIZE_128   16
#define LACKYVPN_AES_KEY_SIZE_192   24
#define LACKYVPN_AES_KEY_SIZE_256   32

#define LACKYVPN_CHACHA_KEY_SIZE    32
#define LACKYVPN_CHACHA_NONCE_SIZE  12
#define LACKYVPN_CHACHA_BLOCK_SIZE  64

#define LACKYVPN_SHA256_DIGEST_SIZE 32
#define LACKYVPN_SHA512_DIGEST_SIZE 64
#define LACKYVPN_SHA3_256_SIZE      32
#define LACKYVPN_SHA3_512_SIZE      64

#define LACKYVPN_POLY1305_TAG_SIZE  16
#define LACKYVPN_HMAC_MAX_KEY_SIZE  128

#define LACKYVPN_ECC_P256_SIZE      32
#define LACKYVPN_ECC_P384_SIZE      48
#define LACKYVPN_ECC_P521_SIZE      66

#define LACKYVPN_RSA_2048_SIZE      256
#define LACKYVPN_RSA_4096_SIZE      512

// Quantum-resistant parameters
#define LACKYVPN_KYBER_512_PK_SIZE  800
#define LACKYVPN_KYBER_512_SK_SIZE  1632
#define LACKYVPN_KYBER_512_CT_SIZE  768
#define LACKYVPN_KYBER_512_SS_SIZE  32

#define LACKYVPN_DILITHIUM_2_PK_SIZE 1312
#define LACKYVPN_DILITHIUM_2_SK_SIZE 2528
#define LACKYVPN_DILITHIUM_2_SIG_SIZE 2420

// Algorithm identifiers
typedef enum {
    LACKYVPN_ALGO_AES_128_GCM = 0x01,
    LACKYVPN_ALGO_AES_256_GCM = 0x02,
    LACKYVPN_ALGO_CHACHA20_POLY1305 = 0x03,
    LACKYVPN_ALGO_AES_256_XTS = 0x04,
    
    // Post-quantum algorithms
    LACKYVPN_ALGO_KYBER_512 = 0x10,
    LACKYVPN_ALGO_KYBER_768 = 0x11,
    LACKYVPN_ALGO_KYBER_1024 = 0x12,
    
    LACKYVPN_ALGO_DILITHIUM_2 = 0x20,
    LACKYVPN_ALGO_DILITHIUM_3 = 0x21,
    LACKYVPN_ALGO_DILITHIUM_5 = 0x22,
    
    // Hash functions
    LACKYVPN_ALGO_SHA256 = 0x30,
    LACKYVPN_ALGO_SHA512 = 0x31,
    LACKYVPN_ALGO_SHA3_256 = 0x32,
    LACKYVPN_ALGO_SHA3_512 = 0x33,
    LACKYVPN_ALGO_BLAKE3 = 0x34,
    
    // ECC
    LACKYVPN_ALGO_ECDSA_P256 = 0x40,
    LACKYVPN_ALGO_ECDSA_P384 = 0x41,
    LACKYVPN_ALGO_ECDH_P256 = 0x42,
    LACKYVPN_ALGO_ED25519 = 0x43,
    LACKYVPN_ALGO_X25519 = 0x44,
    
    // RSA
    LACKYVPN_ALGO_RSA_2048 = 0x50,
    LACKYVPN_ALGO_RSA_4096 = 0x51
} lackyvpn_algorithm_t;

// Encryption operation modes
typedef enum {
    LACKYVPN_CRYPTO_MODE_ENCRYPT,
    LACKYVPN_CRYPTO_MODE_DECRYPT
} lackyvpn_crypto_mode_t;

// Key types
typedef enum {
    LACKYVPN_KEY_SYMMETRIC,
    LACKYVPN_KEY_ASYMMETRIC_PUBLIC,
    LACKYVPN_KEY_ASYMMETRIC_PRIVATE,
    LACKYVPN_KEY_QUANTUM_RESISTANT
} lackyvpn_key_type_t;

// Error codes
typedef enum {
    LACKYVPN_CRYPTO_SUCCESS = 0,
    LACKYVPN_CRYPTO_ERROR_INVALID_PARAM = -1,
    LACKYVPN_CRYPTO_ERROR_BUFFER_TOO_SMALL = -2,
    LACKYVPN_CRYPTO_ERROR_INVALID_KEY = -3,
    LACKYVPN_CRYPTO_ERROR_INVALID_NONCE = -4,
    LACKYVPN_CRYPTO_ERROR_AUTH_FAILED = -5,
    LACKYVPN_CRYPTO_ERROR_NOT_IMPLEMENTED = -6,
    LACKYVPN_CRYPTO_ERROR_MEMORY = -7,
    LACKYVPN_CRYPTO_ERROR_QUANTUM_DECOHERENCE = -8,
    LACKYVPN_CRYPTO_ERROR_ENTANGLEMENT_LOST = -9,
    LACKYVPN_CRYPTO_ERROR_INVALID_STATE = -10,
    LACKYVPN_CRYPTO_ERROR_SELFTEST_FAILED = -11
} LackyvpnCryptoStatus;

//=============================================================================
// CONTEXT STRUCTURES
//=============================================================================

// AES context
typedef struct {
    uint32_t round_keys[60];  // Supports up to AES-256 (14 rounds)
    uint8_t key_size;
    uint8_t rounds;
    uint8_t state[16];
} lackyvpn_aes_ctx_t;

// ChaCha20 context
typedef struct {
    uint32_t state[16];
    uint32_t counter;
    uint8_t key[32];
    uint8_t nonce[12];
} lackyvpn_chacha20_ctx_t;

// Poly1305 context
typedef struct {
    uint32_t r[5];
    uint32_t h[5];
    uint32_t s[4];
    uint8_t buffer[16];
    size_t buffer_len;
} lackyvpn_poly1305_ctx_t;

// SHA-256 context
typedef struct {
    uint32_t state[8];
    uint64_t count;
    uint8_t buffer[64];
    size_t buffer_len;
} lackyvpn_sha256_ctx_t;

// SHA-512 context
typedef struct {
    uint64_t state[8];
    uint64_t count[2];
    uint8_t buffer[128];
    size_t buffer_len;
} lackyvpn_sha512_ctx_t;

// SHA-3 context
typedef struct {
    uint64_t state[25];
    uint8_t buffer[200];
    size_t buffer_len;
    size_t rate;
    size_t capacity;
} lackyvpn_sha3_ctx_t;

// BLAKE3 context
typedef struct {
    uint32_t cv[8];
    uint64_t counter;
    uint8_t buffer[64];
    uint8_t buffer_len;
    uint8_t flags;
} lackyvpn_blake3_ctx_t;

// ECC Point
typedef struct {
    uint8_t x[66];  // Max size for P-521
    uint8_t y[66];
    bool is_infinity;
} lackyvpn_ecc_point_t;

// ECC context
typedef struct {
    lackyvpn_ecc_point_t public_key;
    uint8_t private_key[66];
    uint8_t curve_id;
    size_t key_size;
} lackyvpn_ecc_ctx_t;

// RSA context
typedef struct {
    uint8_t *n;      // Modulus
    uint8_t *e;      // Public exponent
    uint8_t *d;      // Private exponent
    uint8_t *p;      // Prime 1
    uint8_t *q;      // Prime 2
    uint8_t *dp;     // d mod (p-1)
    uint8_t *dq;     // d mod (q-1)
    uint8_t *qinv;   // q^-1 mod p
    size_t key_size;
} lackyvpn_rsa_ctx_t;

// Quantum-resistant Kyber context
typedef struct {
    uint8_t public_key[LACKYVPN_KYBER_512_PK_SIZE];
    uint8_t secret_key[LACKYVPN_KYBER_512_SK_SIZE];
    uint8_t shared_secret[LACKYVPN_KYBER_512_SS_SIZE];
    uint16_t security_level;
} lackyvpn_kyber_ctx_t;

// Quantum-resistant Dilithium context
typedef struct {
    uint8_t public_key[LACKYVPN_DILITHIUM_2_PK_SIZE];
    uint8_t secret_key[LACKYVPN_DILITHIUM_2_SK_SIZE];
    uint8_t signature[LACKYVPN_DILITHIUM_2_SIG_SIZE];
    uint16_t security_level;
} lackyvpn_dilithium_ctx_t;

// Random number generator context
typedef struct {
    uint64_t state[4];
    uint8_t entropy_pool[256];
    size_t pool_index;
    bool initialized;
} lackyvpn_rng_ctx_t;

//=============================================================================
// CORE INITIALIZATION AND CLEANUP
//=============================================================================

/**
 * Initialize the LACKYVPN cryptographic library
 * Sets up hardware acceleration if available
 */
lackyvpn_result_t lackyvpn_crypto_init(void);

/**
 * Cleanup and secure memory wipe
 */
void lackyvpn_crypto_cleanup(void);

/**
 * Get library version information
 */
const char* lackyvpn_crypto_version(void);

//=============================================================================
// RANDOM NUMBER GENERATION
//=============================================================================

/**
 * Initialize secure random number generator
 */
lackyvpn_result_t lackyvpn_rng_init(lackyvpn_rng_ctx_t *ctx);

/**
 * Generate cryptographically secure random bytes
 */
lackyvpn_result_t lackyvpn_rng_generate(lackyvpn_rng_ctx_t *ctx, uint8_t *output, size_t length);

/**
 * Add entropy to the RNG pool
 */
lackyvpn_result_t lackyvpn_rng_add_entropy(lackyvpn_rng_ctx_t *ctx, const uint8_t *entropy, size_t length);

/**
 * Cleanup RNG context
 */
void lackyvpn_rng_cleanup(lackyvpn_rng_ctx_t *ctx);

//=============================================================================
// SYMMETRIC ENCRYPTION - AES
//=============================================================================

/**
 * Initialize AES encryption context
 */
lackyvpn_result_t lackyvpn_aes_init(lackyvpn_aes_ctx_t *ctx, const uint8_t *key, size_t key_size);

/**
 * AES-GCM encryption with authentication
 */
lackyvpn_result_t lackyvpn_aes_gcm_encrypt(
    lackyvpn_aes_ctx_t *ctx,
    const uint8_t *plaintext, size_t plaintext_len,
    const uint8_t *aad, size_t aad_len,
    const uint8_t *iv, size_t iv_len,
    uint8_t *ciphertext,
    uint8_t *tag, size_t tag_len
);

/**
 * AES-GCM decryption with authentication
 */
lackyvpn_result_t lackyvpn_aes_gcm_decrypt(
    lackyvpn_aes_ctx_t *ctx,
    const uint8_t *ciphertext, size_t ciphertext_len,
    const uint8_t *aad, size_t aad_len,
    const uint8_t *iv, size_t iv_len,
    const uint8_t *tag, size_t tag_len,
    uint8_t *plaintext
);

/**
 * AES block encryption (ECB mode)
 */
lackyvpn_result_t lackyvpn_aes_encrypt_block(lackyvpn_aes_ctx_t *ctx, const uint8_t *input, uint8_t *output);

/**
 * AES block decryption (ECB mode)
 */
lackyvpn_result_t lackyvpn_aes_decrypt_block(lackyvpn_aes_ctx_t *ctx, const uint8_t *input, uint8_t *output);

/**
 * Cleanup AES context
 */
void lackyvpn_aes_cleanup(lackyvpn_aes_ctx_t *ctx);

//=============================================================================
// SYMMETRIC ENCRYPTION - ChaCha20-Poly1305
//=============================================================================

/**
 * Initialize ChaCha20 stream cipher
 */
lackyvpn_result_t lackyvpn_chacha20_init(lackyvpn_chacha20_ctx_t *ctx, const uint8_t *key, const uint8_t *nonce);

/**
 * ChaCha20 stream encryption/decryption
 */
lackyvpn_result_t lackyvpn_chacha20_crypt(lackyvpn_chacha20_ctx_t *ctx, const uint8_t *input, uint8_t *output, size_t length);

/**
 * Initialize Poly1305 MAC
 */
lackyvpn_result_t lackyvpn_poly1305_init(lackyvpn_poly1305_ctx_t *ctx, const uint8_t *key);

/**
 * Update Poly1305 with data
 */
lackyvpn_result_t lackyvpn_poly1305_update(lackyvpn_poly1305_ctx_t *ctx, const uint8_t *data, size_t length);

/**
 * Finalize Poly1305 and get tag
 */
lackyvpn_result_t lackyvpn_poly1305_final(lackyvpn_poly1305_ctx_t *ctx, uint8_t *tag);

/**
 * ChaCha20-Poly1305 AEAD encryption
 */
lackyvpn_result_t lackyvpn_chacha20_poly1305_encrypt(
    const uint8_t *key,
    const uint8_t *nonce,
    const uint8_t *aad, size_t aad_len,
    const uint8_t *plaintext, size_t plaintext_len,
    uint8_t *ciphertext,
    uint8_t *tag
);

/**
 * ChaCha20-Poly1305 AEAD decryption
 */
lackyvpn_result_t lackyvpn_chacha20_poly1305_decrypt(
    const uint8_t *key,
    const uint8_t *nonce,
    const uint8_t *aad, size_t aad_len,
    const uint8_t *ciphertext, size_t ciphertext_len,
    const uint8_t *tag,
    uint8_t *plaintext
);

//=============================================================================
// HASH FUNCTIONS
//=============================================================================

/**
 * SHA-256 hash computation
 */
lackyvpn_result_t lackyvpn_sha256(const uint8_t *input, size_t length, uint8_t *output);

/**
 * SHA-256 streaming interface
 */
lackyvpn_result_t lackyvpn_sha256_init(lackyvpn_sha256_ctx_t *ctx);
lackyvpn_result_t lackyvpn_sha256_update(lackyvpn_sha256_ctx_t *ctx, const uint8_t *input, size_t length);
lackyvpn_result_t lackyvpn_sha256_final(lackyvpn_sha256_ctx_t *ctx, uint8_t *output);

/**
 * SHA-512 hash computation
 */
lackyvpn_result_t lackyvpn_sha512(const uint8_t *input, size_t length, uint8_t *output);

/**
 * SHA-512 streaming interface
 */
lackyvpn_result_t lackyvpn_sha512_init(lackyvpn_sha512_ctx_t *ctx);
lackyvpn_result_t lackyvpn_sha512_update(lackyvpn_sha512_ctx_t *ctx, const uint8_t *input, size_t length);
lackyvpn_result_t lackyvpn_sha512_final(lackyvpn_sha512_ctx_t *ctx, uint8_t *output);

/**
 * SHA-3 hash computation
 */
lackyvpn_result_t lackyvpn_sha3_256(const uint8_t *input, size_t length, uint8_t *output);
lackyvpn_result_t lackyvpn_sha3_512(const uint8_t *input, size_t length, uint8_t *output);

/**
 * BLAKE3 hash computation (quantum-resistant)
 */
lackyvpn_result_t lackyvpn_blake3(const uint8_t *input, size_t length, uint8_t *output, size_t output_len);

/**
 * HMAC computation
 */
lackyvpn_result_t lackyvpn_hmac_sha256(
    const uint8_t *key, size_t key_len,
    const uint8_t *message, size_t message_len,
    uint8_t *output
);

lackyvpn_result_t lackyvpn_hmac_sha512(
    const uint8_t *key, size_t key_len,
    const uint8_t *message, size_t message_len,
    uint8_t *output
);

//=============================================================================
// ADVANCED HASH FUNCTIONS AND QUANTUM-RESISTANT VARIANTS
//=============================================================================

/**
 * SHAKE-128 extendable output function
 */
lackyvpn_result_t lackyvpn_shake128(uint8_t *output, size_t output_len, const uint8_t *input, size_t input_len);

/**
 * SHAKE-256 extendable output function
 */
lackyvpn_result_t lackyvpn_shake256(uint8_t *output, size_t output_len, const uint8_t *input, size_t input_len);

/**
 * BLAKE3 keyed hash for authentication
 */
lackyvpn_result_t lackyvpn_blake3_keyed(uint8_t *output, const uint8_t *input, size_t input_len, const uint8_t key[32]);

/**
 * BLAKE3 derive key context
 */
lackyvpn_result_t lackyvpn_blake3_derive_key(uint8_t *output, size_t output_len, const uint8_t *context, const uint8_t *key_material, size_t key_len);

//=============================================================================
// ELLIPTIC CURVE CRYPTOGRAPHY
//=============================================================================

/**
 * Initialize ECC context for specified curve
 */
lackyvpn_result_t lackyvpn_ecc_init(lackyvpn_ecc_ctx_t *ctx, uint8_t curve_id);

/**
 * Generate ECC key pair
 */
lackyvpn_result_t lackyvpn_ecc_generate_keypair(lackyvpn_ecc_ctx_t *ctx, lackyvpn_rng_ctx_t *rng);

/**
 * ECDH key agreement
 */
lackyvpn_result_t lackyvpn_ecdh(
    const lackyvpn_ecc_ctx_t *ctx,
    const lackyvpn_ecc_point_t *peer_public_key,
    uint8_t *shared_secret,
    size_t *shared_secret_len
);

/**
 * ECDSA signature generation
 */
lackyvpn_result_t lackyvpn_ecdsa_sign(
    const lackyvpn_ecc_ctx_t *ctx,
    const uint8_t *hash, size_t hash_len,
    uint8_t *signature, size_t *signature_len,
    lackyvpn_rng_ctx_t *rng
);

/**
 * ECDSA signature verification
 */
lackyvpn_result_t lackyvpn_ecdsa_verify(
    const lackyvpn_ecc_ctx_t *ctx,
    const uint8_t *hash, size_t hash_len,
    const uint8_t *signature, size_t signature_len
);

/**
 * Ed25519 signature operations
 */
lackyvpn_result_t lackyvpn_ed25519_generate_keypair(uint8_t *public_key, uint8_t *private_key, lackyvpn_rng_ctx_t *rng);
lackyvpn_result_t lackyvpn_ed25519_sign(const uint8_t *private_key, const uint8_t *message, size_t message_len, uint8_t *signature);
lackyvpn_result_t lackyvpn_ed25519_verify(const uint8_t *public_key, const uint8_t *message, size_t message_len, const uint8_t *signature);

/**
 * X25519 key exchange
 */
lackyvpn_result_t lackyvpn_x25519_generate_keypair(uint8_t *public_key, uint8_t *private_key, lackyvpn_rng_ctx_t *rng);
lackyvpn_result_t lackyvpn_x25519(uint8_t *shared_secret, const uint8_t *private_key, const uint8_t *public_key);

//=============================================================================
// RSA OPERATIONS
//=============================================================================

/**
 * Initialize RSA context
 */
lackyvpn_result_t lackyvpn_rsa_init(lackyvpn_rsa_ctx_t *ctx, size_t key_size);

/**
 * Generate RSA key pair
 */
lackyvpn_result_t lackyvpn_rsa_generate_keypair(lackyvpn_rsa_ctx_t *ctx, lackyvpn_rng_ctx_t *rng);

/**
 * RSA encryption with OAEP padding
 */
lackyvpn_result_t lackyvpn_rsa_encrypt_oaep(
    const lackyvpn_rsa_ctx_t *ctx,
    const uint8_t *plaintext, size_t plaintext_len,
    const uint8_t *label, size_t label_len,
    uint8_t *ciphertext, size_t *ciphertext_len,
    lackyvpn_rng_ctx_t *rng
);

/**
 * RSA decryption with OAEP padding
 */
lackyvpn_result_t lackyvpn_rsa_decrypt_oaep(
    const lackyvpn_rsa_ctx_t *ctx,
    const uint8_t *ciphertext, size_t ciphertext_len,
    const uint8_t *label, size_t label_len,
    uint8_t *plaintext, size_t *plaintext_len
);

/**
 * RSA signature with PSS padding
 */
lackyvpn_result_t lackyvpn_rsa_sign_pss(
    const lackyvpn_rsa_ctx_t *ctx,
    const uint8_t *hash, size_t hash_len,
    uint8_t *signature, size_t *signature_len,
    lackyvpn_rng_ctx_t *rng
);

/**
 * RSA signature verification with PSS padding
 */
lackyvpn_result_t lackyvpn_rsa_verify_pss(
    const lackyvpn_rsa_ctx_t *ctx,
    const uint8_t *hash, size_t hash_len,
    const uint8_t *signature, size_t signature_len
);

/**
 * RSA key generation with specific parameters
 */
typedef struct {
    uint32_t *n;      // Modulus
    uint32_t *e;      // Public exponent
    uint32_t *d;      // Private exponent
    uint32_t *p, *q;  // Prime factors
    uint32_t *dp, *dq; // CRT exponents
    uint32_t *qinv;   // CRT coefficient
    int key_size;     // Key size in bits
} rsa_key_t;

lackyvpn_result_t lackyvpn_rsa_generate_key(rsa_key_t *key, int key_size);

//=============================================================================
// POST-QUANTUM CRYPTOGRAPHY - KYBER (Key Encapsulation)
//=============================================================================

/**
 * Initialize Kyber context
 */
lackyvpn_result_t lackyvpn_kyber_init(lackyvpn_kyber_ctx_t *ctx, uint16_t security_level);

/**
 * Generate Kyber key pair
 */
lackyvpn_result_t lackyvpn_kyber_keypair(lackyvpn_kyber_ctx_t *ctx, lackyvpn_rng_ctx_t *rng);

/**
 * Kyber encapsulation (generate shared secret)
 */
lackyvpn_result_t lackyvpn_kyber_encaps(
    const lackyvpn_kyber_ctx_t *ctx,
    uint8_t *ciphertext, size_t *ciphertext_len,
    uint8_t *shared_secret,
    lackyvpn_rng_ctx_t *rng
);

/**
 * Kyber decapsulation (recover shared secret)
 */
lackyvpn_result_t lackyvpn_kyber_decaps(
    const lackyvpn_kyber_ctx_t *ctx,
    const uint8_t *ciphertext, size_t ciphertext_len,
    uint8_t *shared_secret
);

//=============================================================================
// POST-QUANTUM CRYPTOGRAPHY - DILITHIUM (Digital Signatures)
//=============================================================================

/**
 * Initialize Dilithium context
 */
lackyvpn_result_t lackyvpn_dilithium_init(lackyvpn_dilithium_ctx_t *ctx, uint16_t security_level);

/**
 * Generate Dilithium key pair
 */
lackyvpn_result_t lackyvpn_dilithium_keypair(lackyvpn_dilithium_ctx_t *ctx, lackyvpn_rng_ctx_t *rng);

/**
 * Dilithium signature generation
 */
lackyvpn_result_t lackyvpn_dilithium_sign(
    const lackyvpn_dilithium_ctx_t *ctx,
    const uint8_t *message, size_t message_len,
    uint8_t *signature, size_t *signature_len,
    lackyvpn_rng_ctx_t *rng
);

/**
 * Dilithium signature verification
 */
lackyvpn_result_t lackyvpn_dilithium_verify(
    const lackyvpn_dilithium_ctx_t *ctx,
    const uint8_t *message, size_t message_len,
    const uint8_t *signature, size_t signature_len
);

//=============================================================================
// KEY DERIVATION FUNCTIONS
//=============================================================================

/**
 * PBKDF2 key derivation
 */
lackyvpn_result_t lackyvpn_pbkdf2_sha256(
    const uint8_t *password, size_t password_len,
    const uint8_t *salt, size_t salt_len,
    uint32_t iterations,
    uint8_t *output, size_t output_len
);

/**
 * HKDF key derivation
 */
lackyvpn_result_t lackyvpn_hkdf_sha256(
    const uint8_t *salt, size_t salt_len,
    const uint8_t *ikm, size_t ikm_len,
    const uint8_t *info, size_t info_len,
    uint8_t *okm, size_t okm_len
);

/**
 * Argon2id password hashing (memory-hard)
 */
lackyvpn_result_t lackyvpn_argon2id(
    const uint8_t *password, size_t password_len,
    const uint8_t *salt, size_t salt_len,
    uint32_t t_cost, uint32_t m_cost, uint32_t parallelism,
    uint8_t *output, size_t output_len
);

//=============================================================================
// QUANTUM CRYPTOGRAPHY SIMULATION
//=============================================================================

/**
 * Simulate BB84 quantum key distribution protocol
 */
typedef struct {
    uint8_t *quantum_bits;
    uint8_t *basis_choices;
    uint8_t *measurement_results;
    size_t bit_count;
    float error_rate;
} lackyvpn_bb84_ctx_t;

lackyvpn_result_t lackyvpn_bb84_init(lackyvpn_bb84_ctx_t *ctx, size_t bit_count);
lackyvpn_result_t lackyvpn_bb84_generate_bits(lackyvpn_bb84_ctx_t *ctx, lackyvpn_rng_ctx_t *rng);
lackyvpn_result_t lackyvpn_bb84_measure(lackyvpn_bb84_ctx_t *alice, lackyvpn_bb84_ctx_t *bob, uint8_t *shared_key, size_t *key_len);
void lackyvpn_bb84_cleanup(lackyvpn_bb84_ctx_t *ctx);

/**
 * Quantum random number generation (simulation)
 */
lackyvpn_result_t lackyvpn_quantum_rng(uint8_t *output, size_t length, lackyvpn_rng_ctx_t *fallback_rng);

//=============================================================================
// COMPREHENSIVE SELF-TEST SUITE
//=============================================================================

/**
 * Run all cryptographic self-tests
 */
lackyvpn_result_t lackyvpn_crypto_self_test_all(void);

/**
 * Individual algorithm self-tests
 */
lackyvpn_result_t lackyvpn_aes_self_test(void);
lackyvpn_result_t lackyvpn_chacha20_self_test(void);
lackyvpn_result_t lackyvpn_sha_self_test(void);
lackyvpn_result_t lackyvpn_sha3_self_test(void);
lackyvpn_result_t lackyvpn_blake3_self_test(void);
lackyvpn_result_t lackyvpn_ecc_self_test(void);
lackyvpn_result_t lackyvpn_rsa_self_test(void);
lackyvpn_result_t lackyvpn_kyber_self_test(void);
lackyvpn_result_t lackyvpn_dilithium_self_test(void);
lackyvpn_result_t lackyvpn_post_quantum_self_test(void);
lackyvpn_result_t lackyvpn_advanced_hash_self_test(void);

//=============================================================================
// PERFORMANCE AND BENCHMARKING
//=============================================================================

typedef struct {
    uint64_t cycles_per_byte;
    uint64_t operations_per_second;
    uint64_t total_bytes_processed;
    uint64_t total_time_ns;
} lackyvpn_perf_metrics_t;

/**
 * Benchmark cryptographic operations
 */
lackyvpn_result_t lackyvpn_benchmark_aes(lackyvpn_perf_metrics_t *metrics);
lackyvpn_result_t lackyvpn_benchmark_chacha20(lackyvpn_perf_metrics_t *metrics);
lackyvpn_result_t lackyvpn_benchmark_sha256(lackyvpn_perf_metrics_t *metrics);
lackyvpn_result_t lackyvpn_benchmark_ecc(lackyvpn_perf_metrics_t *metrics);
lackyvpn_result_t lackyvpn_benchmark_post_quantum(lackyvpn_perf_metrics_t *metrics);

/**
 * Hardware acceleration detection
 */
typedef struct {
    bool aes_ni_available;
    bool sha_extensions_available;
    bool avx2_available;
    bool avx512_available;
    bool neon_available;      // ARM NEON
    bool crypto_extensions;   // ARM Crypto Extensions
} lackyvpn_hw_capabilities_t;

lackyvpn_result_t lackyvpn_detect_hardware_capabilities(lackyvpn_hw_capabilities_t *caps);

//=============================================================================
// UTILITY FUNCTIONS
//=============================================================================

/**
 * Secure memory operations
 */
void lackyvpn_secure_zero(void *ptr, size_t size);
int lackyvpn_secure_compare(const void *a, const void *b, size_t size);

/**
 * Constant-time operations
 */
uint32_t lackyvpn_ct_eq(uint32_t a, uint32_t b);
uint32_t lackyvpn_ct_select(uint32_t condition, uint32_t a, uint32_t b);
void lackyvpn_ct_copy(uint32_t condition, void *dst, const void *src, size_t size);

/**
 * Base64 encoding/decoding for key transport
 */
lackyvpn_result_t lackyvpn_base64_encode(const uint8_t *input, size_t input_len, char *output, size_t *output_len);
lackyvpn_result_t lackyvpn_base64_decode(const char *input, size_t input_len, uint8_t *output, size_t *output_len);

/**
 * Hexadecimal encoding/decoding
 */
lackyvpn_result_t lackyvpn_hex_encode(const uint8_t *input, size_t input_len, char *output, size_t *output_len);
lackyvpn_result_t lackyvpn_hex_decode(const char *input, size_t input_len, uint8_t *output, size_t *output_len);

#endif /* CRYPTO_PRIMITIVES_H */
