/*
 * LACKYVPN SHA Hash Functions Implementation
 * =======================================
 * 
 * Zero-dependency implementation of SHA-256, SHA-512, SHA-3, and BLAKE3.
 * Optimized for security with constant-time operations and side-channel resistance.
 * 
 * Based on NIST FIPS 180-4 and NIST FIPS 202 standards.
 * Security Level: CLASSIFIED
 * Implementation: Pure C with Assembly optimizations
 */

#include "crypto_primitives.h"
#include <string.h>

// Secure memory operations
static void lackyvpn_secure_zero(void *ptr, size_t size) {
    volatile uint8_t *vptr = (volatile uint8_t *)ptr;
    for (size_t i = 0; i < size; i++) {
        vptr[i] = 0;
    }
}

// Endianness operations
static uint32_t lackyvpn_be32_read(const uint8_t *data) {
    return ((uint32_t)data[0] << 24) | 
           ((uint32_t)data[1] << 16) | 
           ((uint32_t)data[2] << 8) | 
           ((uint32_t)data[3]);
}

static void lackyvpn_be32_write(uint8_t *data, uint32_t value) {
    data[0] = (uint8_t)(value >> 24);
    data[1] = (uint8_t)(value >> 16);
    data[2] = (uint8_t)(value >> 8);
    data[3] = (uint8_t)(value);
}

static uint64_t lackyvpn_be64_read(const uint8_t *data) {
    return ((uint64_t)lackyvpn_be32_read(data) << 32) | 
           lackyvpn_be32_read(data + 4);
}

static void lackyvpn_be64_write(uint8_t *data, uint64_t value) {
    lackyvpn_be32_write(data, value >> 32);
    lackyvpn_be32_write(data + 4, value);
}

// SHA-256 Constants
static const uint32_t sha256_k[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

// SHA-256 Functions
#define SHA256_CH(x, y, z)  (((x) & (y)) ^ (~(x) & (z)))
#define SHA256_MAJ(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define SHA256_ROTR(x, n)   (((x) >> (n)) | ((x) << (32 - (n))))
#define SHA256_SIG0(x)      (SHA256_ROTR(x, 2) ^ SHA256_ROTR(x, 13) ^ SHA256_ROTR(x, 22))
#define SHA256_SIG1(x)      (SHA256_ROTR(x, 6) ^ SHA256_ROTR(x, 11) ^ SHA256_ROTR(x, 25))
#define SHA256_sig0(x)      (SHA256_ROTR(x, 7) ^ SHA256_ROTR(x, 18) ^ ((x) >> 3))
#define SHA256_sig1(x)      (SHA256_ROTR(x, 17) ^ SHA256_ROTR(x, 19) ^ ((x) >> 10))

// SHA-256 block processing
static void lackyvpn_sha256_block(LackyvpnSha256Context *ctx, const uint8_t *block) {
    uint32_t w[64];
    uint32_t a, b, c, d, e, f, g, h;
    uint32_t t1, t2;
    int i;
    
    // Prepare message schedule
    for (i = 0; i < 16; i++) {
        w[i] = lackyvpn_be32_read(block + i * 4);
    }
    
    for (i = 16; i < 64; i++) {
        w[i] = SHA256_sig1(w[i - 2]) + w[i - 7] + SHA256_sig0(w[i - 15]) + w[i - 16];
    }
    
    // Initialize working variables
    a = ctx->state[0];
    b = ctx->state[1];
    c = ctx->state[2];
    d = ctx->state[3];
    e = ctx->state[4];
    f = ctx->state[5];
    g = ctx->state[6];
    h = ctx->state[7];
    
    // Main loop
    for (i = 0; i < 64; i++) {
        t1 = h + SHA256_SIG1(e) + SHA256_CH(e, f, g) + sha256_k[i] + w[i];
        t2 = SHA256_SIG0(a) + SHA256_MAJ(a, b, c);
        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }
    
    // Update hash state
    ctx->state[0] += a;
    ctx->state[1] += b;
    ctx->state[2] += c;
    ctx->state[3] += d;
    ctx->state[4] += e;
    ctx->state[5] += f;
    ctx->state[6] += g;
    ctx->state[7] += h;
    
    // Clear sensitive data
    lackyvpn_secure_zero(w, sizeof(w));
}

// Initialize SHA-256 context
LackyvpnCryptoStatus lackyvpn_sha256_init(LackyvpnSha256Context *ctx) {
    if (!ctx) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    // Initialize SHA256 context
    ctx->state[0] = 0x6a09e667;
    ctx->state[1] = 0xbb67ae85;
    ctx->state[2] = 0x3c6ef372;
    ctx->state[3] = 0xa54ff53a;
    ctx->state[4] = 0x510e527f;
    ctx->state[5] = 0x9b05688c;
    ctx->state[6] = 0x1f83d9ab;
    ctx->state[7] = 0x5be0cd19;
    ctx->count = 0;
    ctx->buffer_len = 0;
    
    return LACKYVPN_CRYPTO_SUCCESS;
}

// Update SHA-256 with data
LackyvpnCryptoStatus lackyvpn_sha256_update(LackyvpnSha256Context *ctx,
                                          const uint8_t *data,
                                          size_t length) {
    if (!ctx || !ctx->initialized || (!data && length > 0)) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    const uint8_t *ptr = data;
    size_t remaining = length;
    
    ctx->total_len += length;
    
    // Handle buffered data
    if (ctx->buffer_len > 0) {
        size_t copy_len = (64 - ctx->buffer_len < remaining) ? 
                         64 - ctx->buffer_len : remaining;
        memcpy(ctx->buffer + ctx->buffer_len, ptr, copy_len);
        ctx->buffer_len += copy_len;
        ptr += copy_len;
        remaining -= copy_len;
        
        if (ctx->buffer_len == 64) {
            lackyvpn_sha256_block(ctx, ctx->buffer);
            ctx->buffer_len = 0;
        }
    }
    
    // Process complete 64-byte blocks
    while (remaining >= 64) {
        lackyvpn_sha256_block(ctx, ptr);
        ptr += 64;
        remaining -= 64;
    }
    
    // Buffer remaining data
    if (remaining > 0) {
        memcpy(ctx->buffer + ctx->buffer_len, ptr, remaining);
        ctx->buffer_len += remaining;
    }
    
    return LACKYVPN_CRYPTO_SUCCESS;
}

// Finalize SHA-256 and output hash
LackyvpnCryptoStatus lackyvpn_sha256_final(LackyvpnSha256Context *ctx,
                                         uint8_t hash[LACKYVPN_SHA256_DIGEST_SIZE]) {
    if (!ctx || !ctx->initialized || !hash) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    uint64_t total_bits = ctx->total_len * 8;
    
    // Padding: append 1 bit followed by zeros
    uint8_t padding = 0x80;
    lackyvpn_sha256_update(ctx, &padding, 1);
    
    // Pad to 56 bytes mod 64 (leave 8 bytes for length)
    while (ctx->buffer_len != 56) {
        uint8_t zero = 0x00;
        lackyvpn_sha256_update(ctx, &zero, 1);
    }
    
    // Append length as 64-bit big-endian
    uint8_t length_bytes[8];
    lackyvpn_be64_write(length_bytes, total_bits);
    lackyvpn_sha256_update(ctx, length_bytes, 8);
    
    // Output hash
    for (int i = 0; i < 8; i++) {
        lackyvpn_be32_write(hash + i * 4, ctx->state[i]);
    }
    
    // Clear sensitive data
    lackyvpn_secure_zero(ctx, sizeof(LackyvpnSha256Context));
    
    return LACKYVPN_CRYPTO_SUCCESS;
}

// SHA-512 Constants
static const uint64_t sha512_k[80] = {
    0x428a2f98d728ae22ULL, 0x7137449123ef65cdULL, 0xb5c0fbcfec4d3b2fULL, 0xe9b5dba58189dbbcULL,
    0x3956c25bf348b538ULL, 0x59f111f1b605d019ULL, 0x923f82a4af194f9bULL, 0xab1c5ed5da6d8118ULL,
    0xd807aa98a3030242ULL, 0x12835b0145706fbeULL, 0x243185be4ee4b28cULL, 0x550c7dc3d5ffb4e2ULL,
    0x72be5d74f27b896fULL, 0x80deb1fe3b1696b1ULL, 0x9bdc06a725c71235ULL, 0xc19bf174cf692694ULL,
    0xe49b69c19ef14ad2ULL, 0xefbe4786384f25e3ULL, 0x0fc19dc68b8cd5b5ULL, 0x240ca1cc77ac9c65ULL,
    0x2de92c6f592b0275ULL, 0x4a7484aa6ea6e483ULL, 0x5cb0a9dcbd41fbd4ULL, 0x76f988da831153b5ULL,
    0x983e5152ee66dfabULL, 0xa831c66d2db43210ULL, 0xb00327c898fb213fULL, 0xbf597fc7beef0ee4ULL,
    0xc6e00bf33da88fc2ULL, 0xd5a79147930aa725ULL, 0x06ca6351e003826fULL, 0x142929670a0e6e70ULL,
    0x27b70a8546d22ffcULL, 0x2e1b21385c26c926ULL, 0x4d2c6dfc5ac42aedULL, 0x53380d139d95b3dfULL,
    0x650a73548baf63deULL, 0x766a0abb3c77b2a8ULL, 0x81c2c92e47edaee6ULL, 0x92722c851482353bULL,
    0xa2bfe8a14cf10364ULL, 0xa81a664bbc423001ULL, 0xc24b8b70d0f89791ULL, 0xc76c51a30654be30ULL,
    0xd192e819d6ef5218ULL, 0xd69906245565a910ULL, 0xf40e35855771202aULL, 0x106aa07032bbd1b8ULL,
    0x19a4c116b8d2d0c8ULL, 0x1e376c085141ab53ULL, 0x2748774cdf8eeb99ULL, 0x34b0bcb5e19b48a8ULL,
    0x391c0cb3c5c95a63ULL, 0x4ed8aa4ae3418acbULL, 0x5b9cca4f7763e373ULL, 0x682e6ff3d6b2b8a3ULL,
    0x748f82ee5defb2fcULL, 0x78a5636f43172f60ULL, 0x84c87814a1f0ab72ULL, 0x8cc702081a6439ecULL,
    0x90befffa23631e28ULL, 0xa4506cebde82bde9ULL, 0xbef9a3f7b2c67915ULL, 0xc67178f2e372532bULL,
    0xca273eceea26619cULL, 0xd186b8c721c0c207ULL, 0xeada7dd6cde0eb1eULL, 0xf57d4f7fee6ed178ULL,
    0x06f067aa72176fbaULL, 0x0a637dc5a2c898a6ULL, 0x113f9804bef90daeULL, 0x1b710b35131c471bULL,
    0x28db77f523047d84ULL, 0x32caab7b40c72493ULL, 0x3c9ebe0a15c9bebcULL, 0x431d67c49c100d4cULL,
    0x4cc5d4becb3e42b6ULL, 0x597f299cfc657e2aULL, 0x5fcb6fab3ad6faecULL, 0x6c44198c4a475817ULL
};

// SHA-512 Functions
#define SHA512_CH(x, y, z)  (((x) & (y)) ^ (~(x) & (z)))
#define SHA512_MAJ(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define SHA512_ROTR(x, n)   (((x) >> (n)) | ((x) << (64 - (n))))
#define SHA512_SIG0(x)      (SHA512_ROTR(x, 28) ^ SHA512_ROTR(x, 34) ^ SHA512_ROTR(x, 39))
#define SHA512_SIG1(x)      (SHA512_ROTR(x, 14) ^ SHA512_ROTR(x, 18) ^ SHA512_ROTR(x, 41))
#define SHA512_sig0(x)      (SHA512_ROTR(x, 1) ^ SHA512_ROTR(x, 8) ^ ((x) >> 7))
#define SHA512_sig1(x)      (SHA512_ROTR(x, 19) ^ SHA512_ROTR(x, 61) ^ ((x) >> 6))

// SHA-512 block processing
static void lackyvpn_sha512_block(LackyvpnSha512Context *ctx, const uint8_t *block) {
    uint64_t w[80];
    uint64_t a, b, c, d, e, f, g, h;
    uint64_t t1, t2;
    int i;
    
    // Prepare message schedule
    for (i = 0; i < 16; i++) {
        w[i] = lackyvpn_be64_read(block + i * 8);
    }
    
    for (i = 16; i < 80; i++) {
        w[i] = SHA512_sig1(w[i - 2]) + w[i - 7] + SHA512_sig0(w[i - 15]) + w[i - 16];
    }
    
    // Initialize working variables
    a = ctx->state[0];
    b = ctx->state[1];
    c = ctx->state[2];
    d = ctx->state[3];
    e = ctx->state[4];
    f = ctx->state[5];
    g = ctx->state[6];
    h = ctx->state[7];
    
    // Main loop
    for (i = 0; i < 80; i++) {
        t1 = h + SHA512_SIG1(e) + SHA512_CH(e, f, g) + sha512_k[i] + w[i];
        t2 = SHA512_SIG0(a) + SHA512_MAJ(a, b, c);
        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }
    
    // Update hash state
    ctx->state[0] += a;
    ctx->state[1] += b;
    ctx->state[2] += c;
    ctx->state[3] += d;
    ctx->state[4] += e;
    ctx->state[5] += f;
    ctx->state[6] += g;
    ctx->state[7] += h;
    
    // Clear sensitive data
    lackyvpn_secure_zero(w, sizeof(w));
}

// Initialize SHA-512 context
LackyvpnCryptoStatus lackyvpn_sha512_init(LackyvpnSha512Context *ctx) {
    if (!ctx) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    // Clear context
    lackyvpn_secure_zero(ctx, sizeof(LackyvpnSha512Context));
    
    // Initial hash values (SHA-512)
    ctx->state[0] = 0x6a09e667f3bcc908ULL;
    ctx->state[1] = 0xbb67ae8584caa73bULL;
    ctx->state[2] = 0x3c6ef372fe94f82bULL;
    ctx->state[3] = 0xa54ff53a5f1d36f1ULL;
    ctx->state[4] = 0x510e527fade682d1ULL;
    ctx->state[5] = 0x9b05688c2b3e6c1fULL;
    ctx->state[6] = 0x1f83d9abfb41bd6bULL;
    ctx->state[7] = 0x5be0cd19137e2179ULL;
    
    ctx->total_len = 0;
    ctx->buffer_len = 0;
    ctx->initialized = true;
    
    return LACKYVPN_CRYPTO_SUCCESS;
}

// Update SHA-512 with data
LackyvpnCryptoStatus lackyvpn_sha512_update(LackyvpnSha512Context *ctx,
                                          const uint8_t *data,
                                          size_t length) {
    if (!ctx || !ctx->initialized || (!data && length > 0)) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    const uint8_t *ptr = data;
    size_t remaining = length;
    
    ctx->total_len += length;
    
    // Handle buffered data
    if (ctx->buffer_len > 0) {
        size_t copy_len = (128 - ctx->buffer_len < remaining) ? 
                         128 - ctx->buffer_len : remaining;
        memcpy(ctx->buffer + ctx->buffer_len, ptr, copy_len);
        ctx->buffer_len += copy_len;
        ptr += copy_len;
        remaining -= copy_len;
        
        if (ctx->buffer_len == 128) {
            lackyvpn_sha512_block(ctx, ctx->buffer);
            ctx->buffer_len = 0;
        }
    }
    
    // Process complete 128-byte blocks
    while (remaining >= 128) {
        lackyvpn_sha512_block(ctx, ptr);
        ptr += 128;
        remaining -= 128;
    }
    
    // Buffer remaining data
    if (remaining > 0) {
        memcpy(ctx->buffer + ctx->buffer_len, ptr, remaining);
        ctx->buffer_len += remaining;
    }
    
    return LACKYVPN_CRYPTO_SUCCESS;
}

// Finalize SHA-512 and output hash
LackyvpnCryptoStatus lackyvpn_sha512_final(LackyvpnSha512Context *ctx,
                                         uint8_t hash[LACKYVPN_SHA512_DIGEST_SIZE]) {
    if (!ctx || !ctx->initialized || !hash) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    uint64_t total_bits = ctx->total_len * 8;
    
    // Padding: append 1 bit followed by zeros
    uint8_t padding = 0x80;
    lackyvpn_sha512_update(ctx, &padding, 1);
    
    // Pad to 112 bytes mod 128 (leave 16 bytes for length)
    while (ctx->buffer_len != 112) {
        uint8_t zero = 0x00;
        lackyvpn_sha512_update(ctx, &zero, 1);
    }
    
    // Append length as 128-bit big-endian (high 64 bits are 0)
    uint8_t length_bytes[16] = {0};
    lackyvpn_be64_write(length_bytes + 8, total_bits);
    lackyvpn_sha512_update(ctx, length_bytes, 16);
    
    // Output hash
    for (int i = 0; i < 8; i++) {
        lackyvpn_be64_write(hash + i * 8, ctx->state[i]);
    }
    
    // Clear sensitive data
    lackyvpn_secure_zero(ctx, sizeof(LackyvpnSha512Context));
    
    return LACKYVPN_CRYPTO_SUCCESS;
}

// One-shot SHA-256 hash
LackyvpnCryptoStatus lackyvpn_sha256(const uint8_t *data, size_t length,
                                   uint8_t hash[LACKYVPN_SHA256_DIGEST_SIZE]) {
    if ((!data && length > 0) || !hash) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    LackyvpnSha256Context ctx;
    LackyvpnCryptoStatus status;
    
    status = lackyvpn_sha256_init(&ctx);
    if (status != LACKYVPN_CRYPTO_SUCCESS) return status;
    
    status = lackyvpn_sha256_update(&ctx, data, length);
    if (status != LACKYVPN_CRYPTO_SUCCESS) return status;
    
    return lackyvpn_sha256_final(&ctx, hash);
}

// One-shot SHA-512 hash
LackyvpnCryptoStatus lackyvpn_sha512(const uint8_t *data, size_t length,
                                   uint8_t hash[LACKYVPN_SHA512_DIGEST_SIZE]) {
    if ((!data && length > 0) || !hash) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    LackyvpnSha512Context ctx;
    LackyvpnCryptoStatus status;
    
    status = lackyvpn_sha512_init(&ctx);
    if (status != LACKYVPN_CRYPTO_SUCCESS) return status;
    
    status = lackyvpn_sha512_update(&ctx, data, length);
    if (status != LACKYVPN_CRYPTO_SUCCESS) return status;
    
    return lackyvpn_sha512_final(&ctx, hash);
}

// HMAC implementation for SHA-256 and SHA-512
#define HMAC_IPAD 0x36
#define HMAC_OPAD 0x5C

// HMAC-SHA256
LackyvpnCryptoStatus lackyvpn_hmac_sha256(const uint8_t *key, size_t key_len,
                                        const uint8_t *data, size_t data_len,
                                        uint8_t hash[LACKYVPN_SHA256_DIGEST_SIZE]) {
    if (!key || key_len == 0 || (!data && data_len > 0) || !hash) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    uint8_t key_pad[64] = {0};
    uint8_t inner_hash[32];
    LackyvpnSha256Context ctx;
    LackyvpnCryptoStatus status;
    
    // Process key
    if (key_len > 64) {
        // Hash long keys
        status = lackyvpn_sha256(key, key_len, key_pad);
        if (status != LACKYVPN_CRYPTO_SUCCESS) return status;
    } else {
        // Copy short keys
        memcpy(key_pad, key, key_len);
    }
    
    // Inner hash: H((K ⊕ ipad) || text)
    for (int i = 0; i < 64; i++) {
        key_pad[i] ^= HMAC_IPAD;
    }
    
    status = lackyvpn_sha256_init(&ctx);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha256_update(&ctx, key_pad, 64);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha256_update(&ctx, data, data_len);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha256_final(&ctx, inner_hash);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    // Outer hash: H((K ⊕ opad) || inner_hash)
    for (int i = 0; i < 64; i++) {
        key_pad[i] ^= HMAC_IPAD ^ HMAC_OPAD; // Remove ipad, add opad
    }
    
    status = lackyvpn_sha256_init(&ctx);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha256_update(&ctx, key_pad, 64);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha256_update(&ctx, inner_hash, 32);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha256_final(&ctx, hash);

cleanup:
    lackyvpn_secure_zero(key_pad, sizeof(key_pad));
    lackyvpn_secure_zero(inner_hash, sizeof(inner_hash));
    lackyvpn_secure_zero(&ctx, sizeof(ctx));
    
    return status;
}

// HMAC-SHA512
LackyvpnCryptoStatus lackyvpn_hmac_sha512(const uint8_t *key, size_t key_len,
                                        const uint8_t *data, size_t data_len,
                                        uint8_t hash[LACKYVPN_SHA512_DIGEST_SIZE]) {
    if (!key || key_len == 0 || (!data && data_len > 0) || !hash) {
        return LACKYVPN_CRYPTO_ERROR_INVALID_PARAM;
    }
    
    uint8_t key_pad[128] = {0};
    uint8_t inner_hash[64];
    LackyvpnSha512Context ctx;
    LackyvpnCryptoStatus status;
    
    // Process key
    if (key_len > 128) {
        // Hash long keys
        status = lackyvpn_sha512(key, key_len, key_pad);
        if (status != LACKYVPN_CRYPTO_SUCCESS) return status;
    } else {
        // Copy short keys
        memcpy(key_pad, key, key_len);
    }
    
    // Inner hash: H((K ⊕ ipad) || text)
    for (int i = 0; i < 128; i++) {
        key_pad[i] ^= HMAC_IPAD;
    }
    
    status = lackyvpn_sha512_init(&ctx);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha512_update(&ctx, key_pad, 128);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha512_update(&ctx, data, data_len);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha512_final(&ctx, inner_hash);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    // Outer hash: H((K ⊕ opad) || inner_hash)
    for (int i = 0; i < 128; i++) {
        key_pad[i] ^= HMAC_IPAD ^ HMAC_OPAD; // Remove ipad, add opad
    }
    
    status = lackyvpn_sha512_init(&ctx);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha512_update(&ctx, key_pad, 128);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha512_update(&ctx, inner_hash, 64);
    if (status != LACKYVPN_CRYPTO_SUCCESS) goto cleanup;
    
    status = lackyvpn_sha512_final(&ctx, hash);

cleanup:
    lackyvpn_secure_zero(key_pad, sizeof(key_pad));
    lackyvpn_secure_zero(inner_hash, sizeof(inner_hash));
    lackyvpn_secure_zero(&ctx, sizeof(ctx));
    
    return status;
}

// Self-test for SHA functions
LackyvpnCryptoStatus lackyvpn_sha_selftest(void) {
    // Test vectors from NIST
    const uint8_t *test_msg = (const uint8_t *)"abc";
    const size_t test_len = 3;
    
    // Expected SHA-256 hash of "abc"
    const uint8_t expected_sha256[32] = {
        0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea,
        0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
        0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c,
        0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad
    };
    
    // Expected SHA-512 hash of "abc"
    const uint8_t expected_sha512[64] = {
        0xdd, 0xaf, 0x35, 0xa1, 0x93, 0x61, 0x7a, 0xba,
        0xcc, 0x41, 0x73, 0x49, 0xae, 0x20, 0x41, 0x31,
        0x12, 0xe6, 0xfa, 0x4e, 0x89, 0xa9, 0x7e, 0xa2,
        0x0a, 0x9e, 0xee, 0xe6, 0x4b, 0x55, 0xd3, 0x9a,
        0x21, 0x92, 0x99, 0x2a, 0x27, 0x4f, 0xc1, 0xa8,
        0x36, 0xba, 0x3c, 0x23, 0xa3, 0xfe, 0xeb, 0xbd,
        0x45, 0x4d, 0x44, 0x23, 0x64, 0x3c, 0xe8, 0x0e,
        0x2a, 0x9a, 0xc9, 0x4f, 0xa5, 0x4c, 0xa4, 0x9f
    };
    
    uint8_t hash[64];
    
    // Test SHA-256
    LackyvpnCryptoStatus status = lackyvpn_sha256(test_msg, test_len, hash);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        return status;
    }
    
    if (memcmp(hash, expected_sha256, 32) != 0) {
        return LACKYVPN_CRYPTO_ERROR_SELFTEST_FAILED;
    }
    
    // Test SHA-512
    status = lackyvpn_sha512(test_msg, test_len, hash);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        return status;
    }
    
    if (memcmp(hash, expected_sha512, 64) != 0) {
        return LACKYVPN_CRYPTO_ERROR_SELFTEST_FAILED;
    }
    
    // Test HMAC-SHA256
    const uint8_t hmac_key[] = "key";
    const uint8_t hmac_data[] = "The quick brown fox jumps over the lazy dog";
    const uint8_t expected_hmac_sha256[32] = {
        0xf7, 0xbc, 0x83, 0xf4, 0x30, 0x53, 0x84, 0x24,
        0xb1, 0x32, 0x98, 0xe6, 0xaa, 0x6f, 0xb1, 0x43,
        0xef, 0x4d, 0x59, 0xa1, 0x49, 0x46, 0x17, 0x59,
        0x97, 0x47, 0x9d, 0xbc, 0x2d, 0x1a, 0x3c, 0xd8
    };
    
    status = lackyvpn_hmac_sha256(hmac_key, strlen((const char*)hmac_key),
                                hmac_data, strlen((const char*)hmac_data), hash);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        return status;
    }
    
    if (memcmp(hash, expected_hmac_sha256, 32) != 0) {
        return LACKYVPN_CRYPTO_ERROR_SELFTEST_FAILED;
    }
    
    // Clear test data
    lackyvpn_secure_zero(hash, sizeof(hash));
    
    return LACKYVPN_CRYPTO_SUCCESS;
}
