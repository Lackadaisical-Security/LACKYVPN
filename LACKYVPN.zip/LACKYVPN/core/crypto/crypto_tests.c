/*
 * LACKYVPN Cryptographic Primitives Test Suite
 * ===========================================
 * 
 * Comprehensive test suite for all zero-dependency cryptographic implementations.
 * Includes unit tests, known answer tests (KAT), and security validation.
 * 
 * Security Level: CLASSIFIED
 * Implementation: Comprehensive validation suite
 * Built by: Lackadaisical Security - Crypto Division
 */

#include "crypto_primitives.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <assert.h>

// Test framework macros
#define CYAN_BOLD    "\033[1;36m"
#define GREEN_BOLD   "\033[1;32m"
#define RED_BOLD     "\033[1;31m"
#define YELLOW_BOLD  "\033[1;33m"
#define RESET        "\033[0m"

#define TEST_START(name) \
    printf(CYAN_BOLD "[TEST] " RESET "Starting %s...\n", name); \
    clock_t start_time = clock();

#define TEST_PASS(name) \
    printf(GREEN_BOLD "[PASS] " RESET "%s (%.2fms)\n", name, \
           ((double)(clock() - start_time)) / CLOCKS_PER_SEC * 1000);

#define TEST_FAIL(name, reason) \
    printf(RED_BOLD "[FAIL] " RESET "%s: %s\n", name, reason); \
    return false;

#define BENCHMARK_START(name) \
    printf(YELLOW_BOLD "[BENCH] " RESET "Benchmarking %s...\n", name); \
    clock_t bench_start = clock();

#define BENCHMARK_END(name, ops) \
    double elapsed = ((double)(clock() - bench_start)) / CLOCKS_PER_SEC; \
    printf(YELLOW_BOLD "[BENCH] " RESET "%s: %.2f ops/sec (%.2fms total)\n", \
           name, (ops) / elapsed, elapsed * 1000);

// Helper function to compare arrays
static bool arrays_equal(const uint8_t *a, const uint8_t *b, size_t len) {
    for (size_t i = 0; i < len; i++) {
        if (a[i] != b[i]) return false;
    }
    return true;
}

// Helper function to print hex
static void print_hex(const char *label, const uint8_t *data, size_t len) {
    printf("%s: ", label);
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }
    printf("\n");
}

// Test AES implementation
static bool test_aes() {
    TEST_START("AES Implementation");
    
    // AES-128 test vector from NIST
    const uint8_t key[16] = {
        0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c
    };
    
    const uint8_t plaintext[16] = {
        0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d,
        0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34
    };
    
    const uint8_t expected_ciphertext[16] = {
        0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb,
        0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32
    };
    
    LackyvpnAesContext ctx;
    uint8_t ciphertext[16];
    uint8_t decrypted[16];
    
    // Test encryption
    LackyvpnCryptoStatus status = lackyvpn_aes_init(&ctx, LACKYVPN_AES_128, key);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("AES-128", "Failed to initialize context");
    }
    
    status = lackyvpn_aes_encrypt(&ctx, plaintext, ciphertext);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("AES-128", "Encryption failed");
    }
    
    if (!arrays_equal(ciphertext, expected_ciphertext, 16)) {
        print_hex("Expected", expected_ciphertext, 16);
        print_hex("Got", ciphertext, 16);
        TEST_FAIL("AES-128", "Ciphertext mismatch");
    }
    
    // Test decryption
    status = lackyvpn_aes_decrypt(&ctx, ciphertext, decrypted);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("AES-128", "Decryption failed");
    }
    
    if (!arrays_equal(decrypted, plaintext, 16)) {
        TEST_FAIL("AES-128", "Decrypted plaintext mismatch");
    }
    
    // Test AES-256
    const uint8_t key256[32] = {
        0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe,
        0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81,
        0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7,
        0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4
    };
    
    const uint8_t expected256[16] = {
        0xf3, 0xee, 0xd1, 0xbd, 0xb5, 0xd2, 0xa0, 0x3c,
        0x06, 0x4b, 0x5a, 0x7e, 0x3d, 0xb1, 0x81, 0xf8
    };
    
    status = lackyvpn_aes_init(&ctx, LACKYVPN_AES_256, key256);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("AES-256", "Failed to initialize context");
    }
    
    status = lackyvpn_aes_encrypt(&ctx, plaintext, ciphertext);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("AES-256", "Encryption failed");
    }
    
    if (!arrays_equal(ciphertext, expected256, 16)) {
        print_hex("Expected AES-256", expected256, 16);
        print_hex("Got AES-256", ciphertext, 16);
        TEST_FAIL("AES-256", "Ciphertext mismatch");
    }
    
    TEST_PASS("AES Implementation");
    return true;
}

// Test ChaCha20-Poly1305 implementation
static bool test_chacha20_poly1305() {
    TEST_START("ChaCha20-Poly1305 AEAD");
    
    // RFC 8439 test vector
    const uint8_t key[32] = {
        0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
        0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x8d, 0x8e, 0x8f,
        0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97,
        0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f
    };
    
    const uint8_t nonce[12] = {
        0x07, 0x00, 0x00, 0x00, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47
    };
    
    const char* plaintext_str = "Ladies and Gentlemen of the class of '99: If I could offer you only one tip for the future, sunscreen would be it.";
    const uint8_t *plaintext = (const uint8_t*)plaintext_str;
    const size_t plaintext_len = strlen(plaintext_str);
    
    const uint8_t aad[] = {0x50, 0x51, 0x52, 0x53, 0xc0, 0xc1, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7};
    const size_t aad_len = sizeof(aad);
    
    uint8_t ciphertext[256];
    uint8_t tag[16];
    uint8_t decrypted[256];
    
    // Test encryption
    LackyvpnCryptoStatus status = lackyvpn_chacha20_poly1305_encrypt(
        key, nonce, aad, aad_len, plaintext, plaintext_len, ciphertext, tag);
    
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("ChaCha20-Poly1305", "Encryption failed");
    }
    
    // Test decryption
    status = lackyvpn_chacha20_poly1305_decrypt(
        key, nonce, aad, aad_len, ciphertext, plaintext_len, tag, decrypted);
    
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("ChaCha20-Poly1305", "Decryption failed");
    }
    
    if (!arrays_equal(decrypted, plaintext, plaintext_len)) {
        TEST_FAIL("ChaCha20-Poly1305", "Decrypted plaintext mismatch");
    }
    
    // Test authentication failure
    uint8_t bad_tag[16];
    memcpy(bad_tag, tag, 16);
    bad_tag[0] ^= 1; // Corrupt tag
    
    status = lackyvpn_chacha20_poly1305_decrypt(
        key, nonce, aad, aad_len, ciphertext, plaintext_len, bad_tag, decrypted);
    
    if (status != LACKYVPN_CRYPTO_ERROR_AUTH_FAILED) {
        TEST_FAIL("ChaCha20-Poly1305", "Authentication failure not detected");
    }
    
    TEST_PASS("ChaCha20-Poly1305 AEAD");
    return true;
}

// Test SHA hash functions
static bool test_sha() {
    TEST_START("SHA Hash Functions");
    
    const uint8_t *test_msg = (const uint8_t *)"abc";
    const size_t test_len = 3;
    
    // Test SHA-256
    const uint8_t expected_sha256[32] = {
        0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea,
        0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
        0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c,
        0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad
    };
    
    uint8_t hash[64];
    
    LackyvpnCryptoStatus status = lackyvpn_sha256(test_msg, test_len, hash);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("SHA-256", "Hash computation failed");
    }
    
    if (!arrays_equal(hash, expected_sha256, 32)) {
        print_hex("Expected SHA-256", expected_sha256, 32);
        print_hex("Got SHA-256", hash, 32);
        TEST_FAIL("SHA-256", "Hash mismatch");
    }
    
    // Test SHA-512
    const uint8_t expected_sha512[64] = {
        0xdd, 0xaf, 0x35, 0xa1, 0x93, 0x61, 0x7a, 0xba,
        0xcc, 0x41, 0x73, 0x49, 0xae, 0x20, 0x41, 0x31,
        0x12, 0xe6, 0xfa, 0x4e, 0x89, 0xa9, 0x7e, 0xa2,
        0x0a, 0x9e, 0xee, 0xe6, 0x4b, 0x55, 0xd3, 0x9a,
        0x21, 0x92, 0x99, 0x2a, 0x27, 0x4f, 0xc1, 0xa8,
        0x36, 0xba, 0x3c, 0x23, 0xa3, 0xfe, 0xeb, 0xbd,
        0x45, 0x4d, 0x44, 0x23, 0x64, 0x3c, 0xe8, 0x0e,
        0x2a, 0x9a, 0xc9, 0x4f, 0xa5, 0x4c, 0xa4, 0x9f
    };
    
    status = lackyvpn_sha512(test_msg, test_len, hash);
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("SHA-512", "Hash computation failed");
    }
    
    if (!arrays_equal(hash, expected_sha512, 64)) {
        print_hex("Expected SHA-512", expected_sha512, 64);
        print_hex("Got SHA-512", hash, 64);
        TEST_FAIL("SHA-512", "Hash mismatch");
    }
    
    TEST_PASS("SHA Hash Functions");
    return true;
}

// Test HMAC functions
static bool test_hmac() {
    TEST_START("HMAC Functions");
    
    const uint8_t key[] = "key";
    const uint8_t data[] = "The quick brown fox jumps over the lazy dog";
    
    // Expected HMAC-SHA256
    const uint8_t expected_hmac256[32] = {
        0xf7, 0xbc, 0x83, 0xf4, 0x30, 0x53, 0x84, 0x24,
        0xb1, 0x32, 0x98, 0xe6, 0xaa, 0x6f, 0xb1, 0x43,
        0xef, 0x4d, 0x59, 0xa1, 0x49, 0x46, 0x17, 0x59,
        0x97, 0x47, 0x9d, 0xbc, 0x2d, 0x1a, 0x3c, 0xd8
    };
    
    uint8_t hmac[64];
    
    LackyvpnCryptoStatus status = lackyvpn_hmac_sha256(
        key, strlen((const char*)key),
        data, strlen((const char*)data),
        hmac);
    
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("HMAC-SHA256", "HMAC computation failed");
    }
    
    if (!arrays_equal(hmac, expected_hmac256, 32)) {
        print_hex("Expected HMAC-SHA256", expected_hmac256, 32);
        print_hex("Got HMAC-SHA256", hmac, 32);
        TEST_FAIL("HMAC-SHA256", "HMAC mismatch");
    }
    
    TEST_PASS("HMAC Functions");
    return true;
}

// Test key derivation functions
static bool test_kdf() {
    TEST_START("Key Derivation Functions");
    
    const uint8_t password[] = "password";
    const uint8_t salt[] = "salt";
    const uint32_t iterations = 1000;
    uint8_t output[32];
    
    // Test PBKDF2-SHA256
    LackyvpnCryptoStatus status = lackyvpn_pbkdf2_sha256(
        password, strlen((const char*)password),
        salt, strlen((const char*)salt),
        iterations, output, sizeof(output));
    
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("PBKDF2-SHA256", "Key derivation failed");
    }
    
    // Test HKDF-SHA256
    const uint8_t ikm[] = {0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b,
                          0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b,
                          0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b};
    const uint8_t hkdf_salt[] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                                0x08, 0x09, 0x0a, 0x0b, 0x0c};
    const uint8_t info[] = {0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7,
                           0xf8, 0xf9};
    
    uint8_t hkdf_output[42];
    
    status = lackyvpn_hkdf_sha256(hkdf_salt, sizeof(hkdf_salt),
                                ikm, sizeof(ikm),
                                info, sizeof(info),
                                hkdf_output, sizeof(hkdf_output));
    
    if (status != LACKYVPN_CRYPTO_SUCCESS) {
        TEST_FAIL("HKDF-SHA256", "Key derivation failed");
    }
    
    TEST_PASS("Key Derivation Functions");
    return true;
}

// Benchmark crypto operations
static void benchmark_crypto() {
    printf(CYAN_BOLD "\n=== CRYPTOGRAPHIC BENCHMARKS ===\n" RESET);
    
    // Benchmark AES
    {
        BENCHMARK_START("AES-256 Encryption");
        const uint8_t key[32] = {0};
        const uint8_t plaintext[16] = {0};
        uint8_t ciphertext[16];
        
        LackyvpnAesContext ctx;
        lackyvpn_aes_init(&ctx, LACKYVPN_AES_256, key);
        
        const int ops = 100000;
        for (int i = 0; i < ops; i++) {
            lackyvpn_aes_encrypt(&ctx, plaintext, ciphertext);
        }
        BENCHMARK_END("AES-256 Encryption", ops);
    }
    
    // Benchmark ChaCha20
    {
        BENCHMARK_START("ChaCha20 Stream Encryption");
        const uint8_t key[32] = {0};
        const uint8_t nonce[12] = {0};
        uint8_t data[1024] = {0};
        
        LackyvpnChaCha20Context ctx;
        lackyvpn_chacha20_init(&ctx, key, nonce);
        
        const int ops = 10000;
        for (int i = 0; i < ops; i++) {
            lackyvpn_chacha20_crypt(&ctx, data, data, sizeof(data));
        }
        BENCHMARK_END("ChaCha20 (1KB blocks)", ops);
    }
    
    // Benchmark SHA-256
    {
        BENCHMARK_START("SHA-256 Hashing");
        const uint8_t data[1024] = {0};
        uint8_t hash[32];
        
        const int ops = 10000;
        for (int i = 0; i < ops; i++) {
            lackyvpn_sha256(data, sizeof(data), hash);
        }
        BENCHMARK_END("SHA-256 (1KB blocks)", ops);
    }
    
    // Benchmark PBKDF2
    {
        BENCHMARK_START("PBKDF2-SHA256 (10000 iterations)");
        const uint8_t password[] = "test_password";
        const uint8_t salt[] = "test_salt";
        uint8_t output[32];
        
        const int ops = 100;
        for (int i = 0; i < ops; i++) {
            lackyvpn_pbkdf2_sha256(password, strlen((const char*)password),
                                 salt, strlen((const char*)salt),
                                 10000, output, sizeof(output));
        }
        BENCHMARK_END("PBKDF2-SHA256", ops);
    }
}

// Run all self-tests
static bool run_self_tests() {
    printf(GREEN_BOLD "\n=== SELF-TESTS ===\n" RESET);
    
    bool all_passed = true;
    
    // Run individual self-tests
    if (lackyvpn_aes_selftest() != LACKYVPN_CRYPTO_SUCCESS) {
        printf(RED_BOLD "[FAIL]" RESET " AES self-test failed\n");
        all_passed = false;
    } else {
        printf(GREEN_BOLD "[PASS]" RESET " AES self-test\n");
    }
    
    if (lackyvpn_chacha20_poly1305_selftest() != LACKYVPN_CRYPTO_SUCCESS) {
        printf(RED_BOLD "[FAIL]" RESET " ChaCha20-Poly1305 self-test failed\n");
        all_passed = false;
    } else {
        printf(GREEN_BOLD "[PASS]" RESET " ChaCha20-Poly1305 self-test\n");
    }
    
    if (lackyvpn_sha_selftest() != LACKYVPN_CRYPTO_SUCCESS) {
        printf(RED_BOLD "[FAIL]" RESET " SHA self-test failed\n");
        all_passed = false;
    } else {
        printf(GREEN_BOLD "[PASS]" RESET " SHA self-test\n");
    }
    
    if (lackyvpn_kdf_selftest() != LACKYVPN_CRYPTO_SUCCESS) {
        printf(RED_BOLD "[FAIL]" RESET " KDF self-test failed\n");
        all_passed = false;
    } else {
        printf(GREEN_BOLD "[PASS]" RESET " KDF self-test\n");
    }
    
    return all_passed;
}

// Main test function
int main(void) {
    printf(CYAN_BOLD "\n");
    printf("╔══════════════════════════════════════════════════════════════╗\n");
    printf("║                  LACKYVPN CRYPTO TEST SUITE                  ║\n");
    printf("║                Zero-Dependency Cryptography                 ║\n");
    printf("║              Security Level: CLASSIFIED                     ║\n");
    printf("╚══════════════════════════════════════════════════════════════╝\n");
    printf(RESET "\n");
    
    bool all_passed = true;
    
    // Run unit tests
    printf(CYAN_BOLD "=== UNIT TESTS ===\n" RESET);
    
    if (!test_aes()) all_passed = false;
    if (!test_chacha20_poly1305()) all_passed = false;
    if (!test_sha()) all_passed = false;
    if (!test_hmac()) all_passed = false;
    if (!test_kdf()) all_passed = false;
    
    // Run self-tests
    if (!run_self_tests()) all_passed = false;
    
    // Run benchmarks
    benchmark_crypto();
    
    // Final result
    printf(CYAN_BOLD "\n=== FINAL RESULT ===\n" RESET);
    
    if (all_passed) {
        printf(GREEN_BOLD "✓ ALL TESTS PASSED" RESET "\n");
        printf("Cryptographic primitives are functioning correctly.\n");
        printf("LACKYVPN crypto library is ready for deployment.\n");
        return 0;
    } else {
        printf(RED_BOLD "✗ SOME TESTS FAILED" RESET "\n");
        printf("Cryptographic primitives require attention.\n");
        printf("Do not deploy until all tests pass.\n");
        return 1;
    }
}
