/*
 * LACKYVPN GhostDrive Integration Module Implementation
 * ===================================================
 * 
 * Advanced encrypted storage system with steganographic capabilities,
 * quantum-resistant encryption, and anti-forensic features.
 * 
 * Security Level: CLASSIFIED
 * Implementation: C with Windows API integration
 * Built by: Lackadaisical Security
 */

#include "ghostdrive_integration.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Magic number for GhostDrive header
#define GHOSTDRIVE_MAGIC 0x474C4156  // "GLAV" in hex

// Global initialization status
static BOOLEAN ghostdrive_initialized = FALSE;

//=============================================================================
// CORE INITIALIZATION AND CLEANUP
//=============================================================================

BOOLEAN ghostdrive_init(void) {
    if (ghostdrive_initialized) return TRUE;
    
    // Initialize cryptographic library if not already done
    if (lackyvpn_crypto_init() != LACKYVPN_SUCCESS) {
        return FALSE;
    }
    
    ghostdrive_initialized = TRUE;
    return TRUE;
}

//=============================================================================
// KEY DERIVATION FUNCTIONS
//=============================================================================

BOOLEAN ghostdrive_derive_key_from_vpn(encryption_engine_t* vpn_engine, 
                                      const char* passphrase, size_t passphrase_len,
                                      const uint8_t* salt, uint8_t* derived_key) {
    if (!vpn_engine || !passphrase || !salt || !derived_key) return FALSE;
    
    // Combine VPN master key with user passphrase for enhanced security
    uint8_t combined_material[KEY_SIZE_512 + 256];
    size_t combined_len = 0;
    
    // Copy VPN master key
    memcpy(combined_material, vpn_engine->master_key, KEY_SIZE_512);
    combined_len += KEY_SIZE_512;
    
    // Append user passphrase
    size_t copy_len = (passphrase_len > 256) ? 256 : passphrase_len;
    memcpy(combined_material + combined_len, passphrase, copy_len);
    combined_len += copy_len;
    
    // Derive key using PBKDF2 with high iteration count
    lackyvpn_result_t result = lackyvpn_pbkdf2_sha256(
        combined_material, combined_len,
        salt, GHOSTDRIVE_SALT_SIZE,
        100000,  // High iteration count for security
        derived_key, GHOSTDRIVE_KEY_SIZE
    );
    
    // Secure cleanup
    SecureZeroMemory(combined_material, sizeof(combined_material));
    
    return (result == LACKYVPN_SUCCESS);
}

static BOOLEAN derive_drive_key(const char* passphrase, size_t passphrase_len,
                               const uint8_t* salt, uint8_t* derived_key) {
    if (!passphrase || !salt || !derived_key) return FALSE;
    
    return (lackyvpn_pbkdf2_sha256(
        (const uint8_t*)passphrase, passphrase_len,
        salt, GHOSTDRIVE_SALT_SIZE,
        100000,
        derived_key, GHOSTDRIVE_KEY_SIZE
    ) == LACKYVPN_SUCCESS);
}

//=============================================================================
// DRIVE CREATION FUNCTIONS
//=============================================================================

BOOLEAN ghostdrive_create_drive(const char* drive_path, uint64_t size, 
                               ghostdrive_mode_t mode, ghostdrive_crypto_t crypto,
                               const char* passphrase, size_t passphrase_len) {
    if (!drive_path || !passphrase || size == 0) return FALSE;
    
    if (!ghostdrive_initialized && !ghostdrive_init()) return FALSE;
    
    // Create the drive file
    HANDLE file_handle = CreateFileA(
        drive_path,
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        CREATE_NEW,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (file_handle == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    
    // Generate random salt
    uint8_t salt[GHOSTDRIVE_SALT_SIZE];
    lackyvpn_rng_ctx_t rng;
    if (lackyvpn_rng_init(&rng) != LACKYVPN_SUCCESS) {
        CloseHandle(file_handle);
        return FALSE;
    }
    
    if (lackyvpn_rng_generate(&rng, salt, sizeof(salt)) != LACKYVPN_SUCCESS) {
        lackyvpn_rng_cleanup(&rng);
        CloseHandle(file_handle);
        return FALSE;
    }
    
    // Derive encryption key
    uint8_t drive_key[GHOSTDRIVE_KEY_SIZE];
    if (!derive_drive_key(passphrase, passphrase_len, salt, drive_key)) {
        lackyvpn_rng_cleanup(&rng);
        CloseHandle(file_handle);
        return FALSE;
    }
    
    // Create and write header
    ghostdrive_header_t header = {0};
    header.magic = GHOSTDRIVE_MAGIC;
    header.version = 1;
    header.mode = mode;
    header.crypto_algorithm = crypto;
    header.drive_size = size;
    header.data_offset = GHOSTDRIVE_HEADER_SIZE;
    memcpy(header.salt, salt, GHOSTDRIVE_SALT_SIZE);
    
    // Calculate header hash
    lackyvpn_sha512((uint8_t*)&header, 
                   sizeof(header) - sizeof(header.header_hash) - sizeof(header.reserved),
                   header.header_hash);
    
    // Write header to file
    DWORD bytes_written;
    if (!WriteFile(file_handle, &header, sizeof(header), &bytes_written, NULL) ||
        bytes_written != sizeof(header)) {
        lackyvpn_rng_cleanup(&rng);
        CloseHandle(file_handle);
        DeleteFileA(drive_path);
        return FALSE;
    }
    
    // Initialize the drive with random data for anti-forensic purposes
    uint8_t random_buffer[8192];
    uint64_t remaining_size = size - GHOSTDRIVE_HEADER_SIZE;
    
    while (remaining_size > 0) {
        size_t chunk_size = (remaining_size > sizeof(random_buffer)) ? 
                           sizeof(random_buffer) : (size_t)remaining_size;
        
        if (lackyvpn_rng_generate(&rng, random_buffer, chunk_size) != LACKYVPN_SUCCESS) {
            break;
        }
        
        if (!WriteFile(file_handle, random_buffer, (DWORD)chunk_size, &bytes_written, NULL) ||
            bytes_written != chunk_size) {
            break;
        }
        
        remaining_size -= chunk_size;
    }
    
    // Secure cleanup
    SecureZeroMemory(drive_key, sizeof(drive_key));
    SecureZeroMemory(random_buffer, sizeof(random_buffer));
    lackyvpn_rng_cleanup(&rng);
    CloseHandle(file_handle);
    
    return (remaining_size == 0);
}

//=============================================================================
// DRIVE MOUNTING FUNCTIONS
//=============================================================================

BOOLEAN ghostdrive_mount_drive(ghostdrive_ctx_t* ctx, const char* drive_path, 
                              const char* passphrase, size_t passphrase_len) {
    if (!ctx || !drive_path || !passphrase) return FALSE;
    
    if (!ghostdrive_initialized && !ghostdrive_init()) return FALSE;
    
    // Clear context
    memset(ctx, 0, sizeof(ghostdrive_ctx_t));
    
    // Open the drive file
    ctx->file_handle = CreateFileA(
        drive_path,
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (ctx->file_handle == INVALID_HANDLE_VALUE) {
        return FALSE;
    }
    
    // Read and verify header
    DWORD bytes_read;
    if (!ReadFile(ctx->file_handle, &ctx->header, sizeof(ctx->header), &bytes_read, NULL) ||
        bytes_read != sizeof(ctx->header)) {
        CloseHandle(ctx->file_handle);
        return FALSE;
    }
    
    // Verify magic number
    if (ctx->header.magic != GHOSTDRIVE_MAGIC) {
        CloseHandle(ctx->file_handle);
        return FALSE;
    }
    
    // Verify header integrity
    uint8_t calculated_hash[64];
    lackyvpn_sha512((uint8_t*)&ctx->header, 
                   sizeof(ctx->header) - sizeof(ctx->header.header_hash) - sizeof(ctx->header.reserved),
                   calculated_hash);
    
    if (memcmp(calculated_hash, ctx->header.header_hash, sizeof(calculated_hash)) != 0) {
        CloseHandle(ctx->file_handle);
        return FALSE;
    }
    
    // Derive drive key
    if (!derive_drive_key(passphrase, passphrase_len, ctx->header.salt, ctx->drive_key)) {
        CloseHandle(ctx->file_handle);
        return FALSE;
    }
    
    // Initialize cryptographic contexts based on algorithm
    switch (ctx->header.crypto_algorithm) {
        case GHOSTDRIVE_CRYPTO_AES256_XTS: {
            if (lackyvpn_aes_init(&ctx->aes_ctx, ctx->drive_key, 32) != LACKYVPN_SUCCESS) {
                CloseHandle(ctx->file_handle);
                return FALSE;
            }
            break;
        }
        
        case GHOSTDRIVE_CRYPTO_CHACHA20_POLY1305: {
            memcpy(ctx->chacha20_ctx.key, ctx->drive_key, 32);
            break;
        }
        
        case GHOSTDRIVE_CRYPTO_KYBER_HYBRID: {
            // Initialize Kyber context for quantum-resistant encryption
            ctx->kyber_ctx.security_level = 1024;
            break;
        }
        
        case GHOSTDRIVE_CRYPTO_TRIPLE_CASCADE: {
            // Initialize all contexts for cascade encryption
            if (lackyvpn_aes_init(&ctx->aes_ctx, ctx->drive_key, 32) != LACKYVPN_SUCCESS) {
                CloseHandle(ctx->file_handle);
                return FALSE;
            }
            memcpy(ctx->chacha20_ctx.key, ctx->drive_key + 32, 32);
            ctx->kyber_ctx.security_level = 1024;
            break;
        }
        
        default:
            CloseHandle(ctx->file_handle);
            return FALSE;
    }
    
    ctx->is_mounted = TRUE;
    ctx->current_sector = 0;
    ctx->write_protected = FALSE;
    ctx->access_count = 0;
    
    return TRUE;
}

BOOLEAN ghostdrive_unmount_drive(ghostdrive_ctx_t* ctx) {
    if (!ctx || !ctx->is_mounted) return FALSE;
    
    // Secure cleanup of cryptographic material
    SecureZeroMemory(ctx->drive_key, sizeof(ctx->drive_key));
    SecureZeroMemory(&ctx->aes_ctx, sizeof(ctx->aes_ctx));
    SecureZeroMemory(&ctx->chacha20_ctx, sizeof(ctx->chacha20_ctx));
    SecureZeroMemory(&ctx->kyber_ctx, sizeof(ctx->kyber_ctx));
    
    // Close file handle
    if (ctx->file_handle != INVALID_HANDLE_VALUE) {
        CloseHandle(ctx->file_handle);
        ctx->file_handle = INVALID_HANDLE_VALUE;
    }
    
    // Clean up steganographic resources
    if (ctx->cover_file_path) {
        free(ctx->cover_file_path);
        ctx->cover_file_path = NULL;
    }
    
    ctx->is_mounted = FALSE;
    
    return TRUE;
}

//=============================================================================
// SECTOR I/O FUNCTIONS
//=============================================================================

BOOLEAN ghostdrive_read_sector(ghostdrive_ctx_t* ctx, uint64_t sector, 
                              uint8_t* buffer, size_t buffer_size) {
    if (!ctx || !ctx->is_mounted || !buffer || buffer_size < GHOSTDRIVE_SECTOR_SIZE) {
        return FALSE;
    }
    
    // Calculate file position
    uint64_t file_position = ctx->header.data_offset + (sector * GHOSTDRIVE_SECTOR_SIZE);
    
    // Seek to position
    LARGE_INTEGER seek_pos;
    seek_pos.QuadPart = file_position;
    if (!SetFilePointerEx(ctx->file_handle, seek_pos, NULL, FILE_BEGIN)) {
        return FALSE;
    }
    
    // Read encrypted sector
    uint8_t encrypted_sector[GHOSTDRIVE_SECTOR_SIZE];
    DWORD bytes_read;
    if (!ReadFile(ctx->file_handle, encrypted_sector, GHOSTDRIVE_SECTOR_SIZE, &bytes_read, NULL) ||
        bytes_read != GHOSTDRIVE_SECTOR_SIZE) {
        return FALSE;
    }
    
    // Decrypt sector based on algorithm
    BOOLEAN decrypt_success = FALSE;
    
    switch (ctx->header.crypto_algorithm) {
        case GHOSTDRIVE_CRYPTO_AES256_XTS: {
            // Use sector number as tweak for XTS mode
            uint8_t tweak[16] = {0};
            memcpy(tweak, &sector, sizeof(sector));
            
            decrypt_success = (lackyvpn_aes_xts_decrypt(&ctx->aes_ctx, encrypted_sector, 
                                                       GHOSTDRIVE_SECTOR_SIZE, tweak, buffer) == LACKYVPN_SUCCESS);
            break;
        }
        
        case GHOSTDRIVE_CRYPTO_CHACHA20_POLY1305: {
            // Use sector number in nonce
            uint8_t nonce[12] = {0};
            memcpy(nonce, &sector, sizeof(sector));
            
            decrypt_success = (lackyvpn_chacha20_poly1305_decrypt(ctx->chacha20_ctx.key, nonce,
                                                                 encrypted_sector, GHOSTDRIVE_SECTOR_SIZE - 16,
                                                                 NULL, 0, buffer,
                                                                 encrypted_sector + GHOSTDRIVE_SECTOR_SIZE - 16) == LACKYVPN_SUCCESS);
            break;
        }
        
        case GHOSTDRIVE_CRYPTO_TRIPLE_CASCADE: {
            // Triple cascade decryption: Kyber -> ChaCha20 -> AES
            uint8_t temp_buffer1[GHOSTDRIVE_SECTOR_SIZE];
            uint8_t temp_buffer2[GHOSTDRIVE_SECTOR_SIZE];
            
            // First pass: Kyber (simplified)
            memcpy(temp_buffer1, encrypted_sector, GHOSTDRIVE_SECTOR_SIZE);
            
            // Second pass: ChaCha20
            uint8_t nonce[12] = {0};
            memcpy(nonce, &sector, sizeof(sector));
            if (lackyvpn_chacha20_poly1305_decrypt(ctx->chacha20_ctx.key, nonce,
                                                  temp_buffer1, GHOSTDRIVE_SECTOR_SIZE - 16,
                                                  NULL, 0, temp_buffer2,
                                                  temp_buffer1 + GHOSTDRIVE_SECTOR_SIZE - 16) == LACKYVPN_SUCCESS) {
                
                // Third pass: AES-XTS
                uint8_t tweak[16] = {0};
                memcpy(tweak, &sector, sizeof(sector));
                decrypt_success = (lackyvpn_aes_xts_decrypt(&ctx->aes_ctx, temp_buffer2, 
                                                           GHOSTDRIVE_SECTOR_SIZE - 16, tweak, buffer) == LACKYVPN_SUCCESS);
            }
            
            SecureZeroMemory(temp_buffer1, sizeof(temp_buffer1));
            SecureZeroMemory(temp_buffer2, sizeof(temp_buffer2));
            break;
        }
        
        default:
            decrypt_success = FALSE;
    }
    
    if (decrypt_success) {
        ctx->current_sector = sector;
        ctx->access_count++;
        ctx->last_access_time = GetTickCount64();
    }
    
    SecureZeroMemory(encrypted_sector, sizeof(encrypted_sector));
    return decrypt_success;
}

BOOLEAN ghostdrive_write_sector(ghostdrive_ctx_t* ctx, uint64_t sector, 
                               const uint8_t* data, size_t data_size) {
    if (!ctx || !ctx->is_mounted || ctx->write_protected || !data || 
        data_size != GHOSTDRIVE_SECTOR_SIZE) {
        return FALSE;
    }
    
    uint8_t encrypted_sector[GHOSTDRIVE_SECTOR_SIZE];
    BOOLEAN encrypt_success = FALSE;
    
    // Encrypt sector based on algorithm
    switch (ctx->header.crypto_algorithm) {
        case GHOSTDRIVE_CRYPTO_AES256_XTS: {
            uint8_t tweak[16] = {0};
            memcpy(tweak, &sector, sizeof(sector));
            
            encrypt_success = (lackyvpn_aes_xts_encrypt(&ctx->aes_ctx, data, 
                                                       GHOSTDRIVE_SECTOR_SIZE, tweak, encrypted_sector) == LACKYVPN_SUCCESS);
            break;
        }
        
        case GHOSTDRIVE_CRYPTO_CHACHA20_POLY1305: {
            uint8_t nonce[12] = {0};
            memcpy(nonce, &sector, sizeof(sector));
            
            encrypt_success = (lackyvpn_chacha20_poly1305_encrypt(ctx->chacha20_ctx.key, nonce,
                                                                 data, GHOSTDRIVE_SECTOR_SIZE,
                                                                 NULL, 0, encrypted_sector,
                                                                 encrypted_sector + GHOSTDRIVE_SECTOR_SIZE - 16) == LACKYVPN_SUCCESS);
            break;
        }
        
        case GHOSTDRIVE_CRYPTO_TRIPLE_CASCADE: {
            uint8_t temp_buffer1[GHOSTDRIVE_SECTOR_SIZE];
            uint8_t temp_buffer2[GHOSTDRIVE_SECTOR_SIZE];
            
            // First pass: AES-XTS
            uint8_t tweak[16] = {0};
            memcpy(tweak, &sector, sizeof(sector));
            if (lackyvpn_aes_xts_encrypt(&ctx->aes_ctx, data, GHOSTDRIVE_SECTOR_SIZE, 
                                        tweak, temp_buffer1) == LACKYVPN_SUCCESS) {
                
                // Second pass: ChaCha20
                uint8_t nonce[12] = {0};
                memcpy(nonce, &sector, sizeof(sector));
                if (lackyvpn_chacha20_poly1305_encrypt(ctx->chacha20_ctx.key, nonce,
                                                      temp_buffer1, GHOSTDRIVE_SECTOR_SIZE,
                                                      NULL, 0, temp_buffer2,
                                                      temp_buffer2 + GHOSTDRIVE_SECTOR_SIZE - 16) == LACKYVPN_SUCCESS) {
                    
                    // Third pass: Kyber (simplified)
                    memcpy(encrypted_sector, temp_buffer2, GHOSTDRIVE_SECTOR_SIZE);
                    encrypt_success = TRUE;
                }
            }
            
            SecureZeroMemory(temp_buffer1, sizeof(temp_buffer1));
            SecureZeroMemory(temp_buffer2, sizeof(temp_buffer2));
            break;
        }
        
        default:
            encrypt_success = FALSE;
    }
    
    if (!encrypt_success) {
        SecureZeroMemory(encrypted_sector, sizeof(encrypted_sector));
        return FALSE;
    }
    
    // Calculate file position and write
    uint64_t file_position = ctx->header.data_offset + (sector * GHOSTDRIVE_SECTOR_SIZE);
    
    LARGE_INTEGER seek_pos;
    seek_pos.QuadPart = file_position;
    if (!SetFilePointerEx(ctx->file_handle, seek_pos, NULL, FILE_BEGIN)) {
        SecureZeroMemory(encrypted_sector, sizeof(encrypted_sector));
        return FALSE;
    }
    
    DWORD bytes_written;
    BOOLEAN write_success = WriteFile(ctx->file_handle, encrypted_sector, 
                                     GHOSTDRIVE_SECTOR_SIZE, &bytes_written, NULL) &&
                           (bytes_written == GHOSTDRIVE_SECTOR_SIZE);
    
    if (write_success) {
        ctx->current_sector = sector;
        ctx->access_count++;
        ctx->last_access_time = GetTickCount64();
        FlushFileBuffers(ctx->file_handle);
    }
    
    SecureZeroMemory(encrypted_sector, sizeof(encrypted_sector));
    return write_success;
}

//=============================================================================
// STEGANOGRAPHIC FUNCTIONS
//=============================================================================

BOOLEAN ghostdrive_create_stego_drive(const char* cover_file, const char* drive_path,
                                     uint64_t size, const char* passphrase, size_t passphrase_len) {
    if (!cover_file || !drive_path || !passphrase || size == 0) return FALSE;
    
    // TODO: Implement steganographic drive creation
    // This would involve:
    // 1. Analyzing the cover file structure
    // 2. Finding suitable locations for data hiding
    // 3. Creating a mapping of hidden data locations
    // 4. Encrypting and embedding the drive data
    
    return FALSE; // Placeholder
}

BOOLEAN ghostdrive_extract_stego_drive(const char* cover_file, const char* output_path,
                                      const char* passphrase, size_t passphrase_len) {
    if (!cover_file || !output_path || !passphrase) return FALSE;
    
    // TODO: Implement steganographic drive extraction
    return FALSE; // Placeholder
}

//=============================================================================
// ANTI-FORENSIC FUNCTIONS
//=============================================================================

BOOLEAN ghostdrive_secure_delete(const char* file_path) {
    if (!file_path) return FALSE;
    
    HANDLE file_handle = CreateFileA(
        file_path,
        GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    
    if (file_handle == INVALID_HANDLE_VALUE) return FALSE;
    
    // Get file size
    LARGE_INTEGER file_size;
    if (!GetFileSizeEx(file_handle, &file_size)) {
        CloseHandle(file_handle);
        return FALSE;
    }
    
    // Overwrite file with random data multiple times
    lackyvpn_rng_ctx_t rng;
    if (lackyvpn_rng_init(&rng) != LACKYVPN_SUCCESS) {
        CloseHandle(file_handle);
        return FALSE;
    }
    
    uint8_t random_buffer[8192];
    const int overwrite_passes = 7; // DOD 5220.22-M standard
    
    for (int pass = 0; pass < overwrite_passes; pass++) {
        SetFilePointer(file_handle, 0, NULL, FILE_BEGIN);
        
        uint64_t remaining = file_size.QuadPart;
        while (remaining > 0) {
            size_t chunk_size = (remaining > sizeof(random_buffer)) ? 
                               sizeof(random_buffer) : (size_t)remaining;
            
            if (lackyvpn_rng_generate(&rng, random_buffer, chunk_size) != LACKYVPN_SUCCESS) {
                break;
            }
            
            DWORD bytes_written;
            if (!WriteFile(file_handle, random_buffer, (DWORD)chunk_size, &bytes_written, NULL)) {
                break;
            }
            
            remaining -= chunk_size;
        }
        
        FlushFileBuffers(file_handle);
    }
    
    lackyvpn_rng_cleanup(&rng);
    CloseHandle(file_handle);
    
    // Delete the file
    return DeleteFileA(file_path);
}

BOOLEAN ghostdrive_activate_honeypot(ghostdrive_ctx_t* ctx) {
    if (!ctx) return FALSE;
    
    ctx->honeypot_active = TRUE;
    
    // TODO: Implement honeypot mechanisms
    // This could include:
    // 1. Fake data generation
    // 2. Access pattern monitoring
    // 3. Intrusion detection
    
    return TRUE;
}

BOOLEAN ghostdrive_emergency_wipe(ghostdrive_ctx_t* ctx) {
    if (!ctx || !ctx->is_mounted) return FALSE;
    
    // Immediate key destruction
    SecureZeroMemory(ctx->drive_key, sizeof(ctx->drive_key));
    SecureZeroMemory(&ctx->aes_ctx, sizeof(ctx->aes_ctx));
    SecureZeroMemory(&ctx->chacha20_ctx, sizeof(ctx->chacha20_ctx));
    
    // Overwrite header with random data
    uint8_t random_header[GHOSTDRIVE_HEADER_SIZE];
    lackyvpn_rng_ctx_t rng;
    
    if (lackyvpn_rng_init(&rng) == LACKYVPN_SUCCESS) {
        if (lackyvpn_rng_generate(&rng, random_header, sizeof(random_header)) == LACKYVPN_SUCCESS) {
            SetFilePointer(ctx->file_handle, 0, NULL, FILE_BEGIN);
            
            DWORD bytes_written;
            WriteFile(ctx->file_handle, random_header, sizeof(random_header), &bytes_written, NULL);
            FlushFileBuffers(ctx->file_handle);
        }
        lackyvpn_rng_cleanup(&rng);
    }
    
    SecureZeroMemory(random_header, sizeof(random_header));
    
    // Force unmount
    ghostdrive_unmount_drive(ctx);
    
    return TRUE;
}

//=============================================================================
// UTILITY FUNCTIONS
//=============================================================================

void ghostdrive_cleanup(ghostdrive_ctx_t* ctx) {
    if (!ctx) return;
    
    if (ctx->is_mounted) {
        ghostdrive_unmount_drive(ctx);
    }
    
    SecureZeroMemory(ctx, sizeof(ghostdrive_ctx_t));
}

BOOLEAN ghostdrive_verify_integrity(ghostdrive_ctx_t* ctx) {
    if (!ctx || !ctx->is_mounted) return FALSE;
    
    // Verify header hash
    uint8_t calculated_hash[64];
    lackyvpn_sha512((uint8_t*)&ctx->header, 
                   sizeof(ctx->header) - sizeof(ctx->header.header_hash) - sizeof(ctx->header.reserved),
                   calculated_hash);
    
    return (memcmp(calculated_hash, ctx->header.header_hash, sizeof(calculated_hash)) == 0);
}

uint64_t ghostdrive_get_free_space(ghostdrive_ctx_t* ctx) {
    if (!ctx || !ctx->is_mounted) return 0;
    
    return ctx->header.drive_size - ctx->header.data_offset;
}
