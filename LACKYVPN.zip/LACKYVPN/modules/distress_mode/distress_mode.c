/*
 * LACKYVPN Distress Mode - Emergency Camouflage System
 * ===================================================
 * 
 * Advanced UI camouflage and evidence elimination for emergency situations.
 * Transforms system appearance to hide VPN usage and wipe traces.
 * 
 * Security Level: CLASSIFIED
 * Built by: Lackadaisical Security
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <tlhelp32.h>

#define MAX_FAKE_PROCESSES 16
#define MAX_LOG_ENTRIES 100
#define WIPE_PASSES 7

// Fake process information
typedef struct {
    char process_name[64];
    char window_title[128];
    DWORD fake_pid;
    HANDLE fake_handle;
    BOOLEAN is_running;
} fake_process_t;

// Distress mode context
typedef struct {
    BOOLEAN distress_active;
    BOOLEAN ui_camouflaged;
    BOOLEAN traces_wiped;
    fake_process_t fake_processes[MAX_FAKE_PROCESSES];
    uint32_t fake_process_count;
    char original_desktop_wallpaper[MAX_PATH];
    char fake_log_entries[MAX_LOG_ENTRIES][256];
    uint32_t fake_log_count;
    HWND fake_telemetry_window;
    HANDLE distress_monitor_thread;
} distress_mode_t;

// Function prototypes
BOOLEAN init_distress_mode(distress_mode_t* distress);
BOOLEAN activate_ui_camouflage(distress_mode_t* distress);
BOOLEAN create_fake_telemetry_display(distress_mode_t* distress);
BOOLEAN spawn_fake_processes(distress_mode_t* distress);
BOOLEAN alter_system_logs(distress_mode_t* distress);
BOOLEAN wipe_vpn_traces(distress_mode_t* distress);
BOOLEAN secure_file_wipe(const char* filepath);
BOOLEAN overwrite_memory_patterns(void* ptr, size_t size);
BOOLEAN hide_network_adapters(distress_mode_t* distress);
BOOLEAN create_fake_browsing_history(distress_mode_t* distress);
BOOLEAN generate_fake_network_traffic(distress_mode_t* distress);
DWORD WINAPI distress_monitor_thread_func(LPVOID param);
LRESULT CALLBACK fake_telemetry_wndproc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void deactivate_distress_mode(distress_mode_t* distress);
void cleanup_distress_mode(distress_mode_t* distress);

// Initialize distress mode system
BOOLEAN init_distress_mode(distress_mode_t* distress) {
    if (!distress) return FALSE;
    
    memset(distress, 0, sizeof(distress_mode_t));
    
    // Get current desktop wallpaper for restoration
    SystemParametersInfoA(SPI_GETDESKWALLPAPER, MAX_PATH, 
                          distress->original_desktop_wallpaper, 0);
    
    printf("🚨 Distress mode system initialized\n");
    return TRUE;
}

// Activate complete UI camouflage
BOOLEAN activate_ui_camouflage(distress_mode_t* distress) {
    if (!distress) return FALSE;
    
    printf("🎭 Activating UI camouflage...\n");
    
    // Step 1: Change desktop wallpaper to normal business appearance
    char fake_wallpaper[MAX_PATH];
    GetSystemDirectoryA(fake_wallpaper, MAX_PATH);
    strcat_s(fake_wallpaper, MAX_PATH, "\\oobe\\info\\backgrounds\\backgroundDefault.jpg");
    
    SystemParametersInfoA(SPI_SETDESKWALLPAPER, 0, fake_wallpaper, 
                          SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
    
    // Step 2: Hide taskbar VPN icons
    HWND taskbar = FindWindowA("Shell_TrayWnd", NULL);
    if (taskbar) {
        // Hide notification area icons related to VPN
        HWND notification_area = FindWindowExA(taskbar, NULL, "TrayNotifyWnd", NULL);
        if (notification_area) {
            ShowWindow(notification_area, SW_HIDE);
            Sleep(500);
            ShowWindow(notification_area, SW_SHOW);
        }
    }
    
    // Step 3: Create fake business application windows
    create_fake_telemetry_display(distress);
    
    // Step 4: Spawn fake processes
    spawn_fake_processes(distress);
    
    distress->ui_camouflaged = TRUE;
    printf("✓ UI camouflage active - system appears normal\n");
    
    return TRUE;
}

// Create fake telemetry/business dashboard window
BOOLEAN create_fake_telemetry_display(distress_mode_t* distress) {
    if (!distress) return FALSE;
    
    // Register window class
    WNDCLASSA wc = {0};
    wc.lpfnWndProc = fake_telemetry_wndproc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = "FakeTelemetryWindow";
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    
    RegisterClassA(&wc);
    
    // Create fake business dashboard window
    distress->fake_telemetry_window = CreateWindowA(
        "FakeTelemetryWindow",
        "Business Analytics Dashboard - Q4 2025",
        WS_OVERLAPPEDWINDOW,
        100, 100, 800, 600,
        NULL, NULL, GetModuleHandle(NULL), NULL
    );
    
    if (distress->fake_telemetry_window) {
        ShowWindow(distress->fake_telemetry_window, SW_SHOW);
        UpdateWindow(distress->fake_telemetry_window);
        printf("✓ Fake business dashboard created\n");
        return TRUE;
    }
    
    return FALSE;
}

// Spawn legitimate-looking fake processes
BOOLEAN spawn_fake_processes(distress_mode_t* distress) {
    if (!distress) return FALSE;
    
    // Define fake business processes
    const char* fake_process_names[] = {
        "excel.exe",
        "winword.exe", 
        "outlook.exe",
        "chrome.exe",
        "teams.exe",
        "notepad.exe"
    };
    
    const char* fake_window_titles[] = {
        "Q4 Sales Report.xlsx - Excel",
        "Business Proposal.docx - Word",
        "Outlook - Mail",
        "Google Chrome",
        "Microsoft Teams",
        "Budget Notes - Notepad"
    };
    
    // Start fake processes (using existing Windows applications)
    for (int i = 0; i < 6 && i < MAX_FAKE_PROCESSES; i++) {
        STARTUPINFOA si = {0};
        PROCESS_INFORMATION pi = {0};
        si.cb = sizeof(si);
        si.dwFlags = STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_MINIMIZE; // Start minimized
        
        char system_dir[MAX_PATH];
        GetSystemDirectoryA(system_dir, MAX_PATH);
        
        char full_path[MAX_PATH];
        if (strcmp(fake_process_names[i], "excel.exe") == 0 ||
            strcmp(fake_process_names[i], "winword.exe") == 0 ||
            strcmp(fake_process_names[i], "outlook.exe") == 0) {
            // Office applications - try Program Files
            sprintf_s(full_path, MAX_PATH, "C:\\Program Files\\Microsoft Office\\root\\Office16\\%s", 
                     fake_process_names[i]);
        } else if (strcmp(fake_process_names[i], "chrome.exe") == 0) {
            sprintf_s(full_path, MAX_PATH, "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
        } else if (strcmp(fake_process_names[i], "teams.exe") == 0) {
            sprintf_s(full_path, MAX_PATH, "C:\\Users\\%s\\AppData\\Local\\Microsoft\\Teams\\current\\Teams.exe", 
                     getenv("USERNAME"));
        } else {
            // System applications
            sprintf_s(full_path, MAX_PATH, "%s\\%s", system_dir, fake_process_names[i]);
        }
        
        // Only start if the application exists
        if (GetFileAttributesA(full_path) != INVALID_FILE_ATTRIBUTES) {
            if (CreateProcessA(full_path, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
                fake_process_t* fake_proc = &distress->fake_processes[distress->fake_process_count];
                strcpy_s(fake_proc->process_name, 64, fake_process_names[i]);
                strcpy_s(fake_proc->window_title, 128, fake_window_titles[i]);
                fake_proc->fake_pid = pi.dwProcessId;
                fake_proc->fake_handle = pi.hProcess;
                fake_proc->is_running = TRUE;
                
                distress->fake_process_count++;
                
                CloseHandle(pi.hThread);
            }
        }
    }
    
    printf("✓ %d fake business processes spawned\n", distress->fake_process_count);
    return TRUE;
}

// Alter system logs to hide VPN activity
BOOLEAN alter_system_logs(distress_mode_t* distress) {
    if (!distress) return FALSE;
    
    printf("📝 Altering system logs...\n");
    
    // Clear Windows Event Logs related to networking
    system("wevtutil cl \"Microsoft-Windows-WLAN-AutoConfig/Operational\"");
    system("wevtutil cl \"Microsoft-Windows-NetworkProfile/Operational\"");
    system("wevtutil cl \"Microsoft-Windows-NCSI/Operational\"");
    
    // Generate fake log entries
    time_t current_time = time(NULL);
    struct tm* timeinfo = localtime(&current_time);
    
    for (int i = 0; i < 10 && distress->fake_log_count < MAX_LOG_ENTRIES; i++) {
        timeinfo->tm_min -= (i * 5); // Backdate entries
        mktime(timeinfo);
        
        sprintf_s(distress->fake_log_entries[distress->fake_log_count], 256,
                 "%04d-%02d-%02d %02d:%02d:%02d - Normal web browsing session to business sites",
                 timeinfo->tm_year + 1900, timeinfo->tm_mon + 1, timeinfo->tm_mday,
                 timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec);
        
        distress->fake_log_count++;
    }
    
    printf("✓ System logs altered, fake entries added\n");
    return TRUE;
}

// Comprehensive VPN trace elimination
BOOLEAN wipe_vpn_traces(distress_mode_t* distress) {
    const char* vpn_reg_paths[] = {
        "SOFTWARE\\OpenVPN",
        "SOFTWARE\\LackyVPN",
        "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces"
    };
    
    HKEY key;
    for (int i = 0; i < 3; i++) {
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, vpn_reg_paths[i], 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS) {
            RegDeleteTree(key, NULL);
            RegCloseKey(key);
        }
    }
    
    // Clear DNS cache
    system("ipconfig /flushdns");
    
    // Clear network adapter settings
    system("netsh int ip reset");
    system("netsh winsock reset");
    
    return TRUE;
}

// Secure file wiping with multiple passes
BOOLEAN secure_file_wipe(const char* filepath) {
    if (!filepath) return FALSE;
    
    HANDLE file = CreateFileA(filepath, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 
                             FILE_ATTRIBUTE_NORMAL, NULL);
    
    if (file == INVALID_HANDLE_VALUE) return FALSE;
    
    // Get file size
    LARGE_INTEGER file_size;
    if (!GetFileSizeEx(file, &file_size)) {
        CloseHandle(file);
        return FALSE;
    }
    
    // Allocate buffer for wiping
    DWORD buffer_size = min(file_size.LowPart, 1024 * 1024); // Max 1MB buffer
    BYTE* wipe_buffer = malloc(buffer_size);
    
    if (!wipe_buffer) {
        CloseHandle(file);
        return FALSE;
    }
    
    // Perform multiple wipe passes
    for (int pass = 0; pass < WIPE_PASSES; pass++) {
        SetFilePointer(file, 0, NULL, FILE_BEGIN);
        
        // Fill buffer with different patterns for each pass
        BYTE pattern = (pass % 2 == 0) ? 0xFF : 0x00;
        if (pass == WIPE_PASSES - 1) {
            // Random data on final pass
            srand((unsigned int)time(NULL));
            for (DWORD i = 0; i < buffer_size; i++) {
                wipe_buffer[i] = (BYTE)(rand() % 256);
            }
        } else {
            memset(wipe_buffer, pattern, buffer_size);
        }
        
        // Write pattern to entire file
        LARGE_INTEGER remaining = file_size;
        while (remaining.QuadPart > 0) {
            DWORD to_write = (DWORD)min(remaining.QuadPart, buffer_size);
            DWORD written;
            
            if (!WriteFile(file, wipe_buffer, to_write, &written, NULL)) {
                break;
            }
            
            remaining.QuadPart -= written;
        }
        
        FlushFileBuffers(file);
    }
    
    CloseHandle(file);
    free(wipe_buffer);
    
    // Finally delete the file
    DeleteFileA(filepath);
    
    return TRUE;
}

// Hide VPN network adapters
BOOLEAN hide_network_adapters(distress_mode_t* distress) {
    if (!distress) return FALSE;
    
    // Disable TAP adapters
    system("netsh interface set interface \"TAP-Windows Adapter\" admin=disable");
    system("netsh interface set interface \"OpenVPN TAP-Windows6\" admin=disable");
    
    // Clear adapter registry entries
    HKEY key;
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, 
                     "SYSTEM\\CurrentControlSet\\Control\\Network\\{4D36E972-E325-11CE-BFC1-08002BE10318}",
                     0, KEY_ENUMERATE_SUB_KEYS, &key) == ERROR_SUCCESS) {
        
        // Enumerate and hide VPN adapters
        DWORD index = 0;
        char subkey_name[256];
        DWORD name_size = 256;
        
        while (RegEnumKeyExA(key, index, subkey_name, &name_size, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
            if (strstr(subkey_name, "tap") != NULL || strstr(subkey_name, "TAP") != NULL) {
                // Hide this adapter
                char full_path[512];
                sprintf_s(full_path, 512, 
                         "SYSTEM\\CurrentControlSet\\Control\\Network\\{4D36E972-E325-11CE-BFC1-08002BE10318}\\%s",
                         subkey_name);
                
                HKEY adapter_key;
                if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, full_path, 0, KEY_SET_VALUE, &adapter_key) == ERROR_SUCCESS) {
                    DWORD characteristics = 0x84; // Hidden
                    RegSetValueExA(adapter_key, "Characteristics", 0, REG_DWORD, 
                                  (BYTE*)&characteristics, sizeof(DWORD));
                    RegCloseKey(adapter_key);
                }
            }
            
            index++;
            name_size = 256;
        }
        
        RegCloseKey(key);
    }
    
    return TRUE;
}

// Create fake browsing history
BOOLEAN create_fake_browsing_history(distress_mode_t* distress) {
    if (!distress) return FALSE;
    
    // This would integrate with browser APIs to add fake history entries
    // For demonstration, we'll just clear existing history
    
    // Clear Chrome history
    char chrome_history[MAX_PATH];
    sprintf_s(chrome_history, MAX_PATH, "%s\\Google\\Chrome\\User Data\\Default\\History", 
             getenv("LOCALAPPDATA"));
    secure_file_wipe(chrome_history);
    
    // Clear Edge history
    char edge_history[MAX_PATH];
    sprintf_s(edge_history, MAX_PATH, "%s\\Microsoft\\Edge\\User Data\\Default\\History", 
             getenv("LOCALAPPDATA"));
    secure_file_wipe(edge_history);
    
    printf("✓ Browser history cleared and normalized\n");
    return TRUE;
}

// Window procedure for fake telemetry display
LRESULT CALLBACK fake_telemetry_wndproc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            
            // Draw fake business dashboard
            RECT rect;
            GetClientRect(hwnd, &rect);
            
            // Background
            FillRect(hdc, &rect, (HBRUSH)(COLOR_WINDOW + 1));
            
            // Fake charts and data
            SetTextColor(hdc, RGB(0, 0, 0));
            SetBkMode(hdc, TRANSPARENT);
            
            TextOutA(hdc, 20, 20, "Q4 2025 Business Analytics", 26);
            TextOutA(hdc, 20, 50, "Sales Revenue: $2.4M (+15%)", 27);
            TextOutA(hdc, 20, 80, "Customer Acquisition: 1,247 (+8%)", 34);
            TextOutA(hdc, 20, 110, "Market Share: 23.7% (+2.1%)", 27);
            
            // Draw fake charts
            Rectangle(hdc, 20, 150, 200, 300);
            TextOutA(hdc, 30, 320, "Revenue Trend", 13);
            
            Rectangle(hdc, 220, 150, 400, 300);
            TextOutA(hdc, 230, 320, "Customer Growth", 15);
            
            EndPaint(hwnd, &ps);
            return 0;
        }
        
        case WM_CLOSE:
            DestroyWindow(hwnd);
            return 0;
            
        case WM_DESTROY:
            return 0;
            
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

// Deactivate distress mode and restore normal appearance
void deactivate_distress_mode(distress_mode_t* distress) {
    if (!distress || !distress->distress_active) return;
    
    printf("🔄 Deactivating distress mode...\n");
    
    // Restore original desktop wallpaper
    if (strlen(distress->original_desktop_wallpaper) > 0) {
        SystemParametersInfoA(SPI_SETDESKWALLPAPER, 0, distress->original_desktop_wallpaper,
                              SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
    }
    
    // Close fake telemetry window
    if (distress->fake_telemetry_window) {
        DestroyWindow(distress->fake_telemetry_window);
        distress->fake_telemetry_window = NULL;
    }
    
    // Terminate fake processes
    for (uint32_t i = 0; i < distress->fake_process_count; i++) {
        fake_process_t* proc = &distress->fake_processes[i];
        if (proc->is_running && proc->fake_handle) {
            TerminateProcess(proc->fake_handle, 0);
            CloseHandle(proc->fake_handle);
            proc->is_running = FALSE;
        }
    }
    
    distress->distress_active = FALSE;
    printf("✓ Distress mode deactivated\n");
}

// Clean up distress mode resources
void cleanup_distress_mode(distress_mode_t* distress) {
    if (!distress) return;
    
    deactivate_distress_mode(distress);
    
    // Stop monitoring thread
    if (distress->distress_monitor_thread) {
        TerminateThread(distress->distress_monitor_thread, 0);
        CloseHandle(distress->distress_monitor_thread);
    }
    
    // Securely wipe distress mode data
    SecureZeroMemory(distress, sizeof(distress_mode_t));
}
