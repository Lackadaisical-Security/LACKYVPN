// L4CKYVPN C0NTR0L SYST3M

// Settings Manager
class SettingsManager {
    constructor() {
        this.settings = {
            'effect-matrix-rain': true,
            'effect-scanlines': true,
            'effect-glitch': true,
            'effect-glow': true,
            'effect-animations': true,
            'effect-sounds': true,
            'effect-terminal': true,
            'effect-bandwidth': true,
            'theme': 'cyberpunk'
        };
        
        this.presets = {
            ultra: {
                'effect-matrix-rain': true,
                'effect-scanlines': true,
                'effect-glitch': true,
                'effect-glow': true,
                'effect-animations': true,
                'effect-sounds': true,
                'effect-terminal': true,
                'effect-bandwidth': true
            },
            high: {
                'effect-matrix-rain': true,
                'effect-scanlines': true,
                'effect-glitch': true,
                'effect-glow': true,
                'effect-animations': true,
                'effect-sounds': true,
                'effect-terminal': false,
                'effect-bandwidth': true
            },
            balanced: {
                'effect-matrix-rain': false,
                'effect-scanlines': true,
                'effect-glitch': true,
                'effect-glow': true,
                'effect-animations': true,
                'effect-sounds': true,
                'effect-terminal': false,
                'effect-bandwidth': true
            },
            low: {
                'effect-matrix-rain': false,
                'effect-scanlines': false,
                'effect-glitch': false,
                'effect-glow': false,
                'effect-animations': false,
                'effect-sounds': true,
                'effect-terminal': false,
                'effect-bandwidth': false
            }
        };
        
        this.loadSettings();
        this.initEventListeners();
        this.applySettings();
    }
    
    loadSettings() {
        const saved = localStorage.getItem('lackyvpn_settings');
        if (saved) {
            try {
                this.settings = JSON.parse(saved);
            } catch (e) {
                console.error('Failed to load settings:', e);
            }
        }
        
        // Update checkboxes
        Object.keys(this.settings).forEach(key => {
            const checkbox = document.getElementById(key);
            if (checkbox) {
                checkbox.checked = this.settings[key];
            }
        });
    }
    
    saveSettings() {
        localStorage.setItem('lackyvpn_settings', JSON.stringify(this.settings));
        this.applySettings();
        this.applyTheme(this.settings.theme || 'cyberpunk');
        
        // Show save confirmation with theme
        const terminal = window.vpnController?.terminal;
        if (terminal) {
            terminal.writeLine('SETTINGS SAVED', '#00ff00');
            terminal.writeLine(`THEME: ${this.settings.theme.toUpperCase()}`, '#00ff00');
        }
    }
    
    resetSettings() {
        Object.keys(this.settings).forEach(key => {
            this.settings[key] = true;
            const checkbox = document.getElementById(key);
            if (checkbox) {
                checkbox.checked = true;
            }
        });
        
        this.saveSettings();
    }
    
    applySettings() {
        // Matrix Rain
        const matrixCanvas = document.getElementById('matrix-rain');
        if (matrixCanvas) {
            matrixCanvas.style.display = this.settings['effect-matrix-rain'] ? 'block' : 'none';
        }
        
        // Scanlines
        const scanlines = document.querySelector('.scanlines');
        if (scanlines) {
            scanlines.style.display = this.settings['effect-scanlines'] ? 'block' : 'none';
        }
        
        // Glitch effects
        if (!this.settings['effect-glitch']) {
            document.body.classList.add('no-glitch');
            document.querySelectorAll('.glitch').forEach(el => {
                el.classList.remove('glitch');
            });
        } else {
            document.body.classList.remove('no-glitch');
            document.querySelectorAll('[data-text]').forEach(el => {
                if (!el.classList.contains('glitch')) {
                    el.classList.add('glitch');
                }
            });
        }
        
        // Glow effects
        document.body.classList.toggle('no-glow', !this.settings['effect-glow']);
        
        // Animations
        document.body.classList.toggle('no-animations', !this.settings['effect-animations']);
        
        // Terminal typing effect
        window.terminalTypingEnabled = this.settings['effect-terminal'];
        
        // Bandwidth monitor
        if (window.vpnController) {
            if (!this.settings['effect-bandwidth']) {
                window.vpnController.stopBandwidthSimulation();
            } else if (window.vpnController.isConnected) {
                window.vpnController.startBandwidthSimulation();
            }
        }
    }
    
    applyTheme(theme) {
        // Remove all theme classes
        document.body.classList.remove('theme-cyberpunk', 'theme-matrix', 'theme-terminal', 'theme-stealth');
        
        // Add new theme class
        document.body.classList.add(`theme-${theme}`);
        
        // Update active theme button
        document.querySelectorAll('.theme-option').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.theme === theme);
        });
        
        // Special handling for different themes
        switch(theme) {
            case 'matrix':
                // Make matrix rain more prominent
                const matrixCanvas = document.getElementById('matrix-rain');
                if (matrixCanvas) {
                    matrixCanvas.style.opacity = '0.3';
                }
                break;
            case 'terminal':
                // Simplify interface
                document.querySelectorAll('.glitch').forEach(el => {
                    el.classList.remove('glitch');
                });
                break;
            case 'stealth':
                // Minimal visuals
                this.applyPreset('low');
                break;
        }
        
        this.settings.theme = theme;
    }
    
    applyPreset(presetName) {
        const preset = this.presets[presetName];
        if (!preset) return;
        
        // Apply preset settings
        Object.keys(preset).forEach(key => {
            this.settings[key] = preset[key];
            const checkbox = document.getElementById(key);
            if (checkbox) {
                checkbox.checked = preset[key];
            }
        });
        
        this.applySettings();
        
        // Show notification
        const terminal = window.vpnController?.terminal;
        if (terminal) {
            terminal.writeLine(`PERFORMANCE PRESET: ${presetName.toUpperCase()} APPLIED`, '#00ff00');
        }
    }
    
    initEventListeners() {
        // Settings toggle button
        const settingsToggle = document.getElementById('settings-toggle');
        const settingsPanel = document.getElementById('settings-panel');
        
        settingsToggle?.addEventListener('click', () => {
            settingsPanel?.classList.toggle('hidden');
        });
        
        // Setting checkboxes
        Object.keys(this.settings).forEach(key => {
            const checkbox = document.getElementById(key);
            checkbox?.addEventListener('change', (e) => {
                this.settings[key] = e.target.checked;
            });
        });
        
        // Save button
        document.getElementById('save-settings')?.addEventListener('click', () => {
            this.saveSettings();
        });
        
        // Reset button
        document.getElementById('reset-settings')?.addEventListener('click', () => {
            if (confirm('R3S3T 4LL S3TT1NGS T0 D3F4ULT?')) {
                this.resetSettings();
            }
        });
        
        // Close settings when clicking outside
        document.addEventListener('click', (e) => {
            if (!settingsPanel?.contains(e.target) && !settingsToggle?.contains(e.target)) {
                settingsPanel?.classList.add('hidden');
            }
        });
        
        // Theme buttons
        document.querySelectorAll('.theme-option').forEach(btn => {
            btn.addEventListener('click', () => {
                this.applyTheme(btn.dataset.theme);
            });
        });
        
        // Preset buttons
        document.querySelectorAll('.preset-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.applyPreset(btn.dataset.preset);
            });
        });
    }
    
    isSoundEnabled() {
        return this.settings['effect-sounds'];
    }
}

// Global settings manager instance
let settingsManager;

// Terminal with optional typing effect
class Terminal {
    constructor(elementId) {
        this.element = document.getElementById(elementId);
        this.lines = [];
    }
    
    writeLine(text, color = '#20C20E') {
        const line = document.createElement('span');
        line.className = 'terminal-line';
        line.style.color = color;
        
        if (window.terminalTypingEnabled !== false) {
            // Typing effect
            line.textContent = '> ';
            this.element.appendChild(line);
            
            let i = 0;
            const typeInterval = setInterval(() => {
                if (i < text.length) {
                    line.textContent += text[i];
                    i++;
                } else {
                    clearInterval(typeInterval);
                }
            }, 20);
        } else {
            // Instant display
            line.textContent = `> ${text}`;
            this.element.appendChild(line);
        }
        
        this.element.scrollTop = this.element.scrollHeight;
        
        // Keep only last 50 lines
        if (this.element.children.length > 50) {
            this.element.removeChild(this.element.firstChild);
        }
    }
    
    clear() {
        this.element.innerHTML = '';
    }
}

// Encryption utilities for client-side
class ClientEncryption {
    constructor() {
        this.sessionKey = null;
    }

    async setSessionKey(keyHex) {
        this.sessionKey = await this.hexToKey(keyHex);
    }

    async hexToKey(hex) {
        const keyData = new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
        return await crypto.subtle.importKey(
            'raw',
            keyData,
            { name: 'AES-GCM' },
            false,
            ['encrypt', 'decrypt']
        );
    }

    async encrypt(data) {
        const iv = crypto.getRandomValues(new Uint8Array(16));
        const encodedData = new TextEncoder().encode(JSON.stringify(data));
        
        const encrypted = await crypto.subtle.encrypt(
            { name: 'AES-GCM', iv: iv, tagLength: 128 },
            this.sessionKey,
            encodedData
        );
        
        // Extract tag from the end of encrypted data
        const encryptedArray = new Uint8Array(encrypted);
        const tag = encryptedArray.slice(-16);
        const ciphertext = encryptedArray.slice(0, -16);
        
        return {
            iv: this.arrayToHex(iv),
            tag: this.arrayToHex(tag),
            data: this.arrayToHex(ciphertext)
        };
    }

    async decrypt(encryptedObj) {
        const iv = this.hexToArray(encryptedObj.iv);
        const tag = this.hexToArray(encryptedObj.tag);
        const ciphertext = this.hexToArray(encryptedObj.data);
        
        // Combine ciphertext and tag for decryption
        const combined = new Uint8Array(ciphertext.length + tag.length);
        combined.set(ciphertext);
        combined.set(tag, ciphertext.length);
        
        const decrypted = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv: iv, tagLength: 128 },
            this.sessionKey,
            combined
        );
        
        const decoded = new TextDecoder().decode(decrypted);
        return JSON.parse(decoded);
    }

    arrayToHex(array) {
        return Array.from(array).map(b => b.toString(16).padStart(2, '0')).join('');
    }

    hexToArray(hex) {
        return new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
    }
}

// VPN Controller with encryption
class VPNController {
    constructor() {
        this.terminal = new Terminal('terminal-output');
        this.isConnected = false;
        this.selectedServer = null;
        this.uptimeInterval = null;
        this.bandwidthInterval = null;
        this.startTime = null;
        this.sessionId = null;
        this.ws = null;
        this.encryption = new ClientEncryption();
        
        this.initEventListeners();
        this.initBandwidthMonitor();
        this.updateClock();
    }
    
    connectWebSocket() {
        // Use secure WebSocket
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        this.ws = new WebSocket(`${protocol}//localhost:1337/ws`);
        
        this.ws.onopen = () => {
            this.terminal.writeLine('SECURE WEBSOCKET CONNECTION ESTABLISHED', '#00ff00');
            
            // Send authentication
            if (this.sessionId) {
                this.ws.send(JSON.stringify({
                    type: 'auth',
                    sessionId: this.sessionId
                }));
            }
        };
        
        this.ws.onmessage = async (event) => {
            const message = JSON.parse(event.data);
            
            switch (message.type) {
                case 'auth_required':
                    // Re-authenticate if needed
                    if (this.sessionId) {
                        this.ws.send(JSON.stringify({
                            type: 'auth',
                            sessionId: this.sessionId
                        }));
                    }
                    break;
                    
                case 'auth_success':
                    this.terminal.writeLine('WEBSOCKET AUTHENTICATED', '#00ff00');
                    break;
                    
                case 'encrypted_status':
                    // Decrypt status update
                    const status = await this.encryption.decrypt(message.data);
                    this.updateFromServerStatus(status);
                    break;
                    
                case 'encrypted_response':
                    // Decrypt response
                    const response = await this.encryption.decrypt(message.data);
                    this.handleServerResponse(response);
                    break;
                    
                case 'error':
                    this.terminal.writeLine(`ERROR: ${message.data.message}`, '#ff0040');
                    break;
            }
        };
        
        this.ws.onerror = () => {
            this.terminal.writeLine('WEBSOCKET CONNECTION ERROR', '#ff0040');
        };
        
        this.ws.onclose = () => {
            this.terminal.writeLine('WEBSOCKET CONNECTION LOST', '#ff0040');
            // Attempt reconnection
            setTimeout(() => this.connectWebSocket(), 5000);
        };
    }
    
    updateFromServerStatus(status) {
        if (status.isConnected && !this.isConnected) {
            // Connection established
            this.isConnected = true;
            this.startTime = Date.now() - status.uptime;
            this.updateConnectionUI(true);
        } else if (!status.isConnected && this.isConnected) {
            // Connection lost
            this.isConnected = false;
            this.updateConnectionUI(false);
        }
        
        if (status.isConnected) {
            // Update stats
            document.getElementById('vpn-ip').textContent = status.stats.currentIP || 'XXX.XXX.XXX.XXX';
            document.getElementById('vpn-location').textContent = status.stats.location || 'UNKN0WN';
            document.getElementById('data-sent').textContent = (status.stats.bytesOut / 1024 / 1024).toFixed(2) + ' MB';
            document.getElementById('data-received').textContent = (status.stats.bytesIn / 1024 / 1024).toFixed(2) + ' MB';
        }
    }
    
    async authenticate() {
        const password = document.getElementById('password').value;
        const yubikey = document.getElementById('yubikey').value;
        
        this.terminal.writeLine('INITIATING SECURE AUTHENTICATION...');
        
        try {
            // Use HTTPS for authentication
            const response = await fetch('https://localhost:1337/api/auth', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ password, yubikey }),
                credentials: 'include'
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.sessionId = result.sessionId;
                await this.encryption.setSessionKey(result.sessionKey);
                
                await this.delay(1000);
                this.terminal.writeLine('AUTHENTICATION SUCCESSFUL', '#00ff00');
                this.terminal.writeLine('SESSION ENCRYPTED WITH AES-256-GCM');
                this.terminal.writeLine('ACCESS GRANTED - WELCOME OPERATOR');
                
                // Connect WebSocket with session
                this.connectWebSocket();
                
                // Show main panel
                document.getElementById('auth-panel').classList.add('hidden');
                document.getElementById('main-panel').classList.remove('hidden');
                
                // Start system
                this.initializeSystem();
            } else {
                this.terminal.writeLine('AUTHENTICATION FAILED', '#ff0040');
                this.terminal.writeLine('ACCESS DENIED');
            }
        } catch (error) {
            this.terminal.writeLine('AUTHENTICATION ERROR: ' + error.message, '#ff0040');
        }
    }
    
    async scanBiometric() {
        const btn = document.getElementById('biometric-scan');
        btn.disabled = true;
        btn.innerHTML = '<span class="btn-text">[ SC4NN1NG... ]</span>';
        
        await this.delay(2000);
        
        btn.innerHTML = '<span class="btn-text">[ SC4N C0MPL3T3 ✓ ]</span>';
        btn.style.borderColor = '#00ff00';
        
        setTimeout(() => {
            btn.disabled = false;
            btn.innerHTML = '<span class="btn-text">[ SC4N F1NG3RPR1NT ]</span>';
            btn.style.borderColor = '';
        }, 3000);
    }
    
    async initializeSystem() {
        this.terminal.writeLine('INITIALIZING LACKYVPN SYSTEMS...');
        
        const systems = [
            '10-LAYER ENCRYPTION ENGINE',
            'GHOST OBFUSCATION MODULE',
            'KILL-SWITCH PROTECTION',
            'DNS LEAK PREVENTION',
            'MAC ADDRESS RANDOMIZER'
        ];
        
        for (const system of systems) {
            await this.delay(500);
            this.terminal.writeLine(`LOADING ${system}... [OK]`, '#00ff00');
        }
        
        await this.delay(1000);
        this.terminal.writeLine('ALL SYSTEMS OPERATIONAL', '#00ff00');
        this.terminal.writeLine('READY FOR CONNECTION');
    }
    
    selectServer(node) {
        // Remove previous selection
        document.querySelectorAll('.server-node').forEach(n => {
            n.classList.remove('active');
        });
        
        // Set new selection
        node.classList.add('active');
        this.selectedServer = node.dataset.server;
        
        this.terminal.writeLine(`SERVER SELECTED: ${node.querySelector('.node-name').textContent}`, '#00ffff');
        
        // Handle custom config
        if (this.selectedServer === 'custom') {
            document.getElementById('config-file').click();
        }
    }
    
    async connect() {
        if (!this.selectedServer) {
            this.terminal.writeLine('ERROR: NO SERVER SELECTED', '#ff0040');
            return;
        }
        
        const connectBtn = document.getElementById('connect-btn');
        connectBtn.disabled = true;
        connectBtn.innerHTML = '<span class="matrix-icon">⚡</span><span>C0NN3CT1NG...</span>';
        
        this.terminal.writeLine('INITIATING ENCRYPTED CONNECTION...');
        
        // Send encrypted connect command
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            const encrypted = await this.encryption.encrypt({
                action: 'connect',
                data: { server: this.selectedServer }
            });
            
            this.ws.send(JSON.stringify({
                type: 'encrypted_message',
                data: encrypted
            }));
        }
    }
    
    handleConnectResult(result) {
        if (result.success) {
            this.terminal.writeLine('CONNECTION ESTABLISHED', '#00ff00');
            this.terminal.writeLine('YOU ARE NOW GHOST ON THE WIRE', '#00ff00');
            this.playSound('connect-sound');
        } else {
            this.terminal.writeLine('CONNECTION FAILED', '#ff0040');
            this.updateConnectionUI(false);
        }
    }
    
    async disconnect() {
        const disconnectBtn = document.getElementById('disconnect-btn');
        disconnectBtn.disabled = true;
        
        this.terminal.writeLine('TERMINATING CONNECTION...');
        
        // Send disconnect command via WebSocket
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                action: 'disconnect',
                data: {}
            }));
        }
    }
    
    handleDisconnectResult(result) {
        if (result.success) {
            this.terminal.writeLine('CONNECTION TERMINATED', '#ffff00');
            this.playSound('disconnect-sound');
        }
    }
    
    async activateDistress() {
        if (confirm('4CT1V4T3 D1STR3SS M0D3? 4LL TR4C3S W1LL B3 3L1M1N4T3D!')) {
            this.terminal.writeLine('!!! DISTRESS MODE ACTIVATED !!!', '#ff0040');
            
            // Play alert sound
            this.playSound('alert-sound');
            
            // Flash screen
            document.body.style.animation = 'danger-flash 0.5s ease-in-out 3';
            
            // Send distress command via WebSocket
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({
                    action: 'distress',
                    data: {}
                }));
            }
            
            // Clear terminal after delay
            setTimeout(() => {
                this.terminal.clear();
                this.terminal.writeLine('SYSTEM READY');
            }, 3000);
        }
    }
    
    updateConnectionUI(connected) {
        const connectBtn = document.getElementById('connect-btn');
        const disconnectBtn = document.getElementById('disconnect-btn');
        
        if (connected) {
            connectBtn.disabled = true;
            connectBtn.innerHTML = '<span class="matrix-icon">✓</span><span>0NL1N3</span>';
            disconnectBtn.disabled = false;
            
            document.getElementById('connection-status').textContent = '[ C0NN3CT3D ]';
            document.getElementById('connection-status').classList.remove('disconnected');
            document.getElementById('connection-status').classList.add('connected');
            
            document.getElementById('vpn-status').textContent = '0NL1N3';
            
            this.startUptime();
            this.startBandwidthSimulation();
        } else {
            connectBtn.disabled = false;
            connectBtn.innerHTML = '<span class="matrix-icon">⚡</span><span>J4CK 1N</span>';
            disconnectBtn.disabled = true;
            
            document.getElementById('connection-status').textContent = '[ D1SC0NN3CT3D ]';
            document.getElementById('connection-status').classList.remove('connected');
            document.getElementById('connection-status').classList.add('disconnected');
            
            this.stopUptime();
            this.stopBandwidthSimulation();
            this.resetStats();
        }
    }

    updateStats() {
        if (!this.isConnected) return;
        
        // Simulate stats
        document.getElementById('vpn-status').textContent = '0NL1N3';
        document.getElementById('vpn-ip').textContent = this.generateRandomIP();
        document.getElementById('vpn-location').textContent = this.getServerLocation();
    }
    
    generateRandomIP() {
        return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
    }
    
    getServerLocation() {
        const locations = {
            'stealth-us.ovpn': 'UN1T3D ST4T3S',
            'ghost-eu.ovpn': '3UR0P3',
            'shadow-asia.ovpn': '4S14',
            'custom': 'UNKN0WN'
        };
        return locations[this.selectedServer] || 'UNKN0WN';
    }
    
    startUptime() {
        this.uptimeInterval = setInterval(() => {
            const elapsed = Date.now() - this.startTime;
            const hours = Math.floor(elapsed / 3600000);
            const minutes = Math.floor((elapsed % 3600000) / 60000);
            const seconds = Math.floor((elapsed % 60000) / 1000);
            
            document.getElementById('vpn-uptime').textContent = 
                `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }, 1000);
    }
    
    stopUptime() {
        if (this.uptimeInterval) {
            clearInterval(this.uptimeInterval);
            this.uptimeInterval = null;
        }
    }
    
    resetStats() {
        document.getElementById('vpn-status').textContent = '0FFL1N3';
        document.getElementById('vpn-ip').textContent = 'XXX.XXX.XXX.XXX';
        document.getElementById('vpn-location').textContent = 'UNKN0WN';
        document.getElementById('vpn-uptime').textContent = '00:00:00';
        document.getElementById('data-sent').textContent = '0.00 MB';
        document.getElementById('data-received').textContent = '0.00 MB';
    }
    
    initBandwidthMonitor() {
        const canvas = document.getElementById('bandwidth-monitor');
        const ctx = canvas.getContext('2d');
        
        // Set canvas size
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        
        // Initialize data
        this.bandwidthData = new Array(50).fill(0);
        
        // Draw function
        this.drawBandwidth = () => {
            ctx.fillStyle = '#000';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Draw grid
            ctx.strokeStyle = '#00ff00';
            ctx.lineWidth = 0.5;
            ctx.globalAlpha = 0.3;
            
            // Horizontal lines
            for (let i = 0; i < 5; i++) {
                const y = (canvas.height / 5) * i;
                ctx.beginPath();
                ctx.moveTo(0, y);
                ctx.lineTo(canvas.width, y);
                ctx.stroke();
            }
            
            // Vertical lines
            for (let i = 0; i < 10; i++) {
                const x = (canvas.width / 10) * i;
                ctx.beginPath();
                ctx.moveTo(x, 0);
                ctx.lineTo(x, canvas.height);
                ctx.stroke();
            }
            
            ctx.globalAlpha = 1;
            
            // Draw bandwidth line
            if (this.isConnected) {
                ctx.strokeStyle = '#00ff00';
                ctx.lineWidth = 2;
                ctx.shadowBlur = 10;
                ctx.shadowColor = '#00ff00';
                
                ctx.beginPath();
                for (let i = 0; i < this.bandwidthData.length; i++) {
                    const x = (canvas.width / this.bandwidthData.length) * i;
                    const y = canvas.height - (this.bandwidthData[i] * canvas.height);
                    
                    if (i === 0) {
                        ctx.moveTo(x, y);
                    } else {
                        ctx.lineTo(x, y);
                    }
                }
                ctx.stroke();
            }
        };
        
        // Initial draw
        this.drawBandwidth();
    }
    
    startBandwidthSimulation() {
        if (!settingsManager?.settings['effect-bandwidth']) {
            return;
        }
        
        let sent = 0;
        let received = 0;
        
        this.bandwidthInterval = setInterval(() => {
            // Simulate bandwidth usage
            const usage = Math.random() * 0.7 + 0.1;
            this.bandwidthData.shift();
            this.bandwidthData.push(usage);
            
            // Update data counters
            sent += Math.random() * 0.5;
            received += Math.random() * 1.2;
            
            document.getElementById('data-sent').textContent = sent.toFixed(2) + ' MB';
            document.getElementById('data-received').textContent = received.toFixed(2) + ' MB';
            
            // Redraw
            this.drawBandwidth();
        }, 200);
    }
    
    stopBandwidthSimulation() {
        if (this.bandwidthInterval) {
            clearInterval(this.bandwidthInterval);
            this.bandwidthInterval = null;
        }
        
        // Clear data
        this.bandwidthData.fill(0);
        this.drawBandwidth();
    }
    
    updateClock() {
        const updateTime = () => {
            const now = new Date();
            const time = now.toTimeString().split(' ')[0];
            document.getElementById('terminal-time').textContent = time;
        };
        
        updateTime();
        setInterval(updateTime, 1000);
    }
    
    playSound(soundId) {
        if (!settingsManager?.isSoundEnabled()) {
            return;
        }
        
        const audio = document.getElementById(soundId);
        if (audio) {
            audio.play().catch(() => {
                // Ignore audio play errors
            });
        }
    }
    
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Add danger flash animation
const style = document.createElement('style');
style.textContent = `
@keyframes danger-flash {
    0%, 100% { background-color: transparent; }
    50% { background-color: rgba(255, 0, 64, 0.2); }
}
`;
document.head.appendChild(style);

// Matrix rain effect with toggle
let matrixRainAnimation;

function initMatrixRain() {
    const canvas = document.getElementById('matrix-rain');
    const ctx = canvas.getContext('2d');
    
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const matrix = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%+-/~{[|`]}";
    const matrixArray = matrix.split("");
    
    const fontSize = 10;
    const columns = canvas.width / fontSize;
    
    const drops = [];
    for(let x = 0; x < columns; x++) {
        drops[x] = 1;
    }
    
    function draw() {
        // Check if effect is enabled
        if (!settingsManager?.settings['effect-matrix-rain']) {
            return;
        }
        
        ctx.fillStyle = 'rgba(0, 0, 0, 0.04)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = '#0F0';
        ctx.font = fontSize + 'px monospace';
        
        for(let i = 0; i < drops.length; i++) {
            const text = matrixArray[Math.floor(Math.random() * matrixArray.length)];
            ctx.fillText(text, i * fontSize, drops[i] * fontSize);
            
            if(drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                drops[i] = 0;
            }
            drops[i]++;
        }
    }
    
    matrixRainAnimation = setInterval(draw, 35);
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', () => {
    // Initialize settings manager first
    settingsManager = new SettingsManager();
    
    // Then initialize other components
    initMatrixRain();
    window.vpnController = new VPNController();
    
    // Window resize handler
    window.addEventListener('resize', () => {
        const canvas = document.getElementById('matrix-rain');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
});

// Add keyboard shortcuts for quick settings
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + Shift + E to toggle effects
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'E') {
        e.preventDefault();
        const allEnabled = Object.keys(settingsManager.settings)
            .filter(k => k.startsWith('effect-'))
            .every(k => settingsManager.settings[k]);
        
        // Toggle all effects
        Object.keys(settingsManager.settings)
            .filter(k => k.startsWith('effect-'))
            .forEach(k => {
                settingsManager.settings[k] = !allEnabled;
                const checkbox = document.getElementById(k);
                if (checkbox) checkbox.checked = !allEnabled;
            });
        
        settingsManager.applySettings();
        
        const terminal = window.vpnController?.terminal;
        if (terminal) {
            terminal.writeLine(`ALL EFFECTS ${allEnabled ? 'DISABLED' : 'ENABLED'}`, '#ffff00');
        }
    }
    
    // Ctrl/Cmd + Shift + T to cycle themes
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'T') {
        e.preventDefault();
        const themes = ['cyberpunk', 'matrix', 'terminal', 'stealth'];
        const currentIndex = themes.indexOf(settingsManager.settings.theme || 'cyberpunk');
        const nextIndex = (currentIndex + 1) % themes.length;
        settingsManager.applyTheme(themes[nextIndex]);
    }
});
