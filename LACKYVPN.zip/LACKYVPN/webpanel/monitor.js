/**
 * L4CKYVPN N3TW0RK M0N1T0R
 * ========================
 * Advanced network monitoring and analysis
 */

const os = require('os');
const si = require('systeminformation');
const WebSocket = require('ws');

class SystemMonitor {
    constructor() {
        this.metrics = {
            cpu: [],
            memory: [],
            network: [],
            processes: []
        };
        this.maxDataPoints = 300; // 5 minutes at 1 sample/sec
    }

    async collectMetrics() {
        try {
            // CPU usage
            const cpu = await si.currentLoad();
            this.metrics.cpu.push({
                timestamp: Date.now(),
                usage: cpu.currentLoad,
                cores: cpu.cpus.map(c => c.load)
            });

            // Memory usage
            const mem = await si.mem();
            this.metrics.memory.push({
                timestamp: Date.now(),
                total: mem.total,
                used: mem.used,
                free: mem.free,
                percent: (mem.used / mem.total) * 100
            });

            // Network stats
            const net = await si.networkStats();
            const primaryInterface = net.find(n => n.iface === 'Ethernet' || n.iface === 'Wi-Fi') || net[0];
            
            if (primaryInterface) {
                this.metrics.network.push({
                    timestamp: Date.now(),
                    rx: primaryInterface.rx_bytes,
                    tx: primaryInterface.tx_bytes,
                    rx_sec: primaryInterface.rx_sec,
                    tx_sec: primaryInterface.tx_sec
                });
            }

            // Check for suspicious processes
            const processes = await si.processes();
            const suspiciousProcesses = processes.list.filter(p => {
                const suspicious = ['wireshark', 'tcpdump', 'nmap', 'netstat', 'traceroute'];
                return suspicious.some(s => p.name.toLowerCase().includes(s));
            });

            if (suspiciousProcesses.length > 0) {
                console.log('[!] SUSPICIOUS PROCESSES DETECTED:', suspiciousProcesses.map(p => p.name));
            }

            // Trim old data
            Object.keys(this.metrics).forEach(key => {
                if (this.metrics[key].length > this.maxDataPoints) {
                    this.metrics[key] = this.metrics[key].slice(-this.maxDataPoints);
                }
            });

        } catch (error) {
            console.error('Error collecting metrics:', error);
        }
    }

    async detectAnomalies() {
        // Simple anomaly detection
        if (this.metrics.network.length > 10) {
            const recent = this.metrics.network.slice(-10);
            const avgRxSec = recent.reduce((sum, m) => sum + m.rx_sec, 0) / recent.length;
            const avgTxSec = recent.reduce((sum, m) => sum + m.tx_sec, 0) / recent.length;
            
            const latest = this.metrics.network[this.metrics.network.length - 1];
            
            // Alert if traffic spike (3x average)
            if (latest.rx_sec > avgRxSec * 3 || latest.tx_sec > avgTxSec * 3) {
                console.log('[!] TRAFFIC SPIKE DETECTED!');
                return {
                    type: 'traffic_spike',
                    rx_spike: latest.rx_sec > avgRxSec * 3,
                    tx_spike: latest.tx_sec > avgTxSec * 3,
                    current_rx: latest.rx_sec,
                    current_tx: latest.tx_sec,
                    avg_rx: avgRxSec,
                    avg_tx: avgTxSec
                };
            }
        }
        
        return null;
    }

    getMetrics() {
        return this.metrics;
    }
}

// Start monitoring if run directly
if (require.main === module) {
    const monitor = new SystemMonitor();
    
    console.log('L4CKYVPN System Monitor Started');
    console.log('================================');
    
    // Connect to main server WebSocket
    const ws = new WebSocket('ws://localhost:1338');
    
    ws.on('open', () => {
        console.log('Connected to L4CKYVPN server');
    });
    
    // Collect metrics every second
    setInterval(async () => {
        await monitor.collectMetrics();
        
        const anomaly = await monitor.detectAnomalies();
        if (anomaly) {
            ws.send(JSON.stringify({
                type: 'anomaly',
                data: anomaly
            }));
        }
    }, 1000);
    
    // Report full metrics every 10 seconds
    setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
                type: 'system_metrics',
                data: monitor.getMetrics()
            }));
        }
    }, 10000);
}

module.exports = SystemMonitor;
