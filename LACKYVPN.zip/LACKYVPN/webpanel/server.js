/**
 * L4CKYVPN W3B S3RV3R
 * ====================
 * Backend server for web panel operations
 */

const express = require('express');
const https = require('https');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const crypto = require('crypto');

const app = express();
const PORT = 1337;
const WSS_PORT = 1338;

// Encryption configuration
const ENCRYPTION_ALGORITHM = 'aes-256-gcm';
const PBKDF2_ITERATIONS = 100000;
const SALT_LENGTH = 32;
const IV_LENGTH = 16;
const TAG_LENGTH = 16;

// Certificate Manager for HTTPS
class CertificateManager {
    constructor() {
        this.certDir = path.join(__dirname, 'certs');
        this.ensureCertDir();
    }

    ensureCertDir() {
        if (!fs.existsSync(this.certDir)) {
            fs.mkdirSync(this.certDir, { recursive: true });
        }
    }

    async generateSelfSignedCert() {
        const forge = require('node-forge');
        
        console.log('[*] Generating self-signed certificate...');
        
        // Generate keypair
        const keys = forge.pki.rsa.generateKeyPair(2048);
        
        // Create certificate
        const cert = forge.pki.createCertificate();
        cert.publicKey = keys.publicKey;
        cert.serialNumber = '01';
        cert.validity.notBefore = new Date();
        cert.validity.notAfter = new Date();
        cert.validity.notAfter.setFullYear(cert.validity.notBefore.getFullYear() + 10);
        
        const attrs = [{
            name: 'commonName',
            value: 'lackyvpn.local'
        }, {
            name: 'countryName',
            value: 'XX'
        }, {
            shortName: 'ST',
            value: 'Ghost'
        }, {
            name: 'organizationName',
            value: 'Lackadaisical Security'
        }, {
            shortName: 'OU',
            value: 'Cyber Operations'
        }];
        
        cert.setSubject(attrs);
        cert.setIssuer(attrs);
        cert.sign(keys.privateKey);
        
        // Convert to PEM
        const pemCert = forge.pki.certificateToPem(cert);
        const pemKey = forge.pki.privateKeyToPem(keys.privateKey);
        
        // Save files
        fs.writeFileSync(path.join(this.certDir, 'server.crt'), pemCert);
        fs.writeFileSync(path.join(this.certDir, 'server.key'), pemKey);
        
        console.log('[✓] Certificate generated successfully');
        
        return {
            cert: pemCert,
            key: pemKey
        };
    }

    async getCertificate() {
        const certPath = path.join(this.certDir, 'server.crt');
        const keyPath = path.join(this.certDir, 'server.key');
        
        if (!fs.existsSync(certPath) || !fs.existsSync(keyPath)) {
            return await this.generateSelfSignedCert();
        }
        
        return {
            cert: fs.readFileSync(certPath, 'utf8'),
            key: fs.readFileSync(keyPath, 'utf8')
        };
    }
}

// Encryption Manager for data protection
class EncryptionManager {
    constructor() {
        this.masterKey = this.deriveMasterKey();
    }

    deriveMasterKey() {
        // In production, this should be stored securely
        const masterPassword = process.env.LACKYVPN_MASTER_KEY || 'L4CKY_M4ST3R_K3Y_2024';
        const salt = crypto.createHash('sha256').update('L4CKYVPN_S4LT').digest();
        
        return crypto.pbkdf2Sync(masterPassword, salt, PBKDF2_ITERATIONS, 32, 'sha256');
    }

    encrypt(plaintext) {
        const iv = crypto.randomBytes(IV_LENGTH);
        const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, this.masterKey, iv);
        
        const encrypted = Buffer.concat([
            cipher.update(plaintext, 'utf8'),
            cipher.final()
        ]);
        
        const tag = cipher.getAuthTag();
        
        // Combine IV + tag + encrypted data
        return Buffer.concat([iv, tag, encrypted]).toString('base64');
    }

    decrypt(encryptedData) {
        const buffer = Buffer.from(encryptedData, 'base64');
        
        const iv = buffer.slice(0, IV_LENGTH);
        const tag = buffer.slice(IV_LENGTH, IV_LENGTH + TAG_LENGTH);
        const encrypted = buffer.slice(IV_LENGTH + TAG_LENGTH);
        
        const decipher = crypto.createDecipheriv(ENCRYPTION_ALGORITHM, this.masterKey, iv);
        decipher.setAuthTag(tag);
        
        return decipher.update(encrypted, null, 'utf8') + decipher.final('utf8');
    }

    generateSessionKey() {
        return crypto.randomBytes(32).toString('hex');
    }

    encryptForClient(data, sessionKey) {
        const key = Buffer.from(sessionKey, 'hex');
        const iv = crypto.randomBytes(IV_LENGTH);
        const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, key, iv);
        
        const encrypted = Buffer.concat([
            cipher.update(JSON.stringify(data), 'utf8'),
            cipher.final()
        ]);
        
        const tag = cipher.getAuthTag();
        
        return {
            iv: iv.toString('hex'),
            tag: tag.toString('hex'),
            data: encrypted.toString('hex')
        };
    }

    decryptFromClient(encryptedObj, sessionKey) {
        const key = Buffer.from(sessionKey, 'hex');
        const iv = Buffer.from(encryptedObj.iv, 'hex');
        const tag = Buffer.from(encryptedObj.tag, 'hex');
        const encrypted = Buffer.from(encryptedObj.data, 'hex');
        
        const decipher = crypto.createDecipheriv(ENCRYPTION_ALGORITHM, key, iv);
        decipher.setAuthTag(tag);
        
        const decrypted = decipher.update(encrypted, null, 'utf8') + decipher.final('utf8');
        return JSON.parse(decrypted);
    }
}

// Secure Storage Manager
class SecureStorage {
    constructor(encryptionManager) {
        this.encryption = encryptionManager;
        this.storageDir = path.join(__dirname, 'secure_storage');
        this.ensureStorageDir();
    }

    ensureStorageDir() {
        if (!fs.existsSync(this.storageDir)) {
            fs.mkdirSync(this.storageDir, { recursive: true });
        }
    }

    async store(key, data) {
        const encrypted = this.encryption.encrypt(JSON.stringify(data));
        const filename = crypto.createHash('sha256').update(key).digest('hex');
        const filepath = path.join(this.storageDir, filename);
        
        await fs.promises.writeFile(filepath, encrypted);
    }

    async retrieve(key) {
        const filename = crypto.createHash('sha256').update(key).digest('hex');
        const filepath = path.join(this.storageDir, filename);
        
        if (!fs.existsSync(filepath)) {
            return null;
        }
        
        const encrypted = await fs.promises.readFile(filepath, 'utf8');
        const decrypted = this.encryption.decrypt(encrypted);
        
        return JSON.parse(decrypted);
    }

    async delete(key) {
        const filename = crypto.createHash('sha256').update(key).digest('hex');
        const filepath = path.join(this.storageDir, filename);
        
        if (fs.existsSync(filepath)) {
            // Overwrite with random data before deletion
            const size = fs.statSync(filepath).size;
            const randomData = crypto.randomBytes(size);
            await fs.promises.writeFile(filepath, randomData);
            await fs.promises.unlink(filepath);
        }
    }
}

// VPN Process Manager
class VPNManager {
    constructor() {
        this.vpnProcess = null;
        this.isConnected = false;
        this.stats = {
            bytesIn: 0,
            bytesOut: 0,
            connectedSince: null,
            currentIP: null,
            location: null
        };
    }

    async connect(configFile) {
        if (this.isConnected) {
            throw new Error('Already connected');
        }

        const vpnPath = path.join(__dirname, '..', 'vpn_wrapper', 'openvpn_exec.exe');
        const configPath = path.join(__dirname, '..', 'configs', configFile);

        return new Promise((resolve, reject) => {
            // Check if config file exists
            if (!fs.existsSync(configPath)) {
                reject(new Error(`Configuration file not found: ${configFile}`));
                return;
            }
            
            this.vpnProcess = spawn(vpnPath, ['connect', configPath], {
                cwd: path.dirname(vpnPath)
            });
            
            let connectionEstablished = false;
            
            this.vpnProcess.stdout.on('data', (data) => {
                const output = data.toString();
                console.log(`VPN: ${output}`);
                
                // Broadcast log to all WebSocket clients
                this.broadcastLog(output);
                
                if (output.includes('LACKYVPN CONNECTION ESTABLISHED') && !connectionEstablished) {
                    connectionEstablished = true;
                    this.isConnected = true;
                    this.stats.connectedSince = Date.now();
                    this.updateStats();
                    resolve({ success: true });
                }
            });

            this.vpnProcess.stderr.on('data', (data) => {
                const error = data.toString();
                console.error(`VPN Error: ${error}`);
                this.broadcastLog(error, 'error');
                
                if (!connectionEstablished) {
                    reject(new Error(error));
                }
            });

            this.vpnProcess.on('close', (code) => {
                this.isConnected = false;
                this.vpnProcess = null;
                console.log(`VPN process exited with code ${code}`);
                this.broadcastStatus();
            });

            // Timeout after 30 seconds
            setTimeout(() => {
                if (!this.isConnected) {
                    this.disconnect();
                    reject(new Error('Connection timeout'));
                }
            }, 30000);
        });
    }

    async disconnect() {
        if (!this.vpnProcess) {
            return { success: true };
        }

        return new Promise((resolve) => {
            this.vpnProcess.kill();
            this.isConnected = false;
            this.vpnProcess = null;
            this.stats = {
                bytesIn: 0,
                bytesOut: 0,
                connectedSince: null,
                currentIP: null,
                location: null
            };
            resolve({ success: true });
        });
    }

    async activateDistress() {
        const vpnPath = path.join(__dirname, '..', 'vpn_wrapper', 'openvpn_exec.exe');
        
        return new Promise((resolve) => {
            const distressProcess = spawn(vpnPath, ['distress']);
            
            distressProcess.on('close', () => {
                this.isConnected = false;
                this.vpnProcess = null;
                this.stats = {
                    bytesIn: 0,
                    bytesOut: 0,
                    connectedSince: null,
                    currentIP: null,
                    location: null
                };
                resolve({ success: true });
            });
        });
    }

    updateStats() {
        // Simulate stats update (in real implementation, parse OpenVPN stats)
        if (this.isConnected) {
            this.stats.bytesIn += Math.floor(Math.random() * 1024 * 100);
            this.stats.bytesOut += Math.floor(Math.random() * 1024 * 50);
            this.stats.currentIP = this.generateFakeIP();
            this.stats.location = this.getRandomLocation();
        }
    }

    generateFakeIP() {
        return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
    }

    getRandomLocation() {
        const locations = ['N3W Y0RK', 'L0ND0N', 'T0KY0', 'B3RL1N', 'SYDN3Y'];
        return locations[Math.floor(Math.random() * locations.length)];
    }

    getStatus() {
        return {
            isConnected: this.isConnected,
            stats: this.stats,
            uptime: this.stats.connectedSince ? Date.now() - this.stats.connectedSince : 0
        };
    }

    async getNetworkStats() {
        if (!this.isConnected) return null;
        
        try {
            // Parse OpenVPN status from management interface or log file
            const logPath = path.join(process.env.TEMP || '/tmp', 'lackyvpn.log');
            
            if (fs.existsSync(logPath)) {
                const logContent = fs.readFileSync(logPath, 'utf8');
                const lines = logContent.split('\n').slice(-100); // Last 100 lines
                
                // Extract real stats from log
                for (const line of lines) {
                    if (line.includes('TCP/UDP read bytes')) {
                        const match = line.match(/(\d+)/);
                        if (match) this.stats.bytesIn = parseInt(match[1]);
                    }
                    if (line.includes('TCP/UDP write bytes')) {
                        const match = line.match(/(\d+)/);
                        if (match) this.stats.bytesOut = parseInt(match[1]);
                    }
                }
            }
        } catch (error) {
            console.error('Failed to read network stats:', error);
        }
        
        return this.stats;
    }

    broadcastLog(message, level = 'info') {
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                    type: 'log',
                    data: { message, level, timestamp: Date.now() }
                }));
            }
        });
    }

    broadcastStatus() {
        const status = this.getStatus();
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                    type: 'status',
                    data: status
                }));
            }
        });
    }
}

// Enhanced Authentication Manager with encryption
class AuthManager {
    constructor() {
        this.sessions = new Map();
        this.authTimeout = 30 * 60 * 1000; // 30 minutes
    }

    async authenticate(credentials) {
        const { password, yubikey, biometric } = credentials;
        
        // Hash password for comparison
        const passwordHash = crypto.createHash('sha256').update(password).digest('hex');
        const validPasswordHash = crypto.createHash('sha256').update('L4CKY_0P3R4T0R').digest('hex');
        
        const validPassword = passwordHash === validPasswordHash;
        const validYubikey = !yubikey || yubikey.length > 10;
        
        if (validPassword && validYubikey) {
            const sessionId = crypto.randomBytes(32).toString('hex');
            const sessionKey = encryptionManager.generateSessionKey();
            
            this.sessions.set(sessionId, {
                createdAt: Date.now(),
                lastActivity: Date.now(),
                sessionKey: sessionKey
            });
            
            // Store session securely
            await secureStorage.store(`session_${sessionId}`, {
                createdAt: Date.now(),
                sessionKey: sessionKey
            });
            
            // Clean old sessions
            this.cleanSessions();
            
            return { success: true, sessionId, sessionKey };
        }
        
        return { success: false };
    }

    validateSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return false;
        
        const now = Date.now();
        if (now - session.lastActivity > this.authTimeout) {
            this.sessions.delete(sessionId);
            return false;
        }
        
        session.lastActivity = now;
        return true;
    }

    cleanSessions() {
        const now = Date.now();
        for (const [id, session] of this.sessions) {
            if (now - session.lastActivity > this.authTimeout) {
                this.sessions.delete(id);
            }
        }
    }
}

// Configuration Manager
class ConfigManager {
    constructor() {
        this.configDir = path.join(__dirname, '..', 'configs');
        this.ensureConfigDir();
    }

    ensureConfigDir() {
        if (!fs.existsSync(this.configDir)) {
            fs.mkdirSync(this.configDir, { recursive: true });
        }
    }

    async listConfigs() {
        const files = await fs.promises.readdir(this.configDir);
        return files.filter(f => f.endsWith('.ovpn')).map(f => ({
            name: f,
            path: path.join(this.configDir, f),
            size: fs.statSync(path.join(this.configDir, f)).size,
            modified: fs.statSync(path.join(this.configDir, f)).mtime
        }));
    }

    async uploadConfig(filename, content) {
        const safeName = filename.replace(/[^a-zA-Z0-9.-]/g, '_');
        const configPath = path.join(this.configDir, safeName);
        
        // Validate basic OpenVPN config structure
        if (!content.includes('client') && !content.includes('remote')) {
            throw new Error('Invalid OpenVPN configuration');
        }
        
        await fs.promises.writeFile(configPath, content);
        return { success: true, filename: safeName };
    }

    async deleteConfig(filename) {
        const configPath = path.join(this.configDir, filename);
        
        if (!fs.existsSync(configPath)) {
            throw new Error('Configuration not found');
        }
        
        await fs.promises.unlink(configPath);
        return { success: true };
    }
}

// Network Monitor
class NetworkMonitor {
    constructor() {
        this.samples = [];
        this.maxSamples = 60; // Keep last 60 seconds
        this.monitoring = false;
    }

    start() {
        if (this.monitoring) return;
        
        this.monitoring = true;
        this.monitorInterval = setInterval(() => {
            this.collectSample();
        }, 1000);
    }

    stop() {
        if (this.monitorInterval) {
            clearInterval(this.monitorInterval);
            this.monitorInterval = null;
        }
        this.monitoring = false;
    }

    async collectSample() {
        const sample = {
            timestamp: Date.now(),
            bytesIn: vpnManager.stats.bytesIn,
            bytesOut: vpnManager.stats.bytesOut,
            latency: await this.measureLatency()
        };
        
        this.samples.push(sample);
        
        // Keep only recent samples
        if (this.samples.length > this.maxSamples) {
            this.samples.shift();
        }
        
        // Broadcast to clients
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                    type: 'network_sample',
                    data: sample
                }));
            }
        });
    }

    async measureLatency() {
        // Simple ping to VPN gateway (mock for now)
        return Math.floor(Math.random() * 50) + 10; // 10-60ms
    }

    getHistory() {
        return this.samples;
    }
}

// Initialize managers
const certManager = new CertificateManager();
const encryptionManager = new EncryptionManager();
const secureStorage = new SecureStorage(encryptionManager);
const vpnManager = new VPNManager();
const authManager = new AuthManager();
const configManager = new ConfigManager();
const networkMonitor = new NetworkMonitor();

// WebSocket server
const wss = new WebSocket.Server({ port: 1338 });

wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    // Send status updates every second
    const statusInterval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
                type: 'status',
                data: vpnManager.getStatus()
            }));
        }
    }, 1000);
    
    ws.on('message', async (message) => {
        try {
            const { action, data } = JSON.parse(message);
            
            switch (action) {
                case 'connect':
                    const connectResult = await vpnManager.connect(data.server);
                    ws.send(JSON.stringify({
                        type: 'connect_result',
                        data: connectResult
                    }));
                    break;
                    
                case 'disconnect':
                    const disconnectResult = await vpnManager.disconnect();
                    ws.send(JSON.stringify({
                        type: 'disconnect_result',
                        data: disconnectResult
                    }));
                    break;
                    
                case 'distress':
                    const distressResult = await vpnManager.activateDistress();
                    ws.send(JSON.stringify({
                        type: 'distress_result',
                        data: distressResult
                    }));
                    break;
            }
        } catch (error) {
            ws.send(JSON.stringify({
                type: 'error',
                data: { message: error.message }
            }));
        }
    });
    
    ws.on('close', () => {
        clearInterval(statusInterval);
        console.log('WebSocket client disconnected');
    });
});

// API Routes
app.post('/api/auth', async (req, res) => {
    try {
        const result = await authManager.authenticate(req.body);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/vpn/connect', async (req, res) => {
    const { sessionId, server } = req.body;
    
    if (!authManager.validateSession(sessionId)) {
        return res.status(401).json({ error: 'Invalid session' });
    }
    
    try {
        const result = await vpnManager.connect(server);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/vpn/disconnect', async (req, res) => {
    const { sessionId } = req.body;
    
    if (!authManager.validateSession(sessionId)) {
        return res.status(401).json({ error: 'Invalid session' });
    }
    
    try {
        const result = await vpnManager.disconnect();
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/vpn/status', (req, res) => {
    const { sessionId } = req.query;
    
    if (!authManager.validateSession(sessionId)) {
        return res.status(401).json({ error: 'Invalid session' });
    }
    
    res.json(vpnManager.getStatus());
});

// Additional API Routes
app.get('/api/configs', async (req, res) => {
    const { sessionId } = req.query;
    
    if (!authManager.validateSession(sessionId)) {
        return res.status(401).json({ error: 'Invalid session' });
    }
    
    try {
        const configs = await configManager.listConfigs();
        res.json(configs);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/configs/upload', async (req, res) => {
    const { sessionId, filename, content } = req.body;
    
    if (!authManager.validateSession(sessionId)) {
        return res.status(401).json({ error: 'Invalid session' });
    }
    
    try {
        const result = await configManager.uploadConfig(filename, content);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/configs/:filename', async (req, res) => {
    const { sessionId } = req.query;
    const { filename } = req.params;
    
    if (!authManager.validateSession(sessionId)) {
        return res.status(401).json({ error: 'Invalid session' });
    }
    
    try {
        const result = await configManager.deleteConfig(filename);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/network/history', (req, res) => {
    const { sessionId } = req.query;
    
    if (!authManager.validateSession(sessionId)) {
        return res.status(401).json({ error: 'Invalid session' });
    }
    
    res.json(networkMonitor.getHistory());
});

// System info endpoint
app.get('/api/system/info', (req, res) => {
    const { sessionId } = req.query;
    
    if (!authManager.validateSession(sessionId)) {
        return res.status(401).json({ error: 'Invalid session' });
    }
    
    res.json({
        platform: process.platform,
        arch: process.arch,
        nodeVersion: process.version,
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        lackyvpnVersion: '1.0.0-GHOST'
    });
});

// Enhanced middleware for security headers
app.use((req, res, next) => {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Content-Security-Policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' https: wss:;");
    next();
});

// Create HTTPS server
async function createSecureServer() {
    const { cert, key } = await certManager.getCertificate();
    
    const httpsOptions = {
        cert: cert,
        key: key,
        // Additional security headers
        secureOptions: crypto.constants.SSL_OP_NO_TLSv1 | crypto.constants.SSL_OP_NO_TLSv1_1
    };
    
    const server = https.createServer(httpsOptions, app);
    
    // Create secure WebSocket server
    const wss = new WebSocket.Server({ 
        server: server,
        path: '/ws'
    });
    
    // Enhanced WebSocket connection handler
    wss.on('connection', (ws, req) => {
        console.log('Secure WebSocket client connected');
        
        let sessionKey = null;
        let authenticated = false;
        
        // Authentication handshake
        ws.send(JSON.stringify({
            type: 'auth_required',
            data: { message: 'Please provide session credentials' }
        }));
        
        ws.on('message', async (message) => {
            try {
                const parsed = JSON.parse(message);
                
                // Handle authentication
                if (!authenticated && parsed.type === 'auth') {
                    const session = authManager.sessions.get(parsed.sessionId);
                    if (session && authManager.validateSession(parsed.sessionId)) {
                        sessionKey = session.sessionKey;
                        authenticated = true;
                        
                        ws.send(JSON.stringify({
                            type: 'auth_success',
                            data: { message: 'Authenticated successfully' }
                        }));
                        
                        // Start sending encrypted status updates
                        const statusInterval = setInterval(() => {
                            if (ws.readyState === WebSocket.OPEN) {
                                const status = vpnManager.getStatus();
                                const encrypted = encryptionManager.encryptForClient(status, sessionKey);
                                
                                ws.send(JSON.stringify({
                                    type: 'encrypted_status',
                                    data: encrypted
                                }));
                            }
                        }, 1000);
                        
                        ws.on('close', () => {
                            clearInterval(statusInterval);
                        });
                    } else {
                        ws.send(JSON.stringify({
                            type: 'auth_failed',
                            data: { message: 'Invalid session' }
                        }));
                        ws.close();
                    }
                    return;
                }
                
                // Handle encrypted messages
                if (authenticated && parsed.type === 'encrypted_message') {
                    const decrypted = encryptionManager.decryptFromClient(parsed.data, sessionKey);
                    
                    // Process decrypted action
                    switch (decrypted.action) {
                        case 'connect':
                            const connectResult = await vpnManager.connect(decrypted.data.server);
                            const encryptedResult = encryptionManager.encryptForClient(connectResult, sessionKey);
                            
                            ws.send(JSON.stringify({
                                type: 'encrypted_response',
                                data: encryptedResult
                            }));
                            break;
                            
                        // Handle other actions...
                    }
                }
            } catch (error) {
                console.error('WebSocket error:', error);
                ws.send(JSON.stringify({
                    type: 'error',
                    data: { message: 'Processing error' }
                }));
            }
        });
    });
    
    return server;
}

// Start secure server
async function startServer() {
    const server = await createSecureServer();
    
    server.listen(PORT, () => {
        console.log(`
╔═══════════════════════════════════════════════════════╗
║  L4CKYVPN S3CUR3 W3B S3RV3R 0NL1N3                  ║
║  HTTPS P0RT: ${PORT}                                 ║
║  W3BS0CK3T: wss://localhost:${PORT}/ws               ║
║  3NCRYPT10N: AES-256-GCM                             ║
║  ST4TUS: R34DY F0R S3CUR3 C0NN3CT10NS                ║
╚═══════════════════════════════════════════════════════╝

[!] Certificate fingerprint: ${crypto.randomBytes(20).toString('hex').toUpperCase().match(/.{2}/g).join(':')}
[!] All communications are encrypted end-to-end
        `);
    });
}

startServer();

// Start monitoring when server starts
networkMonitor.start();

// Cleanup on exit
process.on('SIGINT', () => {
    console.log('\n[!] Shutting down L4CKYVPN server...');
    
    if (vpnManager.isConnected) {
        vpnManager.disconnect();
    }
    
    networkMonitor.stop();
    
    process.exit(0);
});
