/*
 * LACKYVPN Electron Main Process - 80s Cyber Edition
 * ==================================================
 * 
 * Secure Electron application for LACKYVPN operator interface.
 * Implements security-hardened UI with anti-analysis features and 80s cyber aesthetic.
 * 
 * Security Level: CLASSIFIED
 * Theme: 80s Retro Cyber Tech
 * Built by: Lackadaisical Security
 */

const { app, BrowserWindow, ipcMain, dialog, Menu, shell, globalShortcut } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn } = require('child_process');

// Security configuration with cyber hardening
const SECURITY_CONFIG = {
    nodeIntegration: false,
    contextIsolation: true,
    enableRemoteModule: false,
    webSecurity: true,
    allowRunningInsecureContent: false,
    experimentalFeatures: false,
    sandbox: true
};

// Global variables for cyber interface
let mainWindow;
let vpnProcess;
let isDistressModeActive = false;
let authenticationRequired = true;
let cyberModeEnabled = true;
let soundEnabled = true;

// Application paths
const APP_DATA_PATH = path.join(require('os').homedir(), '.lackyvpn');
const LACKYVPN_BINARY = path.join(__dirname, '..', '..', 'bin', 'lackyvpn.exe');
const CYBER_ASSETS_PATH = path.join(__dirname, 'assets', 'cyber');

//=============================================================================
// APPLICATION INITIALIZATION
//=============================================================================

app.whenReady().then(() => {
    initializeSecurity();
    createMainWindow();
    setupApplicationMenu();
    setupIPCHandlers();
    
    // Check for distress mode on startup
    checkDistressMode();
});

app.on('window-all-closed', () => {
    // Secure shutdown
    if (vpnProcess) {
        vpnProcess.kill('SIGTERM');
    }
    
    // Clear sensitive data
    clearSensitiveMemory();
    
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createMainWindow();
    }
});

//=============================================================================
// SECURITY INITIALIZATION
//=============================================================================

function initializeSecurity() {
    // Disable node integration globally
    app.on('web-contents-created', (event, contents) => {
        contents.on('new-window', (event, navigationUrl) => {
            event.preventDefault();
            shell.openExternal(navigationUrl);
        });
        
        contents.on('will-navigate', (event, navigationUrl) => {
            const parsedUrl = new URL(navigationUrl);
            if (parsedUrl.origin !== 'file://') {
                event.preventDefault();
            }
        });
    });
    
    // Create secure app data directory
    if (!fs.existsSync(APP_DATA_PATH)) {
        fs.mkdirSync(APP_DATA_PATH, { mode: 0o700 });
    }
    
    console.log('LACKYVPN: Security initialization complete');
}

//=============================================================================
// MAIN WINDOW CREATION
//=============================================================================

function createMainWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        minWidth: 800,
        minHeight: 600,
        webPreferences: {
            ...SECURITY_CONFIG,
            preload: path.join(__dirname, 'preload.js')
        },
        icon: path.join(__dirname, 'assets', 'icon.png'),
        title: 'LACKYVPN - Operator Interface',
        show: false, // Don't show until ready
        frame: true,
        titleBarStyle: 'default'
    });
    
    // Load the main interface
    mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
    
    // Show window when ready
    mainWindow.once('ready-to-show', () => {
        if (authenticationRequired) {
            showAuthenticationDialog();
        } else {
            mainWindow.show();
        }
    });
    
    // Handle window closed
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
    
    // Development tools (disable in production)
    if (process.env.NODE_ENV === 'development') {
        mainWindow.webContents.openDevTools();
    }
}

//=============================================================================
// AUTHENTICATION SYSTEM
//=============================================================================

function showAuthenticationDialog() {
    const authWindow = new BrowserWindow({
        width: 400,
        height: 300,
        resizable: false,
        modal: true,
        parent: mainWindow,
        webPreferences: {
            ...SECURITY_CONFIG,
            preload: path.join(__dirname, 'preload.js')
        },
        title: 'LACKYVPN Authentication'
    });
    
    authWindow.loadFile(path.join(__dirname, 'renderer', 'auth.html'));
    
    authWindow.once('closed', () => {
        if (!authenticationRequired) {
            mainWindow.show();
        } else {
            app.quit();
        }
    });
}

//=============================================================================
// IPC HANDLERS
//=============================================================================

function setupIPCHandlers() {
    // Authentication
    ipcMain.handle('authenticate', async (event, credentials) => {
        return await authenticateUser(credentials);
    });
    
    // VPN Control
    ipcMain.handle('vpn-connect', async (event, config) => {
        return await connectVPN(config);
    });
    
    ipcMain.handle('vpn-disconnect', async () => {
        return await disconnectVPN();
    });
    
    ipcMain.handle('vpn-status', async () => {
        return await getVPNStatus();
    });
    
    // Security Features
    ipcMain.handle('enable-stealth-mode', async () => {
        return await enableStealthMode();
    });
    
    ipcMain.handle('activate-distress-mode', async () => {
        return await activateDistressMode();
    });
    
    ipcMain.handle('system-hardening', async (event, options) => {
        return await applySystemHardening(options);
    });
    
    // Encryption Management
    ipcMain.handle('rotate-keys', async () => {
        return await rotateEncryptionKeys();
    });
    
    ipcMain.handle('quantum-sync', async () => {
        return await performQuantumSync();
    });
    
    // File Operations
    ipcMain.handle('export-config', async () => {
        return await exportConfiguration();
    });
    
    ipcMain.handle('import-config', async (event, configPath) => {
        return await importConfiguration(configPath);
    });
}

//=============================================================================
// AUTHENTICATION IMPLEMENTATION
//=============================================================================

async function authenticateUser(credentials) {
    try {
        // Multi-factor authentication
        const { password, biometric, totp } = credentials;
        
        // Validate password (would integrate with operator_keychain.c)
        const passwordValid = await validatePassword(password);
        if (!passwordValid) {
            return { success: false, error: 'Invalid password' };
        }
        
        // Validate TOTP if provided
        if (totp) {
            const totpValid = await validateTOTP(totp);
            if (!totpValid) {
                return { success: false, error: 'Invalid TOTP code' };
            }
        }
        
        // Validate biometric if provided
        if (biometric) {
            const biometricValid = await validateBiometric(biometric);
            if (!biometricValid) {
                return { success: false, error: 'Biometric authentication failed' };
            }
        }
        
        authenticationRequired = false;
        return { success: true };
        
    } catch (error) {
        console.error('Authentication error:', error);
        return { success: false, error: 'Authentication system error' };
    }
}

async function validatePassword(password) {
    // This would call the C backend for password validation
    return new Promise((resolve) => {
        const hash = crypto.createHash('sha256').update(password).digest('hex');
        // Simulate validation (in real implementation, call operator_keychain.c)
        resolve(hash.length > 0);
    });
}

//=============================================================================
// VPN CONTROL IMPLEMENTATION
//=============================================================================

async function connectVPN(config) {
    try {
        if (vpnProcess) {
            throw new Error('VPN already running');
        }
        
        const args = [
            '--connect',
            '--config', config.configFile || 'default.ovpn',
            '--stealth-mode', config.stealthMode ? '1' : '0',
            '--encryption-layers', config.encryptionLayers || '10'
        ];
        
        vpnProcess = spawn(LACKYVPN_BINARY, args, {
            cwd: path.dirname(LACKYVPN_BINARY),
            stdio: ['pipe', 'pipe', 'pipe']
        });
        
        vpnProcess.stdout.on('data', (data) => {
            console.log('VPN Output:', data.toString());
            mainWindow?.webContents.send('vpn-log', data.toString());
        });
        
        vpnProcess.stderr.on('data', (data) => {
            console.error('VPN Error:', data.toString());
            mainWindow?.webContents.send('vpn-error', data.toString());
        });
        
        vpnProcess.on('close', (code) => {
            console.log('VPN process exited with code:', code);
            vpnProcess = null;
            mainWindow?.webContents.send('vpn-disconnected', code);
        });
        
        return { success: true, message: 'VPN connection initiated' };
        
    } catch (error) {
        console.error('VPN connection error:', error);
        return { success: false, error: error.message };
    }
}

async function disconnectVPN() {
    try {
        if (!vpnProcess) {
            return { success: false, error: 'No VPN process running' };
        }
        
        vpnProcess.kill('SIGTERM');
        
        // Wait for graceful shutdown
        setTimeout(() => {
            if (vpnProcess) {
                vpnProcess.kill('SIGKILL');
            }
        }, 5000);
        
        return { success: true, message: 'VPN disconnection initiated' };
        
    } catch (error) {
        console.error('VPN disconnection error:', error);
        return { success: false, error: error.message };
    }
}

async function getVPNStatus() {
    return {
        connected: vpnProcess !== null,
        pid: vpnProcess?.pid || null,
        uptime: vpnProcess ? Date.now() - vpnProcess.spawnTime : 0
    };
}

//=============================================================================
// SECURITY FEATURES
//=============================================================================

async function enableStealthMode() {
    try {
        // This would call the C backend to enable stealth mode
        const result = await executeSecurityCommand(['--enable-stealth']);
        return { success: true, message: 'Stealth mode activated' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function activateDistressMode() {
    try {
        isDistressModeActive = true;
        
        // Hide main window
        mainWindow?.hide();
        
        // Execute distress mode
        const result = await executeSecurityCommand(['--distress-mode']);
        
        // Create fake business interface
        createFakeBusinessInterface();
        
        return { success: true, message: 'Distress mode activated' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

function createFakeBusinessInterface() {
    const fakeWindow = new BrowserWindow({
        width: 1024,
        height: 768,
        webPreferences: SECURITY_CONFIG,
        title: 'Corporate Dashboard - Q2 2025 Financial Analysis'
    });
    
    fakeWindow.loadFile(path.join(__dirname, 'renderer', 'fake_business.html'));
}

async function applySystemHardening(options) {
    try {
        const args = ['--system-hardening'];
        
        if (options.firewall) args.push('--enable-firewall');
        if (options.dnsProtection) args.push('--dns-protection');
        if (options.macRandomization) args.push('--mac-randomization');
        
        const result = await executeSecurityCommand(args);
        return { success: true, message: 'System hardening applied' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

//=============================================================================
// UTILITY FUNCTIONS
//=============================================================================

async function executeSecurityCommand(args) {
    return new Promise((resolve, reject) => {
        const process = spawn(LACKYVPN_BINARY, args);
        
        let output = '';
        process.stdout.on('data', (data) => {
            output += data.toString();
        });
        
        process.on('close', (code) => {
            if (code === 0) {
                resolve(output);
            } else {
                reject(new Error(`Command failed with code ${code}`));
            }
        });
    });
}

function checkDistressMode() {
    // Check for distress mode indicators
    const distressFile = path.join(APP_DATA_PATH, '.distress');
    if (fs.existsSync(distressFile)) {
        activateDistressMode();
    }
}

function clearSensitiveMemory() {
    // Clear sensitive variables
    if (global.gc) {
        global.gc();
    }
    
    console.log('LACKYVPN: Sensitive memory cleared');
}

function setupApplicationMenu() {
    const template = [
        {
            label: 'File',
            submenu: [
                {
                    label: 'Import Configuration',
                    click: () => {
                        dialog.showOpenDialog(mainWindow, {
                            properties: ['openFile'],
                            filters: [{ name: 'VPN Config', extensions: ['ovpn', 'conf'] }]
                        }).then(result => {
                            if (!result.canceled) {
                                importConfiguration(result.filePaths[0]);
                            }
                        });
                    }
                },
                {
                    label: 'Export Configuration',
                    click: () => exportConfiguration()
                },
                { type: 'separator' },
                {
                    label: 'Exit',
                    accelerator: 'CmdOrCtrl+Q',
                    click: () => app.quit()
                }
            ]
        },
        {
            label: 'Security',
            submenu: [
                {
                    label: 'Enable Stealth Mode',
                    click: () => enableStealthMode()
                },
                {
                    label: 'Activate Distress Mode',
                    accelerator: 'CmdOrCtrl+Shift+D',
                    click: () => activateDistressMode()
                },
                {
                    label: 'Rotate Encryption Keys',
                    click: () => rotateEncryptionKeys()
                },
                {
                    label: 'System Hardening',
                    click: () => mainWindow?.webContents.send('show-hardening-dialog')
                }
            ]
        },
        {
            label: 'Help',
            submenu: [
                {
                    label: 'About LACKYVPN',
                    click: () => {
                        dialog.showMessageBox(mainWindow, {
                            type: 'info',
                            title: 'About LACKYVPN',
                            message: 'LACKYVPN v1.0\nOperator-Class Privacy Framework\nBuilt by Lackadaisical Security'
                        });
                    }
                }
            ]
        }
    ];
    
    const menu = Menu.buildFromTemplate(template);
    Menu.setApplicationMenu(menu);
}

async function rotateEncryptionKeys() {
    try {
        const result = await executeSecurityCommand(['--rotate-keys']);
        mainWindow?.webContents.send('keys-rotated');
        return { success: true, message: 'Encryption keys rotated' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function performQuantumSync() {
    try {
        const result = await executeSecurityCommand(['--quantum-sync']);
        return { success: true, message: 'Quantum synchronization complete' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function exportConfiguration() {
    try {
        const result = await dialog.showSaveDialog(mainWindow, {
            filters: [{ name: 'Configuration', extensions: ['json'] }],
            defaultPath: 'lackyvpn-config.json'
        });
        
        if (!result.canceled) {
            // Export configuration logic here
            return { success: true, path: result.filePath };
        }
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function importConfiguration(configPath) {
    try {
        // Import configuration logic here
        return { success: true, message: 'Configuration imported' };
    } catch (error) {
        return { success: false, error: error.message };
    }
}
