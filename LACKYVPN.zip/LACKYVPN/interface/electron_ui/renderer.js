// LACKYVPN 80s Retro Cyber Renderer
// filepath: c:\Users\lankyroo\Desktop\LACKYVPN\interface\electron_ui\renderer.js

class CyberInterface {
    constructor() {
        this.isConnected = false;
        this.encryptionLayers = 10;
        this.systemMetrics = {
            cpu: 0,
            memory: 0,
            network: 0,
            temperature: 45
        };
        this.quantumState = {
            entanglement: 97.3,
            coherence: 94.7,
            qubits: 2048
        };
        
        this.init();
        this.startAnimations();
        this.startMetricsUpdate();
    }

    init() {
        this.setupNavigation();
        this.setupButtons();
        this.setupMatrixRain();
        this.generateRandomMetrics();
        this.typewriterEffect();
    }

    setupNavigation() {
        const navItems = document.querySelectorAll('.nav-item');
        const sections = document.querySelectorAll('.section');

        navItems.forEach(item => {
            item.addEventListener('click', () => {
                const targetSection = item.dataset.section;
                
                // Remove active class from all nav items
                navItems.forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');

                // Hide all sections
                sections.forEach(section => section.classList.add('hidden'));
                
                // Show target section
                const target = document.getElementById(`${targetSection}-section`);
                if (target) {
                    target.classList.remove('hidden');
                }

                // Update section title
                const titles = {
                    dashboard: 'SYSTEM DASHBOARD',
                    connection: 'CONNECTION CONTROL',
                    encryption: 'ENCRYPTION MATRIX',
                    stealth: 'STEALTH OPERATIONS',
                    quantum: 'QUANTUM CONTROL',
                    emergency: 'EMERGENCY PROTOCOLS',
                    logs: 'SYSTEM LOGS'
                };
                
                document.getElementById('section-title').textContent = titles[targetSection] || 'UNKNOWN';
                this.addGlitchEffect(document.getElementById('section-title'));
            });
        });
    }

    setupButtons() {
        // Connection buttons
        document.getElementById('connect-btn')?.addEventListener('click', () => this.connect());
        document.getElementById('disconnect-btn')?.addEventListener('click', () => this.disconnect());
        document.getElementById('config-btn')?.addEventListener('click', () => this.showConfigModal());

        // Encryption buttons
        document.getElementById('rotate-keys-btn')?.addEventListener('click', () => this.rotateKeys());
        document.getElementById('quantum-sync-btn')?.addEventListener('click', () => this.quantumSync());
        document.getElementById('harden-crypto-btn')?.addEventListener('click', () => this.hardenCrypto());
        document.getElementById('mutate-cipher-btn')?.addEventListener('click', () => this.mutateCipher());

        // Stealth buttons
        document.getElementById('enable-stealth-btn')?.addEventListener('click', () => this.enableStealth());
        document.getElementById('disable-stealth-btn')?.addEventListener('click', () => this.disableStealth());
        document.getElementById('ghost-mode-btn')?.addEventListener('click', () => this.ghostMode());

        // Quantum buttons
        document.getElementById('quantum-key-btn')?.addEventListener('click', () => this.quantumKeyDistribution());
        document.getElementById('entangle-btn')?.addEventListener('click', () => this.entangleQubits());

        // Emergency buttons
        document.getElementById('distress-btn')?.addEventListener('click', () => this.distressMode());
        document.getElementById('wipe-secrets-btn')?.addEventListener('click', () => this.wipeSecrets());
        document.getElementById('fake-mode-btn')?.addEventListener('click', () => this.fakeBusinessMode());
        document.getElementById('shutdown-btn')?.addEventListener('click', () => this.emergencyShutdown());

        // Log buttons
        document.getElementById('clear-logs-btn')?.addEventListener('click', () => this.clearLogs());
        document.getElementById('export-logs-btn')?.addEventListener('click', () => this.exportLogs());

        // Modal buttons
        document.getElementById('save-config-btn')?.addEventListener('click', () => this.saveConfig());
        document.getElementById('cancel-config-btn')?.addEventListener('click', () => this.hideConfigModal());
    }

    setupMatrixRain() {
        const canvas = document.querySelector('.matrix-rain');
        const ctx = canvas.getContext('2d');
        
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const matrix = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%+-/~{[|`]}";
        const matrixArray = matrix.split("");

        const fontSize = 10;
        const columns = canvas.width / fontSize;

        const drops = [];
        for (let x = 0; x < columns; x++) {
            drops[x] = 1;
        }

        function draw() {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.04)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.fillStyle = '#00ff41';
            ctx.font = fontSize + 'px monospace';

            for (let i = 0; i < drops.length; i++) {
                const text = matrixArray[Math.floor(Math.random() * matrixArray.length)];
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);

                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }
                drops[i]++;
            }
        }

        setInterval(draw, 35);
    }

    startAnimations() {
        // Neon pulse animation for status indicators
        this.pulseInterval = setInterval(() => {
            const statusDot = document.getElementById('status-dot');
            if (statusDot) {
                statusDot.style.transform = `scale(${1 + Math.sin(Date.now() * 0.005) * 0.2})`;
            }
        }, 50);

        // Random glitch effects
        this.glitchInterval = setInterval(() => {
            const cards = document.querySelectorAll('.card');
            const randomCard = cards[Math.floor(Math.random() * cards.length)];
            if (randomCard && Math.random() > 0.8) {
                this.addGlitchEffect(randomCard);
            }
        }, 2000);
    }

    startMetricsUpdate() {
        this.metricsInterval = setInterval(() => {
            this.updateSystemMetrics();
            this.updateQuantumMetrics();
        }, 1000);
    }

    updateSystemMetrics() {
        // Simulate realistic system metrics
        this.systemMetrics.cpu = Math.max(5, Math.min(95, this.systemMetrics.cpu + (Math.random() - 0.5) * 10));
        this.systemMetrics.memory = Math.max(20, Math.min(90, this.systemMetrics.memory + (Math.random() - 0.5) * 5));
        this.systemMetrics.network = Math.random() * 1000;
        this.systemMetrics.temperature = Math.max(35, Math.min(80, this.systemMetrics.temperature + (Math.random() - 0.5) * 2));

        // Update UI
        document.getElementById('cpu-usage').textContent = `${this.systemMetrics.cpu.toFixed(1)}%`;
        document.getElementById('memory-usage').textContent = `${this.systemMetrics.memory.toFixed(1)}%`;
        document.getElementById('network-traffic').textContent = `${this.systemMetrics.network.toFixed(1)} MB/s`;
        document.getElementById('temperature').textContent = `${this.systemMetrics.temperature.toFixed(1)}°C`;
        
        // Update uptime
        const uptime = new Date(Date.now() - 1234567890).toISOString().substr(11, 8);
        document.getElementById('uptime').textContent = uptime;
    }

    updateQuantumMetrics() {
        // Simulate quantum state fluctuations
        this.quantumState.entanglement = Math.max(90, Math.min(99.9, this.quantumState.entanglement + (Math.random() - 0.5) * 0.5));
        this.quantumState.coherence = Math.max(85, Math.min(99, this.quantumState.coherence + (Math.random() - 0.5) * 1));
        
        // Update quantum displays
        const entanglementSpan = document.querySelector('#quantum-entanglement span');
        const coherenceSpan = document.querySelector('#quantum-coherence span');
        
        if (entanglementSpan) entanglementSpan.textContent = `${this.quantumState.entanglement.toFixed(1)}%`;
        if (coherenceSpan) coherenceSpan.textContent = `${this.quantumState.coherence.toFixed(1)}%`;
    }

    connect() {
        this.isConnected = true;
        this.updateConnectionStatus();
        this.addLogEntry('CONNECTION ESTABLISHED', 'success');
        this.addLogEntry('10-LAYER ENCRYPTION TUNNEL ACTIVE', 'info');
        this.addLogEntry('QUANTUM ENTANGLEMENT SYNCHRONIZED', 'success');
        
        // Simulate connection process
        setTimeout(() => {
            document.getElementById('server-location').textContent = 'DARKNET NODE 7';
            document.getElementById('public-ip').textContent = '192.168.1.XXX → MASKED';
            document.getElementById('connection-speed').textContent = '1.2 Gb/s';
        }, 1000);
    }

    disconnect() {
        this.isConnected = false;
        this.updateConnectionStatus();
        this.addLogEntry('CONNECTION TERMINATED', 'warning');
        this.addLogEntry('ENCRYPTION TUNNEL CLOSED', 'info');
        
        document.getElementById('server-location').textContent = '--';
        document.getElementById('public-ip').textContent = 'EXPOSED';
        document.getElementById('connection-speed').textContent = '--';
    }

    updateConnectionStatus() {
        const statusEl = document.getElementById('connection-status');
        const statusDot = document.getElementById('status-dot');
        const statusText = document.getElementById('status-text');

        if (this.isConnected) {
            statusEl.classList.add('connected');
            statusDot.classList.add('connected');
            statusText.textContent = 'CONNECTED';
        } else {
            statusEl.classList.remove('connected');
            statusDot.classList.remove('connected');
            statusText.textContent = 'DISCONNECTED';
        }
    }

    rotateKeys() {
        this.addLogEntry('ROTATING ENCRYPTION KEYS...', 'info');
        setTimeout(() => {
            this.addLogEntry('KEY ROTATION COMPLETE', 'success');
            this.addLogEntry('NEW QUANTUM KEYS GENERATED', 'success');
        }, 2000);
    }

    quantumSync() {
        this.addLogEntry('INITIATING QUANTUM SYNCHRONIZATION...', 'info');
        setTimeout(() => {
            this.addLogEntry('QUANTUM ENTANGLEMENT VERIFIED', 'success');
            this.addLogEntry('BB84 PROTOCOL ACTIVE', 'success');
        }, 3000);
    }

    hardenCrypto() {
        this.addLogEntry('HARDENING CRYPTOGRAPHIC SYSTEMS...', 'warning');
        setTimeout(() => {
            this.addLogEntry('CRYPTO HARDENING COMPLETE', 'success');
            this.addLogEntry('ANTI-QUANTUM DEFENSES ACTIVE', 'success');
        }, 2500);
    }

    mutateCipher() {
        this.addLogEntry('MUTATING CIPHER ALGORITHMS...', 'info');
        setTimeout(() => {
            const mutations = Math.floor(Math.random() * 500) + 1000;
            document.getElementById('code-mutations').textContent = mutations.toString();
            this.addLogEntry(`CIPHER MUTATION COMPLETE: ${mutations} VARIANTS`, 'success');
        }, 1500);
    }

    enableStealth() {
        this.addLogEntry('ENABLING STEALTH MODE...', 'warning');
        setTimeout(() => {
            this.addLogEntry('STEALTH MODE ACTIVE', 'success');
            this.addLogEntry('PROCESS HIDING ENABLED', 'info');
            this.addLogEntry('TRAFFIC OBFUSCATION ACTIVE', 'info');
        }, 2000);
    }

    disableStealth() {
        this.addLogEntry('DISABLING STEALTH MODE...', 'warning');
        setTimeout(() => {
            this.addLogEntry('STEALTH MODE DISABLED', 'info');
        }, 1000);
    }

    ghostMode() {
        this.addLogEntry('ACTIVATING GHOST PROTOCOL...', 'warning');
        setTimeout(() => {
            this.addLogEntry('GHOST MODE ENGAGED', 'success');
            this.addLogEntry('DIGITAL FINGERPRINT ERASED', 'success');
            this.addLogEntry('PHANTOM TRAFFIC GENERATION ACTIVE', 'info');
        }, 3000);
    }

    quantumKeyDistribution() {
        this.addLogEntry('INITIATING BB84 QUANTUM KEY DISTRIBUTION...', 'info');
        setTimeout(() => {
            this.addLogEntry('QUANTUM KEYS DISTRIBUTED', 'success');
            this.addLogEntry('EAVESDROPPING DETECTION: CLEAR', 'success');
        }, 2500);
    }

    entangleQubits() {
        this.addLogEntry('ENTANGLING QUANTUM BITS...', 'info');
        setTimeout(() => {
            const pairs = Math.floor(Math.random() * 500) + 1000;
            document.getElementById('entangled-pairs').innerHTML = `PAIRS: <span>${pairs}</span>`;
            this.addLogEntry(`${pairs} QUBIT PAIRS ENTANGLED`, 'success');
        }, 2000);
    }

    distressMode() {
        if (confirm('⚠️ ACTIVATE DISTRESS MODE? This will wipe sensitive data!')) {
            this.addLogEntry('🚨 DISTRESS MODE ACTIVATED 🚨', 'error');
            this.addLogEntry('WIPING SENSITIVE DATA...', 'error');
            this.addLogEntry('ACTIVATING DECOY SYSTEMS...', 'error');
            setTimeout(() => {
                this.addLogEntry('DISTRESS PROTOCOL COMPLETE', 'error');
            }, 3000);
        }
    }

    wipeSecrets() {
        if (confirm('⚠️ WIPE ALL SECRETS? This action cannot be undone!')) {
            this.addLogEntry('WIPING CRYPTOGRAPHIC SECRETS...', 'error');
            setTimeout(() => {
                this.addLogEntry('SECRET KEYS DESTROYED', 'error');
                this.addLogEntry('MEMORY SANITIZED', 'error');
            }, 2000);
        }
    }

    fakeBusinessMode() {
        this.addLogEntry('ACTIVATING FAKE BUSINESS MODE...', 'warning');
        setTimeout(() => {
            this.addLogEntry('DECOY INTERFACE LOADED', 'warning');
            this.addLogEntry('BUSINESS APPLICATION SIMULATION ACTIVE', 'warning');
        }, 1500);
    }

    emergencyShutdown() {
        if (confirm('⚠️ EMERGENCY SHUTDOWN? System will terminate immediately!')) {
            this.addLogEntry('🚨 EMERGENCY SHUTDOWN INITIATED 🚨', 'error');
            this.addLogEntry('TERMINATING ALL CONNECTIONS...', 'error');
            setTimeout(() => {
                document.body.style.animation = 'fadeOut 3s ease-out forwards';
            }, 1000);
        }
    }

    showConfigModal() {
        document.getElementById('config-modal').classList.remove('hidden');
    }

    hideConfigModal() {
        document.getElementById('config-modal').classList.add('hidden');
    }

    saveConfig() {
        const server = document.getElementById('server-select').value;
        const protocol = document.getElementById('protocol-select').value;
        const encryption = document.getElementById('encryption-level').value;
        
        this.addLogEntry(`CONFIG SAVED: ${server.toUpperCase()}`, 'success');
        this.addLogEntry(`PROTOCOL: ${protocol.toUpperCase()}`, 'info');
        this.addLogEntry(`ENCRYPTION: ${encryption.toUpperCase()}`, 'info');
        
        this.hideConfigModal();
    }

    addLogEntry(message, type = 'info') {
        const logsContainer = document.getElementById('logs-container');
        if (!logsContainer) return;

        const timestamp = new Date().toISOString().substr(11, 8);
        const logEntry = document.createElement('div');
        logEntry.className = `log-entry log-${type}`;
        logEntry.textContent = `[${timestamp}] ${message}`;
        
        logsContainer.appendChild(logEntry);
        logsContainer.scrollTop = logsContainer.scrollHeight;

        // Keep only last 100 entries
        const entries = logsContainer.querySelectorAll('.log-entry');
        if (entries.length > 100) {
            entries[0].remove();
        }
    }

    clearLogs() {
        const logsContainer = document.getElementById('logs-container');
        if (logsContainer) {
            logsContainer.innerHTML = '';
            this.addLogEntry('LOGS CLEARED', 'info');
        }
    }

    exportLogs() {
        const logs = document.querySelectorAll('.log-entry');
        const logText = Array.from(logs).map(log => log.textContent).join('\n');
        
        const blob = new Blob([logText], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `lackyvpn_logs_${Date.now()}.txt`;
        a.click();
        URL.revokeObjectURL(url);
        
        this.addLogEntry('LOGS EXPORTED', 'success');
    }

    addGlitchEffect(element) {
        element.classList.add('glitch');
        setTimeout(() => {
            element.classList.remove('glitch');
        }, 300);
    }

    typewriterEffect() {
        const title = document.querySelector('.logo h1');
        if (!title) return;

        const text = title.textContent;
        title.textContent = '';
        
        let i = 0;
        const typeWriter = () => {
            if (i < text.length) {
                title.textContent += text.charAt(i);
                i++;
                setTimeout(typeWriter, 100);
            }
        };
        
        setTimeout(typeWriter, 500);
    }

    generateRandomMetrics() {
        // Initialize with random but realistic values
        this.systemMetrics.cpu = Math.random() * 40 + 20;
        this.systemMetrics.memory = Math.random() * 50 + 30;
        this.systemMetrics.network = Math.random() * 100;
        this.systemMetrics.temperature = Math.random() * 20 + 40;
    }
}

// Audio Context for cyber sounds
class CyberSounds {
    constructor() {
        this.audioContext = null;
        this.init();
    }

    init() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        } catch (e) {
            console.log('Audio context not supported');
        }
    }

    playBeep(frequency = 440, duration = 200) {
        if (!this.audioContext) return;

        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);

        oscillator.frequency.value = frequency;
        oscillator.type = 'square';

        gainNode.gain.setValueAtTime(0.1, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration / 1000);

        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + duration / 1000);
    }

    playClickSound() {
        this.playBeep(800, 100);
    }

    playErrorSound() {
        this.playBeep(200, 500);
    }

    playSuccessSound() {
        this.playBeep(600, 200);
        setTimeout(() => this.playBeep(800, 200), 100);
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    const cyberInterface = new CyberInterface();
    const cyberSounds = new CyberSounds();

    // Add sound effects to buttons
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', () => cyberSounds.playClickSound());
    });

    // Add sound effects for different log types
    const originalAddLogEntry = cyberInterface.addLogEntry.bind(cyberInterface);
    cyberInterface.addLogEntry = function(message, type = 'info') {
        originalAddLogEntry(message, type);
        
        switch (type) {
            case 'success':
                cyberSounds.playSuccessSound();
                break;
            case 'error':
                cyberSounds.playErrorSound();
                break;
            case 'warning':
                cyberSounds.playBeep(400, 300);
                break;
            default:
                cyberSounds.playBeep(600, 150);
        }
    };

    // Easter egg: Konami Code
    let konamiCode = [];
    const konamiSequence = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'KeyB', 'KeyA'];
    
    document.addEventListener('keydown', (e) => {
        konamiCode.push(e.code);
        if (konamiCode.length > konamiSequence.length) {
            konamiCode.shift();
        }
        
        if (JSON.stringify(konamiCode) === JSON.stringify(konamiSequence)) {
            cyberInterface.addLogEntry('🎮 KONAMI CODE ACTIVATED! 🎮', 'success');
            cyberInterface.addLogEntry('ULTRA SECRET MODE UNLOCKED', 'success');
            document.body.style.filter = 'hue-rotate(180deg) saturate(2)';
            setTimeout(() => {
                document.body.style.filter = '';
            }, 5000);
        }
    });

    // Add keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey || e.metaKey) {
            switch (e.key) {
                case '1':
                    e.preventDefault();
                    document.querySelector('[data-section="dashboard"]').click();
                    break;
                case '2':
                    e.preventDefault();
                    document.querySelector('[data-section="connection"]').click();
                    break;
                case '3':
                    e.preventDefault();
                    document.querySelector('[data-section="encryption"]').click();
                    break;
                case '4':
                    e.preventDefault();
                    document.querySelector('[data-section="stealth"]').click();
                    break;
                case '5':
                    e.preventDefault();
                    document.querySelector('[data-section="quantum"]').click();
                    break;
            }
        }
    });

    console.log(`
    ██╗      █████╗  ██████╗██╗  ██╗██╗   ██╗██╗   ██╗██████╗ ███╗   ██╗
    ██║     ██╔══██╗██╔════╝██║ ██╔╝╚██╗ ██╔╝██║   ██║██╔══██╗████╗  ██║
    ██║     ███████║██║     █████╔╝  ╚████╔╝ ██║   ██║██████╔╝██╔██╗ ██║
    ██║     ██╔══██║██║     ██╔═██╗   ╚██╔╝  ╚██╗ ██╔╝██╔═══╝ ██║╚██╗██║
    ███████╗██║  ██║╚██████╗██║  ██╗   ██║    ╚████╔╝ ██║     ██║ ╚████║
    ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝   ╚═╝     ╚═══╝  ╚═╝     ╚═╝  ╚═══╝
    
    CYBER OPERATOR TERMINAL INITIALIZED
    Version 2.0 - 80s Retro Edition
    `);
});
