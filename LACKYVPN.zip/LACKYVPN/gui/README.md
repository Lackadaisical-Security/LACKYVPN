# LackyVPN Windows GUI Application
## Professional Grade VPN Client with 80s Cyber-Retro Theme

[![Build Status](https://img.shields.io/badge/build-passing-brightgreen)]()
[![Version](https://img.shields.io/badge/version-1.0.0-blue)]()
[![Platform](https://img.shields.io/badge/platform-Windows-lightgrey)]()
[![License](https://img.shields.io/badge/license-MIT-green)]()

### 🎯 Overview

The LackyVPN Windows GUI application is a native Windows client that provides a comprehensive interface for the LackyVPN professional security framework. Featuring an authentic 80s cyber-retro theme with neon colors, animated backgrounds, and tactical-style displays, this application delivers both style and functionality for security-conscious users.

### ✨ Key Features

#### 🎨 **80s Cyber-Retro Interface**
- **Neon Color Scheme**: Vibrant green, blue, pink, and orange neon colors
- **Animated Backgrounds**: Moving cyber grid patterns and matrix rain effects
- **Scan Line Effects**: Authentic CRT monitor simulation with animated scan lines
- **Terminal Aesthetics**: Monospace fonts and command-line inspired layout

#### 🛡️ **Professional Security Controls**
- **VPN Connection Management**: One-click connect/disconnect with visual status indicators
- **Real-time Monitoring**: Live system metrics and network statistics
- **Distress Mode Activation**: Emergency protocols with panic button functionality  
- **Security Dashboard**: Comprehensive threat monitoring and protection status

#### ⚙️ **Advanced Configuration**
- **Tabbed Settings Panel**: Organized configuration across 5 categories
- **Registry Integration**: Persistent settings storage in Windows registry
- **Hardware Integration**: TPM support and biometric authentication options
- **Performance Tuning**: CPU affinity, thread management, and buffer optimization

#### 📊 **Tactical Monitoring Dashboard**
- **System Performance**: Real-time CPU, memory, and disk usage
- **Network Intelligence**: Bandwidth monitoring and connection statistics  
- **Security Metrics**: Encryption status, firewall state, and threat detection
- **System Diagnostics**: Temperature monitoring and power status

### 🏗️ Architecture

#### **Core Components**

```
gui/
├── main.cpp              # Main application window and core logic
├── settings.cpp          # Configuration panel implementation  
├── settings.h            # Settings manager and dialog definitions
├── monitoring.cpp        # Real-time monitoring dashboard
├── monitoring.h          # Monitoring dashboard interface
├── resource.h            # Windows resource definitions
├── lackyvpn.rc          # Windows resource script
└── lackyvpn.manifest    # Application manifest for Windows compatibility
```

#### **Integration Points**

- **Core Framework**: Direct integration with `../core/` modules
- **System Integration**: Interface with `system_integration.h`
- **Monitoring**: Real-time data from `system_monitoring.h`
- **Security**: Distress mode control via `distress_mode.h`
- **Encryption**: Status reporting from encryption engines

### 🚀 Building the Application

#### **Prerequisites**
- Visual Studio 2019 or later with C++ build tools
- Windows SDK 10.0.19041.0 or later
- WiX Toolset v3.11+ (for MSI installer)

#### **Build Commands**

```bash
# Build GUI application only
make gui

# Build GUI with debug symbols
make gui_debug  

# Build complete MSI installer package
make installer

# Build everything (core + GUI + installer)
make all
```

#### **Manual Compilation**
```cmd
cd gui
rc.exe /fo lackyvpn.res lackyvpn.rc
cl.exe /EHsc /D_UNICODE /DUNICODE /I"../core" ^
       main.cpp settings.cpp monitoring.cpp lackyvpn.res ^
       /link user32.lib gdi32.lib shell32.lib advapi32.lib ^
              comctl32.lib d2d1.lib dwrite.lib ^
       /SUBSYSTEM:WINDOWS /OUT:lackyvpn.exe
```

### 📦 Installation

#### **MSI Installer Package**
The automated installer provides:
- **Native Windows Service**: Background VPN service installation
- **TAP Network Driver**: Virtual network adapter for VPN tunneling
- **Desktop Integration**: Start menu shortcuts and desktop icons
- **Documentation Suite**: Complete operator manuals and guides
- **Uninstall Support**: Clean removal with registry cleanup

#### **Installation Features**
- ✅ Administrator privilege elevation
- ✅ Windows compatibility checks (Windows 7+)
- ✅ Service registration and auto-start configuration
- ✅ Firewall exception creation
- ✅ Registry settings initialization
- ✅ Documentation installation

### 🎮 User Interface Guide

#### **Main Window Layout**

```
╔══════════════════════════════════════════════════════════════╗
║  🎯 LackyVPN - Professional Grade VPN Client                 ║
╠══════════════════════════════════════════════════════════════╣
║  [CONNECT] [DISCONNECT] [SETTINGS] [MONITORING] [DISTRESS]   ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║    🟢 CONNECTION STATUS: SECURE TUNNEL ESTABLISHED          ║
║    📍 Server: Cyber-Secure Node Alpha                       ║
║    🌐 Public IP: 203.0.113.45                              ║
║    ⏱️ Uptime: 02:34:17                                       ║
║                                                              ║
║    📊 REAL-TIME METRICS                                      ║
║    ↓ Download: 1.25 MB/s  ↑ Upload: 0.43 MB/s              ║
║    🔒 Encryption: AES-256  🛡️ Security: MAXIMUM             ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
```

#### **Settings Panel Categories**

1. **🏠 General**: Application preferences, theme selection, operator settings
2. **🔒 Security**: Encryption methods, hardware security, authentication
3. **🌐 Network**: Protocol configuration, DNS settings, performance tuning
4. **⚙️ Advanced**: Debug options, memory protection, system integration
5. **🚨 Distress**: Emergency protocols, panic modes, self-destruct sequences

#### **Monitoring Dashboard**

The tactical monitoring dashboard provides comprehensive system intelligence:

- **📊 Performance Panel**: CPU/Memory/Disk usage with animated progress bars
- **🌐 Network Panel**: Real-time bandwidth and connection statistics
- **🛡️ Security Panel**: Threat detection and protection status
- **⚙️ System Panel**: Hardware monitoring and diagnostics
- **🎯 Status Panel**: VPN connection details and uptime tracking

### 🔧 Configuration Options

#### **Security Settings**
- **Encryption Algorithms**: AES-256, ChaCha20-Poly1305, Quantum-resistant options
- **Hash Functions**: SHA-256, SHA-3, BLAKE2b
- **Key Exchange**: ECDH, Kyber (post-quantum)
- **Hardware Security**: TPM integration, biometric authentication

#### **Network Configuration**
- **Protocols**: OpenVPN, WireGuard, IPSec
- **DNS Options**: Custom DNS servers, DNS-over-HTTPS, DNS leak protection
- **Advanced Features**: Kill switch, IPv6 support, traffic compression

#### **Performance Tuning**
- **CPU Affinity**: Multi-core optimization
- **Buffer Sizes**: Memory allocation tuning
- **Thread Management**: Concurrent processing configuration
- **Priority Settings**: Process and thread priority control

### 🚨 Distress Mode Features

Advanced emergency protocols for high-threat environments:

#### **Panic Activation**
- **Hotkey Combinations**: Ctrl+Shift+F12 (configurable)
- **Immediate Actions**: Emergency disconnect, traffic blocking
- **Data Protection**: Secure wipe of sensitive information

#### **Emergency Protocols**
- **🔥 Fake Shutdown**: Simulate system shutdown while maintaining covert operation
- **🌐 Decoy Traffic**: Generate false network activity for obfuscation
- **💣 Self-Destruct**: Complete application and data elimination
- **📞 Emergency Contacts**: Automated notification system

#### **Anti-Forensics**
- **Memory Protection**: Secure memory allocation and clearing
- **Registry Cleanup**: Automatic removal of traces
- **Log Sanitization**: Secure deletion of activity logs

### 🔍 Monitoring & Diagnostics

#### **Real-Time Metrics**
- **System Performance**: CPU usage, memory consumption, disk I/O
- **Network Activity**: Bandwidth utilization, packet statistics, latency
- **Security Status**: Encryption state, firewall status, threat detection

#### **Logging System**
- **Debug Logging**: Detailed technical information for troubleshooting
- **Security Events**: Authentication attempts, connection changes
- **Performance Logs**: System resource usage and optimization data

### 🛠️ Development & Customization

#### **Extending the Interface**
```cpp
// Adding new monitoring panels
void DrawCustomPanel(D2D1_RECT_F rect) {
    // Panel rendering code
    m_pRenderTarget->DrawRectangle(rect, m_pBrushGreen, 2.0f);
    DrawText(L"Custom Panel", rect.left + 10, rect.top + 10, m_pBrushWhite);
}
```

#### **Custom Settings Integration**
```cpp
// Adding new configuration options
class CustomSettings : public SettingsManager {
    void SetCustomOption(const std::string& value) {
        WriteRegistryString("CustomOption", value);
        currentSettings.customOption = value;
    }
};
```

### 📚 Documentation References

- **[Operator Manual](../docs/OPERATOR_MANUAL.md)**: Complete usage guide
- **[Security Architecture](../docs/SECURITY_ARCH.md)**: Technical security details
- **[Build Guide](../docs/BUILD_GUIDE.md)**: Compilation and deployment
- **[Emergency Procedures](../docs/EMERGENCY_PROCEDURES.md)**: Crisis management protocols

### 🔧 Troubleshooting

#### **Common Issues**

**Application Won't Start**
- Verify administrator privileges
- Check Windows version compatibility (Windows 7+)
- Ensure Visual C++ Redistributable is installed

**Connection Problems**
- Verify TAP driver installation  
- Check Windows firewall settings
- Confirm administrator privileges for VPN service

**Performance Issues**
- Adjust CPU affinity settings
- Modify buffer sizes in Advanced settings
- Enable hardware acceleration where available

#### **Debug Mode**
Enable debug mode through Settings → Advanced → Debug Mode for detailed logging and diagnostic information.

### 🎯 Future Enhancements

#### **Planned Features**
- **Multi-Language Support**: Internationalization with additional language packs
- **Plugin Architecture**: Third-party extension support
- **Advanced Visualizations**: 3D network topology displays
- **Machine Learning**: Intelligent threat detection and response

#### **UI Improvements**
- **Custom Themes**: User-defined color schemes and animations
- **Widget System**: Customizable monitoring widgets
- **Touch Support**: Tablet and touch screen optimization

### 📄 License & Legal

This software is part of the LackyVPN security framework and is provided under the MIT License. See the main project LICENSE file for complete terms and conditions.

**Security Notice**: This application includes advanced security features designed for professional use. Users are responsible for compliance with local laws and regulations regarding VPN usage and encryption technologies.

---

**Built with ❤️ and 80s nostalgia by the LackyVPN Security Team**  
*"Keeping your data secure with style since 2024"*
