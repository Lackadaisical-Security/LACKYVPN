#include "monitoring.h"
#include "resource.h"
#include <d2d1.h>
#include <dwrite.h>
#include <wincodec.h>
#include <cmath>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

// Global monitoring instance
MonitoringDashboard* g_MonitoringDashboard = nullptr;

// Constructor
MonitoringDashboard::MonitoringDashboard(HWND parent) 
    : m_hParent(parent), m_hWnd(nullptr), m_pD2DFactory(nullptr),
      m_pRenderTarget(nullptr), m_pWriteFactory(nullptr), m_pTextFormat(nullptr),
      m_pBrushGreen(nullptr), m_pBrushRed(nullptr), m_pBrushBlue(nullptr),
      m_pBrushWhite(nullptr), m_pBrushOrange(nullptr), m_animationTime(0.0f),
      m_isVisible(false), m_updateTimer(0) {
    
    // Initialize metrics
    ZeroMemory(&m_metrics, sizeof(m_metrics));
    m_metrics.uptime = GetTickCount64() / 1000; // seconds
    
    // Initialize performance counters
    InitializePerformanceCounters();
}

// Destructor
MonitoringDashboard::~MonitoringDashboard() {
    Cleanup();
}

// Create the monitoring dashboard window
bool MonitoringDashboard::Create() {
    // Register window class
    WNDCLASSEX wcex = {};
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = MonitoringDashboard::WindowProc;
    wcex.hInstance = GetModuleHandle(nullptr);
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszClassName = L"LackyVPNMonitoringDashboard";
    wcex.hIcon = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_LACKYVPN));
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    if (!RegisterClassEx(&wcex)) {
        return false;
    }

    // Create window
    m_hWnd = CreateWindowEx(
        WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
        L"LackyVPNMonitoringDashboard",
        L"LackyVPN - Tactical Monitoring Dashboard",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        800, 600,
        m_hParent,
        nullptr,
        GetModuleHandle(nullptr),
        this
    );

    if (!m_hWnd) {
        return false;
    }

    // Initialize Direct2D
    if (!InitializeDirect2D()) {
        return false;
    }

    // Start update timer
    m_updateTimer = SetTimer(m_hWnd, 1, 1000, nullptr); // Update every second

    return true;
}

// Show/hide dashboard
void MonitoringDashboard::Show(bool show) {
    if (m_hWnd) {
        ShowWindow(m_hWnd, show ? SW_SHOW : SW_HIDE);
        m_isVisible = show;
        if (show) {
            SetForegroundWindow(m_hWnd);
        }
    }
}

// Toggle dashboard visibility
void MonitoringDashboard::Toggle() {
    Show(!m_isVisible);
}

// Update metrics
void MonitoringDashboard::UpdateMetrics() {
    // Update uptime
    m_metrics.uptime = GetTickCount64() / 1000;

    // CPU usage
    UpdateCPUUsage();

    // Memory usage
    UpdateMemoryUsage();

    // Network statistics
    UpdateNetworkStats();

    // Security metrics
    UpdateSecurityMetrics();

    // VPN status
    UpdateVPNStatus();

    // Force redraw
    if (m_hWnd && m_isVisible) {
        InvalidateRect(m_hWnd, nullptr, FALSE);
    }
}

// Initialize Direct2D
bool MonitoringDashboard::InitializeDirect2D() {
    HRESULT hr = S_OK;

    // Create D2D factory
    hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &m_pD2DFactory);
    if (FAILED(hr)) return false;

    // Create DWrite factory
    hr = DWriteCreateFactory(
        DWRITE_FACTORY_TYPE_SHARED,
        __uuidof(IDWriteFactory),
        reinterpret_cast<IUnknown**>(&m_pWriteFactory)
    );
    if (FAILED(hr)) return false;

    // Create text format
    hr = m_pWriteFactory->CreateTextFormat(
        L"Consolas",
        nullptr,
        DWRITE_FONT_WEIGHT_NORMAL,
        DWRITE_FONT_STYLE_NORMAL,
        DWRITE_FONT_STRETCH_NORMAL,
        12.0f,
        L"en-us",
        &m_pTextFormat
    );
    if (FAILED(hr)) return false;

    // Get client rect
    RECT rc;
    GetClientRect(m_hWnd, &rc);

    // Create render target
    D2D1_SIZE_U size = D2D1::SizeU(rc.right - rc.left, rc.bottom - rc.top);
    
    hr = m_pD2DFactory->CreateHwndRenderTarget(
        D2D1::RenderTargetProperties(),
        D2D1::HwndRenderTargetProperties(m_hWnd, size),
        &m_pRenderTarget
    );
    if (FAILED(hr)) return false;

    // Create brushes
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 1.0f, 0.5f, 1.0f), &m_pBrushGreen);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.0f, 0.5f, 1.0f), &m_pBrushRed);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.5f, 1.0f, 1.0f), &m_pBrushBlue);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f), &m_pBrushWhite);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.5f, 0.0f, 1.0f), &m_pBrushOrange);

    return true;
}

// Render the dashboard
void MonitoringDashboard::Render() {
    if (!m_pRenderTarget) return;

    m_pRenderTarget->BeginDraw();

    // Clear background
    m_pRenderTarget->Clear(D2D1::ColorF(0.0f, 0.0f, 0.1f, 1.0f)); // Dark blue

    // Get render target size
    D2D1_SIZE_F size = m_pRenderTarget->GetSize();

    // Draw cyber grid background
    DrawCyberGrid(size);

    // Draw main dashboard panels
    DrawStatusPanel(D2D1::RectF(10, 10, size.width/2 - 5, 200));
    DrawPerformancePanel(D2D1::RectF(size.width/2 + 5, 10, size.width - 10, 200));
    DrawNetworkPanel(D2D1::RectF(10, 210, size.width/2 - 5, 400));
    DrawSecurityPanel(D2D1::RectF(size.width/2 + 5, 210, size.width - 10, 400));
    DrawSystemPanel(D2D1::RectF(10, 410, size.width - 10, size.height - 10));

    // Draw animated scan lines
    DrawScanLines(size);

    // Update animation
    m_animationTime += 0.1f;
    if (m_animationTime > 360.0f) {
        m_animationTime = 0.0f;
    }

    HRESULT hr = m_pRenderTarget->EndDraw();
    if (hr == D2DERR_RECREATE_TARGET) {
        // Recreate render target if needed
        m_pRenderTarget->Release();
        m_pRenderTarget = nullptr;
        InitializeDirect2D();
    }
}

// Draw cyber grid background
void MonitoringDashboard::DrawCyberGrid(D2D1_SIZE_F size) {
    // Create grid brush with low opacity
    ID2D1SolidColorBrush* pGridBrush = nullptr;
    m_pRenderTarget->CreateSolidColorBrush(
        D2D1::ColorF(0.0f, 1.0f, 0.5f, 0.1f), &pGridBrush);

    if (pGridBrush) {
        // Draw vertical lines
        for (float x = 0; x < size.width; x += 50) {
            m_pRenderTarget->DrawLine(
                D2D1::Point2F(x, 0),
                D2D1::Point2F(x, size.height),
                pGridBrush,
                1.0f
            );
        }

        // Draw horizontal lines
        for (float y = 0; y < size.height; y += 50) {
            m_pRenderTarget->DrawLine(
                D2D1::Point2F(0, y),
                D2D1::Point2F(size.width, y),
                pGridBrush,
                1.0f
            );
        }

        pGridBrush->Release();
    }
}

// Draw status panel
void MonitoringDashboard::DrawStatusPanel(D2D1_RECT_F rect) {
    // Panel border
    m_pRenderTarget->DrawRectangle(rect, m_pBrushGreen, 2.0f);

    // Title
    DrawText(L"🎯 TACTICAL STATUS", rect.left + 10, rect.top + 10, m_pBrushGreen);

    // VPN Status
    float y = rect.top + 40;
    std::wstring vpnStatus = m_metrics.vpnConnected ? L"🟢 VPN: CONNECTED" : L"🔴 VPN: DISCONNECTED";
    ID2D1SolidColorBrush* vpnBrush = m_metrics.vpnConnected ? m_pBrushGreen : m_pBrushRed;
    DrawText(vpnStatus.c_str(), rect.left + 10, y, vpnBrush);

    // Connection details
    y += 25;
    if (m_metrics.vpnConnected) {
        std::wstringstream ss;
        ss << L"Server: " << m_metrics.serverLocation;
        DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);
        
        y += 20;
        ss.str(L"");
        ss << L"IP: " << m_metrics.publicIP;
        DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);
    }

    // Uptime
    y += 25;
    std::wstringstream uptimeStr;
    int hours = m_metrics.uptime / 3600;
    int minutes = (m_metrics.uptime % 3600) / 60;
    int seconds = m_metrics.uptime % 60;
    uptimeStr << L"Uptime: " << std::setfill(L'0') << std::setw(2) << hours 
              << L":" << std::setw(2) << minutes << L":" << std::setw(2) << seconds;
    DrawText(uptimeStr.str().c_str(), rect.left + 10, y, m_pBrushBlue);

    // Distress mode indicator
    if (m_metrics.distressModeActive) {
        y += 25;
        DrawText(L"⚠️ DISTRESS MODE ACTIVE", rect.left + 10, y, m_pBrushRed);
    }
}

// Draw performance panel
void MonitoringDashboard::DrawPerformancePanel(D2D1_RECT_F rect) {
    // Panel border
    m_pRenderTarget->DrawRectangle(rect, m_pBrushBlue, 2.0f);

    // Title
    DrawText(L"📊 PERFORMANCE METRICS", rect.left + 10, rect.top + 10, m_pBrushBlue);

    float y = rect.top + 40;

    // CPU Usage
    std::wstringstream ss;
    ss << L"CPU: " << std::fixed << std::setprecision(1) << m_metrics.cpuUsage << L"%";
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);
    
    // CPU usage bar
    DrawProgressBar(D2D1::RectF(rect.left + 100, y, rect.right - 10, y + 15), 
                   m_metrics.cpuUsage / 100.0f, m_pBrushGreen);

    // Memory Usage
    y += 30;
    ss.str(L"");
    ss << L"Memory: " << (m_metrics.memoryUsed / 1024 / 1024) << L" MB";
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);

    float memoryPercent = (float)m_metrics.memoryUsed / (float)m_metrics.memoryTotal;
    DrawProgressBar(D2D1::RectF(rect.left + 100, y, rect.right - 10, y + 15), 
                   memoryPercent, m_pBrushOrange);

    // Disk Usage
    y += 30;
    ss.str(L"");
    ss << L"Disk: " << std::fixed << std::setprecision(1) << m_metrics.diskUsage << L"%";
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);

    DrawProgressBar(D2D1::RectF(rect.left + 100, y, rect.right - 10, y + 15), 
                   m_metrics.diskUsage / 100.0f, m_pBrushBlue);

    // Thread count
    y += 30;
    ss.str(L"");
    ss << L"Threads: " << m_metrics.threadCount;
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);
}

// Draw network panel
void MonitoringDashboard::DrawNetworkPanel(D2D1_RECT_F rect) {
    // Panel border
    m_pRenderTarget->DrawRectangle(rect, m_pBrushOrange, 2.0f);

    // Title
    DrawText(L"🌐 NETWORK INTELLIGENCE", rect.left + 10, rect.top + 10, m_pBrushOrange);

    float y = rect.top + 40;

    // Bandwidth usage
    std::wstringstream ss;
    ss << L"↓ Download: " << std::fixed << std::setprecision(2) 
       << (m_metrics.bytesReceived / 1024.0 / 1024.0) << L" MB/s";
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushGreen);

    y += 20;
    ss.str(L"");
    ss << L"↑ Upload: " << std::fixed << std::setprecision(2) 
       << (m_metrics.bytesSent / 1024.0 / 1024.0) << L" MB/s";
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushBlue);

    // Connection statistics
    y += 30;
    ss.str(L"");
    ss << L"Active Connections: " << m_metrics.activeConnections;
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);

    y += 20;
    ss.str(L"");
    ss << L"Packets Sent: " << m_metrics.packetsSent;
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);

    y += 20;
    ss.str(L"");
    ss << L"Packets Received: " << m_metrics.packetsReceived;
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);

    // Latency
    y += 30;
    ss.str(L"");
    ss << L"Latency: " << m_metrics.latency << L" ms";
    ID2D1SolidColorBrush* latencyBrush = (m_metrics.latency < 50) ? m_pBrushGreen : 
                                        (m_metrics.latency < 100) ? m_pBrushOrange : m_pBrushRed;
    DrawText(ss.str().c_str(), rect.left + 10, y, latencyBrush);
}

// Draw security panel
void MonitoringDashboard::DrawSecurityPanel(D2D1_RECT_F rect) {
    // Panel border
    m_pRenderTarget->DrawRectangle(rect, m_pBrushRed, 2.0f);

    // Title
    DrawText(L"🛡️ SECURITY STATUS", rect.left + 10, rect.top + 10, m_pBrushRed);

    float y = rect.top + 40;

    // Encryption status
    std::wstring encStatus = m_metrics.encryptionActive ? L"🔒 Encryption: ACTIVE" : L"🔓 Encryption: INACTIVE";
    ID2D1SolidColorBrush* encBrush = m_metrics.encryptionActive ? m_pBrushGreen : m_pBrushRed;
    DrawText(encStatus.c_str(), rect.left + 10, y, encBrush);

    // Firewall status
    y += 25;
    std::wstring fwStatus = m_metrics.firewallActive ? L"🔥 Firewall: ENABLED" : L"❌ Firewall: DISABLED";
    ID2D1SolidColorBrush* fwBrush = m_metrics.firewallActive ? m_pBrushGreen : m_pBrushRed;
    DrawText(fwStatus.c_str(), rect.left + 10, y, fwBrush);

    // Kill switch
    y += 25;
    std::wstring ksStatus = m_metrics.killSwitchActive ? L"🚫 Kill Switch: ARMED" : L"⚪ Kill Switch: DISARMED";
    ID2D1SolidColorBrush* ksBrush = m_metrics.killSwitchActive ? m_pBrushGreen : m_pBrushOrange;
    DrawText(ksStatus.c_str(), rect.left + 10, y, ksBrush);

    // Threat detection
    y += 30;
    std::wstringstream ss;
    ss << L"Threats Blocked: " << m_metrics.threatsBlocked;
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushWhite);

    // Security level
    y += 25;
    ss.str(L"");
    ss << L"Security Level: " << m_metrics.securityLevel;
    ID2D1SolidColorBrush* secBrush = 
        (m_metrics.securityLevel == L"MAXIMUM") ? m_pBrushGreen :
        (m_metrics.securityLevel == L"HIGH") ? m_pBrushBlue :
        (m_metrics.securityLevel == L"MEDIUM") ? m_pBrushOrange : m_pBrushRed;
    DrawText(ss.str().c_str(), rect.left + 10, y, secBrush);
}

// Draw system panel
void MonitoringDashboard::DrawSystemPanel(D2D1_RECT_F rect) {
    // Panel border
    m_pRenderTarget->DrawRectangle(rect, m_pBrushWhite, 2.0f);

    // Title
    DrawText(L"⚙️ SYSTEM DIAGNOSTICS", rect.left + 10, rect.top + 10, m_pBrushWhite);

    float y = rect.top + 40;

    // System temperature
    std::wstringstream ss;
    ss << L"CPU Temperature: " << m_metrics.cpuTemperature << L"°C";
    ID2D1SolidColorBrush* tempBrush = (m_metrics.cpuTemperature < 70) ? m_pBrushGreen :
                                     (m_metrics.cpuTemperature < 85) ? m_pBrushOrange : m_pBrushRed;
    DrawText(ss.str().c_str(), rect.left + 10, y, tempBrush);

    // Power status
    y += 25;
    std::wstring powerStatus = m_metrics.onBattery ? L"🔋 Battery Power" : L"🔌 AC Power";
    DrawText(powerStatus.c_str(), rect.left + 10, y, m_pBrushWhite);

    // Last update time
    y += 30;
    SYSTEMTIME st;
    GetLocalTime(&st);
    ss.str(L"");
    ss << L"Last Update: " << std::setfill(L'0') << std::setw(2) << st.wHour 
       << L":" << std::setw(2) << st.wMinute << L":" << std::setw(2) << st.wSecond;
    DrawText(ss.str().c_str(), rect.left + 10, y, m_pBrushBlue);
}

// Draw animated scan lines
void MonitoringDashboard::DrawScanLines(D2D1_SIZE_F size) {
    ID2D1SolidColorBrush* pScanBrush = nullptr;
    m_pRenderTarget->CreateSolidColorBrush(
        D2D1::ColorF(0.0f, 1.0f, 0.5f, 0.3f), &pScanBrush);

    if (pScanBrush) {
        float scanY = sin(m_animationTime * 0.05f) * (size.height / 4) + (size.height / 2);
        
        m_pRenderTarget->DrawLine(
            D2D1::Point2F(0, scanY),
            D2D1::Point2F(size.width, scanY),
            pScanBrush,
            2.0f
        );

        pScanBrush->Release();
    }
}

// Draw progress bar
void MonitoringDashboard::DrawProgressBar(D2D1_RECT_F rect, float progress, ID2D1SolidColorBrush* brush) {
    // Background
    ID2D1SolidColorBrush* pBgBrush = nullptr;
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.2f, 0.2f, 0.2f, 1.0f), &pBgBrush);
    if (pBgBrush) {
        m_pRenderTarget->FillRectangle(rect, pBgBrush);
        pBgBrush->Release();
    }

    // Progress fill
    D2D1_RECT_F progressRect = rect;
    progressRect.right = rect.left + (rect.right - rect.left) * progress;
    m_pRenderTarget->FillRectangle(progressRect, brush);

    // Border
    m_pRenderTarget->DrawRectangle(rect, m_pBrushWhite, 1.0f);
}

// Draw text helper
void MonitoringDashboard::DrawText(const wchar_t* text, float x, float y, ID2D1SolidColorBrush* brush) {
    if (!m_pTextFormat || !brush) return;

    D2D1_RECT_F textRect = D2D1::RectF(x, y, x + 400, y + 30);
    m_pRenderTarget->DrawText(
        text,
        wcslen(text),
        m_pTextFormat,
        textRect,
        brush
    );
}

// Performance counter updates
void MonitoringDashboard::UpdateCPUUsage() {
    // Simplified CPU usage calculation
    static ULONGLONG lastIdleTime = 0, lastKernelTime = 0, lastUserTime = 0;
    FILETIME idleTime, kernelTime, userTime;
    
    if (GetSystemTimes(&idleTime, &kernelTime, &userTime)) {
        ULONGLONG idle = ((ULONGLONG)idleTime.dwHighDateTime << 32) | idleTime.dwLowDateTime;
        ULONGLONG kernel = ((ULONGLONG)kernelTime.dwHighDateTime << 32) | kernelTime.dwLowDateTime;
        ULONGLONG user = ((ULONGLONG)userTime.dwHighDateTime << 32) | userTime.dwLowDateTime;
        
        if (lastIdleTime != 0) {
            ULONGLONG idleDiff = idle - lastIdleTime;
            ULONGLONG kernelDiff = kernel - lastKernelTime;
            ULONGLONG userDiff = user - lastUserTime;
            ULONGLONG totalDiff = kernelDiff + userDiff;
            
            if (totalDiff > 0) {
                m_metrics.cpuUsage = (float)((totalDiff - idleDiff) * 100.0 / totalDiff);
            }
        }
        
        lastIdleTime = idle;
        lastKernelTime = kernel;
        lastUserTime = user;
    }
}

void MonitoringDashboard::UpdateMemoryUsage() {
    MEMORYSTATUSEX memInfo = {};
    memInfo.dwLength = sizeof(memInfo);
    if (GlobalMemoryStatusEx(&memInfo)) {
        m_metrics.memoryTotal = memInfo.ullTotalPhys;
        m_metrics.memoryUsed = memInfo.ullTotalPhys - memInfo.ullAvailPhys;
    }
}

void MonitoringDashboard::UpdateNetworkStats() {
    // Placeholder for network statistics
    // In a real implementation, this would query WMI or use IP Helper APIs
    m_metrics.bytesReceived = rand() % 1000000;
    m_metrics.bytesSent = rand() % 1000000;
    m_metrics.activeConnections = rand() % 50 + 10;
    m_metrics.latency = rand() % 100 + 20;
}

void MonitoringDashboard::UpdateSecurityMetrics() {
    // Placeholder security metrics
    m_metrics.encryptionActive = true;
    m_metrics.firewallActive = true;
    m_metrics.killSwitchActive = true;
    m_metrics.threatsBlocked = rand() % 10;
    m_metrics.securityLevel = L"MAXIMUM";
}

void MonitoringDashboard::UpdateVPNStatus() {
    // This would interface with the actual VPN core
    // For now, simulate connection status
    m_metrics.vpnConnected = true; // Placeholder
    m_metrics.serverLocation = L"Cyber-Secure Node Alpha";
    m_metrics.publicIP = L"192.168.1.100";
}

void MonitoringDashboard::InitializePerformanceCounters() {
    // Initialize performance monitoring
    m_metrics.cpuUsage = 0.0f;
    m_metrics.diskUsage = 0.0f;
    m_metrics.threadCount = 0;
    m_metrics.cpuTemperature = 45;
    m_metrics.onBattery = false;
    m_metrics.distressModeActive = false;
}

// Cleanup resources
void MonitoringDashboard::Cleanup() {
    if (m_updateTimer) {
        KillTimer(m_hWnd, 1);
        m_updateTimer = 0;
    }

    SafeRelease(m_pBrushGreen);
    SafeRelease(m_pBrushRed);
    SafeRelease(m_pBrushBlue);
    SafeRelease(m_pBrushWhite);
    SafeRelease(m_pBrushOrange);
    SafeRelease(m_pTextFormat);
    SafeRelease(m_pWriteFactory);
    SafeRelease(m_pRenderTarget);
    SafeRelease(m_pD2DFactory);
}

// Window procedure
LRESULT CALLBACK MonitoringDashboard::WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    MonitoringDashboard* pThis = nullptr;

    if (message == WM_NCCREATE) {
        CREATESTRUCT* pcs = (CREATESTRUCT*)lParam;
        pThis = (MonitoringDashboard*)pcs->lpCreateParams;
        SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)pThis);
        pThis->m_hWnd = hWnd;
    } else {
        pThis = (MonitoringDashboard*)GetWindowLongPtr(hWnd, GWLP_USERDATA);
    }

    if (pThis) {
        return pThis->HandleMessage(message, wParam, lParam);
    }

    return DefWindowProc(hWnd, message, wParam, lParam);
}

// Handle window messages
LRESULT MonitoringDashboard::HandleMessage(UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_PAINT:
            {
                PAINTSTRUCT ps;
                BeginPaint(m_hWnd, &ps);
                Render();
                EndPaint(m_hWnd, &ps);
            }
            return 0;

        case WM_SIZE:
            if (m_pRenderTarget) {
                RECT rc;
                GetClientRect(m_hWnd, &rc);
                D2D1_SIZE_U size = D2D1::SizeU(rc.right - rc.left, rc.bottom - rc.top);
                m_pRenderTarget->Resize(size);
            }
            return 0;

        case WM_TIMER:
            if (wParam == 1) {
                UpdateMetrics();
            }
            return 0;

        case WM_KEYDOWN:
            if (wParam == VK_ESCAPE) {
                Show(false);
            }
            return 0;

        case WM_CLOSE:
            Show(false);
            return 0;

        case WM_DESTROY:
            Cleanup();
            return 0;
    }

    return DefWindowProc(m_hWnd, message, wParam, lParam);
}

// Template function for safe release
template<class Interface>
void MonitoringDashboard::SafeRelease(Interface** ppInterfaceToRelease) {
    if (*ppInterfaceToRelease != nullptr) {
        (*ppInterfaceToRelease)->Release();
        (*ppInterfaceToRelease) = nullptr;
    }
}
