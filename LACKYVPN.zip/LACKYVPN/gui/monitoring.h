#ifndef MONITORING_H
#define MONITORING_H

#include <windows.h>
#include <d2d1.h>
#include <dwrite.h>
#include <string>

// Forward declarations
interface ID2D1Factory;
interface ID2D1HwndRenderTarget;
interface IDWriteFactory;
interface IDWriteTextFormat;
interface ID2D1SolidColorBrush;

// System metrics structure
struct SystemMetrics {
    // Performance metrics
    float cpuUsage;
    float diskUsage;
    ULONGLONG memoryTotal;
    ULONGLONG memoryUsed;
    int threadCount;
    int cpuTemperature;
    bool onBattery;
    
    // Network metrics
    ULONGLONG bytesReceived;
    ULONGLONG bytesSent;
    int activeConnections;
    int packetsSent;
    int packetsReceived;
    int latency;
    
    // Security metrics
    bool encryptionActive;
    bool firewallActive;
    bool killSwitchActive;
    int threatsBlocked;
    std::wstring securityLevel;
    
    // VPN metrics
    bool vpnConnected;
    std::wstring serverLocation;
    std::wstring publicIP;
    
    // System status
    ULONGLONG uptime;
    bool distressModeActive;
};

// Monitoring Dashboard Class
class MonitoringDashboard {
public:
    MonitoringDashboard(HWND parent);
    ~MonitoringDashboard();

    // Main interface
    bool Create();
    void Show(bool show = true);
    void Toggle();
    void UpdateMetrics();
    
    // Getters
    bool IsVisible() const { return m_isVisible; }
    HWND GetHandle() const { return m_hWnd; }

private:
    // Window management
    HWND m_hParent;
    HWND m_hWnd;
    bool m_isVisible;
    UINT_PTR m_updateTimer;

    // Direct2D resources
    ID2D1Factory* m_pD2DFactory;
    ID2D1HwndRenderTarget* m_pRenderTarget;
    IDWriteFactory* m_pWriteFactory;
    IDWriteTextFormat* m_pTextFormat;
    
    // Brushes for different colors
    ID2D1SolidColorBrush* m_pBrushGreen;    // Success/Normal
    ID2D1SolidColorBrush* m_pBrushRed;      // Error/Danger
    ID2D1SolidColorBrush* m_pBrushBlue;     // Info/Primary
    ID2D1SolidColorBrush* m_pBrushWhite;    // Text/Background
    ID2D1SolidColorBrush* m_pBrushOrange;   // Warning
    
    // Animation
    float m_animationTime;
    
    // System metrics
    SystemMetrics m_metrics;
    
    // Internal methods
    bool InitializeDirect2D();
    void Render();
    void Cleanup();
    
    // Rendering methods
    void DrawCyberGrid(D2D1_SIZE_F size);
    void DrawStatusPanel(D2D1_RECT_F rect);
    void DrawPerformancePanel(D2D1_RECT_F rect);
    void DrawNetworkPanel(D2D1_RECT_F rect);
    void DrawSecurityPanel(D2D1_RECT_F rect);
    void DrawSystemPanel(D2D1_RECT_F rect);
    void DrawScanLines(D2D1_SIZE_F size);
    void DrawProgressBar(D2D1_RECT_F rect, float progress, ID2D1SolidColorBrush* brush);
    void DrawText(const wchar_t* text, float x, float y, ID2D1SolidColorBrush* brush);
    
    // Metrics update methods
    void UpdateCPUUsage();
    void UpdateMemoryUsage();
    void UpdateNetworkStats();
    void UpdateSecurityMetrics();
    void UpdateVPNStatus();
    void InitializePerformanceCounters();
    
    // Window procedure
    static LRESULT CALLBACK WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
    LRESULT HandleMessage(UINT message, WPARAM wParam, LPARAM lParam);
    
    // Utility template
    template<class Interface>
    void SafeRelease(Interface** ppInterfaceToRelease);
};

// Global monitoring dashboard instance
extern MonitoringDashboard* g_MonitoringDashboard;

// Resource IDs for monitoring
#define IDM_MONITORING_SHOW        3000
#define IDM_MONITORING_HIDE        3001
#define IDM_MONITORING_TOGGLE      3002
#define IDM_MONITORING_REFRESH     3003

#endif // MONITORING_H
