#ifndef SETTINGS_H
#define SETTINGS_H

#include <windows.h>
#include <commctrl.h>
#include <string>
#include <map>

// Resource IDs for settings dialog
#define IDD_SETTINGS              2000
#define IDC_SETTINGS_TAB          2001

// General Tab Controls
#define IDC_GENERAL_TAB           2100
#define IDC_AUTOSTART_CHECK       2101
#define IDC_MINIMIZE_TO_TRAY      2102
#define IDC_SHOW_NOTIFICATIONS    2103
#define IDC_THEME_COMBO          2104
#define IDC_LANGUAGE_COMBO       2105
#define IDC_OPERATOR_NAME_EDIT   2106
#define IDC_LOG_LEVEL_COMBO      2107

// Security Tab Controls
#define IDC_SECURITY_TAB         2200
#define IDC_ENCRYPTION_COMBO     2201
#define IDC_HASH_COMBO          2202
#define IDC_KEY_SIZE_COMBO      2203
#define IDC_PERFECT_FORWARD     2204
#define IDC_QUANTUM_RESISTANT   2205
#define IDC_TPM_ENABLED         2206
#define IDC_BIOMETRIC_AUTH      2207
#define IDC_AUTO_LOCK_CHECK     2208
#define IDC_LOCK_TIMEOUT_EDIT   2209

// Network Tab Controls
#define IDC_NETWORK_TAB         2300
#define IDC_PROTOCOL_COMBO      2301
#define IDC_PORT_EDIT           2302
#define IDC_DNS_SERVER_EDIT     2303
#define IDC_MTU_EDIT            2304
#define IDC_COMPRESSION_CHECK   2305
#define IDC_IPV6_SUPPORT        2306
#define IDC_KILL_SWITCH         2307
#define IDC_LEAK_PROTECTION     2308
#define IDC_BANDWIDTH_LIMIT     2309

// Advanced Tab Controls
#define IDC_ADVANCED_TAB        2400
#define IDC_DEBUG_MODE          2401
#define IDC_VERBOSE_LOGGING     2402
#define IDC_MEMORY_PROTECTION   2403

// Forward declaration
class SettingsPanel;

// ========== SETTINGS PANEL CLASS ==========
class SettingsPanel {
private:
    HWND m_hDialog;
    HWND m_hTabControl;
    HWND m_hCurrentTab;
    SettingsManager* m_pSettingsManager;
    
    // Tab window handles
    HWND m_hGeneralTab;
    HWND m_hSecurityTab;
    HWND m_hNetworkTab;
    HWND m_hAdvancedTab;
    HWND m_hDistressTab;
    
public:
    SettingsPanel();
    ~SettingsPanel();
    
    // Main interface
    void ShowSettings(HWND hParent);
    
    // Dialog initialization
    void InitializeDialog(HWND hDlg);
    void CreateTabControl();
    
    // Tab creation
    void CreateGeneralTab();
    void CreateSecurityTab();
    void CreateNetworkTab();
    void CreateAdvancedTab();
    void CreateDistressTab();
    
    // Theme and UI
    void ApplyCyberTheme();
    static BOOL CALLBACK SetCyberThemeProc(HWND hwnd, LPARAM lParam);
    
    // Event handlers
    BOOL OnCommand(WORD id, WORD notifyCode);
    BOOL OnNotify(LPNMHDR pnmh);
    void ShowTabContent(int tabIndex);
    
    // Settings management
    void LoadSettings();
    void SaveSettings();
    void ApplySettings();
    void ResetToDefaults();
    
    // Accessors
    HWND GetDialog() const { return m_hDialog; }
    SettingsManager* GetSettingsManager() const { return m_pSettingsManager; }
};

// ========== SETTINGS MANAGER CLASS =========
class SettingsManager {
private:
    static SettingsManager* instance;
    LackyVPNSettings currentSettings;
    std::map<std::string, std::string> registry;
    
    // Registry helper functions
    bool ReadRegistryString(const std::string& key, std::string& value);
    bool WriteRegistryString(const std::string& key, const std::string& value);
    bool ReadRegistryInt(const std::string& key, int& value);
    bool WriteRegistryInt(const std::string& key, int value);
    bool ReadRegistryBool(const std::string& key, bool& value);
    bool WriteRegistryBool(const std::string& key, bool value);
    
    // Default settings
    void LoadDefaults();
    
public:
    static SettingsManager* GetInstance();
    
    // Settings management
    bool LoadSettings();
    bool SaveSettings();
    void ResetToDefaults();
    
    // Getters
    const LackyVPNSettings& GetSettings() const { return currentSettings; }
    
    // Individual setting getters
    bool GetAutoStart() const { return currentSettings.autoStart; }
    bool GetMinimizeToTray() const { return currentSettings.minimizeToTray; }
    bool GetShowNotifications() const { return currentSettings.showNotifications; }
    std::string GetTheme() const { return currentSettings.theme; }
    std::string GetLanguage() const { return currentSettings.language; }
    std::string GetOperatorName() const { return currentSettings.operatorName; }
    int GetLogLevel() const { return currentSettings.logLevel; }
    
    std::string GetEncryptionMethod() const { return currentSettings.encryptionMethod; }
    std::string GetHashAlgorithm() const { return currentSettings.hashAlgorithm; }
    int GetKeySize() const { return currentSettings.keySize; }
    bool GetPerfectForwardSecrecy() const { return currentSettings.perfectForwardSecrecy; }
    bool GetQuantumResistant() const { return currentSettings.quantumResistant; }
    bool GetTpmEnabled() const { return currentSettings.tpmEnabled; }
    bool GetBiometricAuth() const { return currentSettings.biometricAuth; }
    bool GetAutoLock() const { return currentSettings.autoLock; }
    int GetLockTimeout() const { return currentSettings.lockTimeout; }
    
    std::string GetProtocol() const { return currentSettings.protocol; }
    int GetPort() const { return currentSettings.port; }
    std::string GetDnsServer() const { return currentSettings.dnsServer; }
    int GetMtu() const { return currentSettings.mtu; }
    bool GetCompression() const { return currentSettings.compression; }
    bool GetIpv6Support() const { return currentSettings.ipv6Support; }
    bool GetKillSwitch() const { return currentSettings.killSwitch; }
    bool GetLeakProtection() const { return currentSettings.leakProtection; }
    int GetBandwidthLimit() const { return currentSettings.bandwidthLimit; }
    
    bool GetDebugMode() const { return currentSettings.debugMode; }
    bool GetVerboseLogging() const { return currentSettings.verboseLogging; }
    bool GetMemoryProtection() const { return currentSettings.memoryProtection; }
    bool GetAntiForensics() const { return currentSettings.antiForensics; }
    int GetCpuAffinity() const { return currentSettings.cpuAffinity; }
    std::string GetProcessPriority() const { return currentSettings.processPriority; }
    int GetBufferSize() const { return currentSettings.bufferSize; }
    int GetThreadCount() const { return currentSettings.threadCount; }
    
    bool GetDistressEnabled() const { return currentSettings.distressEnabled; }
    std::string GetPanicKey() const { return currentSettings.panicKey; }
    bool GetWipeData() const { return currentSettings.wipeData; }
    bool GetFakeShutdown() const { return currentSettings.fakeShutdown; }
    bool GetDecoyTraffic() const { return currentSettings.decoyTraffic; }
    std::string GetEmergencyContacts() const { return currentSettings.emergencyContacts; }
    bool GetSelfDestruct() const { return currentSettings.selfDestruct; }
    std::string GetCanaryToken() const { return currentSettings.canaryToken; }
    
    // Setters
    void SetAutoStart(bool value);
    void SetMinimizeToTray(bool value);
    void SetShowNotifications(bool value);
    void SetTheme(const std::string& value);
    void SetLanguage(const std::string& value);
    void SetOperatorName(const std::string& value);
    void SetLogLevel(int value);
    
    void SetEncryptionMethod(const std::string& value);
    void SetHashAlgorithm(const std::string& value);
    void SetKeySize(int value);
    void SetPerfectForwardSecrecy(bool value);
    void SetQuantumResistant(bool value);
    void SetTpmEnabled(bool value);
    void SetBiometricAuth(bool value);
    void SetAutoLock(bool value);
    void SetLockTimeout(int value);
    
    void SetProtocol(const std::string& value);
    void SetPort(int value);
    void SetDnsServer(const std::string& value);
    void SetMtu(int value);
    void SetCompression(bool value);
    void SetIpv6Support(bool value);
    void SetKillSwitch(bool value);
    void SetLeakProtection(bool value);
    void SetBandwidthLimit(int value);
    
    void SetDebugMode(bool value);
    void SetVerboseLogging(bool value);
    void SetMemoryProtection(bool value);
    void SetAntiForensics(bool value);
    void SetCpuAffinity(int value);
    void SetProcessPriority(const std::string& value);
    void SetBufferSize(int value);
    void SetThreadCount(int value);
    
    void SetDistressEnabled(bool value);
    void SetPanicKey(const std::string& value);
    void SetWipeData(bool value);
    void SetFakeShutdown(bool value);
    void SetDecoyTraffic(bool value);
    void SetEmergencyContacts(const std::string& value);
    void SetSelfDestruct(bool value);
    void SetCanaryToken(const std::string& value);
    
    // Validation
    bool ValidateSettings();
    std::string GetValidationError() const;
    
private:
    std::string m_validationError;
};

// Dialog procedures
INT_PTR CALLBACK SettingsDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK GeneralTabProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK SecurityTabProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK NetworkTabProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK AdvancedTabProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK DistressTabProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

// Utility functions
void InitializeSettingsDialog(HWND hDlg);
void PopulateComboBoxes(HWND hTab, int tabIndex);
void LoadSettingsToDialog(HWND hDlg);
void SaveSettingsFromDialog(HWND hDlg);
void ApplyTheme(HWND hDlg);
bool ValidateInput(HWND hControl, int controlType);

// Theme constants
#define THEME_CYBER_GREEN    0
#define THEME_CYBER_BLUE     1  
#define THEME_CYBER_PINK     2
#define THEME_MATRIX         3
#define THEME_TERMINAL       4

// Color definitions for cyber theme
#define COLOR_CYBER_BG       RGB(0, 0, 15)
#define COLOR_CYBER_TEXT     RGB(0, 255, 128)
#define COLOR_CYBER_ACCENT   RGB(255, 0, 128)
#define COLOR_CYAN_GLOW      RGB(0, 255, 255)
#define COLOR_ORANGE_ALERT   RGB(255, 128, 0)

#endif // SETTINGS_H
