/*
 * LACKYVPN Settings Panel Implementation
 * =====================================
 * 
 * Advanced configuration interface with 80s cyber theme
 * 
 * Security Level: CLASSIFIED
 * Built by: Lackadaisical Security
 */

#include "settings.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shlobj.h>

//=============================================================================
// SETTINGS DIALOG IMPLEMENTATION
//=============================================================================

INT_PTR CALLBACK SettingsDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
    static SettingsPanel* pSettings = nullptr;
    
    switch (message) {
        case WM_INITDIALOG:
            pSettings = reinterpret_cast<SettingsPanel*>(lParam);
            SetWindowLongPtr(hDlg, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pSettings));
            if (pSettings) {
                pSettings->InitializeDialog(hDlg);
            }
            return TRUE;
            
        case WM_COMMAND:
            if (pSettings) {
                return pSettings->OnCommand(LOWORD(wParam), HIWORD(wParam));
            }
            break;
            
        case WM_NOTIFY:
            if (pSettings) {
                return pSettings->OnNotify(reinterpret_cast<LPNMHDR>(lParam));
            }
            break;
            
        case WM_CTLCOLORDLG:
        case WM_CTLCOLORSTATIC:
        case WM_CTLCOLOREDIT:
            // Dark theme
            SetTextColor((HDC)wParam, RGB(0, 255, 41));
            SetBkColor((HDC)wParam, RGB(0, 0, 0));
            return (INT_PTR)GetStockObject(BLACK_BRUSH);
            
        case WM_CLOSE:
            EndDialog(hDlg, IDCANCEL);
            return TRUE;
    }
    
    return FALSE;
}

//=============================================================================
// SETTINGS PANEL CLASS IMPLEMENTATION
//=============================================================================

SettingsPanel::SettingsPanel() :
    m_hDlg(nullptr),
    m_hTabControl(nullptr),
    m_currentTab(0)
{
    LoadSettings();
}

SettingsPanel::~SettingsPanel() {
    SaveSettings();
}

void SettingsPanel::ShowSettings(HWND hParent) {
    DialogBoxParam(GetModuleHandle(nullptr), MAKEINTRESOURCE(IDD_SETTINGS),
                   hParent, SettingsDialogProc, reinterpret_cast<LPARAM>(this));
}

void SettingsPanel::InitializeDialog(HWND hDlg) {
    m_hDlg = hDlg;
    
    // Set dialog title with cyber theme
    SetWindowText(hDlg, L"🔧 LACKYVPN OPERATOR CONTROLS [CLASSIFIED] 🔧");
    
    // Create tab control
    CreateTabControl();
    
    // Initialize all tabs
    CreateGeneralTab();
    CreateSecurityTab();
    CreateNetworkTab();
    CreateAdvancedTab();
    CreateDistressTab();
    
    // Set dark theme
    ApplyCyberTheme();
    
    // Load current settings into controls
    LoadCurrentSettings();
}

void SettingsPanel::CreateTabControl() {
    RECT tabRect;
    GetClientRect(m_hDlg, &tabRect);
    
    m_hTabControl = CreateWindowEx(
        0, WC_TABCONTROL, L"",
        WS_CHILD | WS_VISIBLE | TCS_TABS,
        10, 10, tabRect.right - 20, tabRect.bottom - 60,
        m_hDlg, (HMENU)IDC_TAB_CONTROL, GetModuleHandle(nullptr), nullptr);
    
    // Add tabs
    TCITEM tie = {0};
    tie.mask = TCIF_TEXT;
    
    tie.pszText = const_cast<LPWSTR>(L"🔧 GENERAL");
    TabCtrl_InsertItem(m_hTabControl, 0, &tie);
    
    tie.pszText = const_cast<LPWSTR>(L"🛡️ SECURITY");
    TabCtrl_InsertItem(m_hTabControl, 1, &tie);
    
    tie.pszText = const_cast<LPWSTR>(L"🌐 NETWORK");
    TabCtrl_InsertItem(m_hTabControl, 2, &tie);
    
    tie.pszText = const_cast<LPWSTR>(L"⚡ ADVANCED");
    TabCtrl_InsertItem(m_hTabControl, 3, &tie);
    
    tie.pszText = const_cast<LPWSTR>(L"🚨 DISTRESS");
    TabCtrl_InsertItem(m_hTabControl, 4, &tie);
}

void SettingsPanel::CreateGeneralTab() {
    RECT tabRect;
    GetClientRect(m_hTabControl, &tabRect);
    TabCtrl_AdjustRect(m_hTabControl, FALSE, &tabRect);
    
    // Auto-start checkbox
    CreateWindowEx(
        0, WC_BUTTON, L"🚀 Start LACKYVPN with Windows",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 20, 300, 25,
        m_hTabControl, (HMENU)IDC_AUTOSTART, GetModuleHandle(nullptr), nullptr);
    
    // Auto-connect checkbox
    CreateWindowEx(
        0, WC_BUTTON, L"🔗 Auto-connect on startup",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 50, 300, 25,
        m_hTabControl, (HMENU)IDC_AUTOCONNECT, GetModuleHandle(nullptr), nullptr);
    
    // Minimize to tray
    CreateWindowEx(
        0, WC_BUTTON, L"📱 Minimize to system tray",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 80, 300, 25,
        m_hTabControl, (HMENU)IDC_MINIMIZE_TRAY, GetModuleHandle(nullptr), nullptr);
    
    // Language selection
    CreateWindowEx(
        0, WC_STATIC, L"🌍 Interface Language:",
        WS_CHILD | WS_VISIBLE,
        tabRect.left + 20, tabRect.top + 120, 150, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    HWND hLanguageCombo = CreateWindowEx(
        0, WC_COMBOBOX, nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        tabRect.left + 180, tabRect.top + 118, 200, 200,
        m_hTabControl, (HMENU)IDC_LANGUAGE, GetModuleHandle(nullptr), nullptr);
    
    SendMessage(hLanguageCombo, CB_ADDSTRING, 0, (LPARAM)L"English (Operator)");
    SendMessage(hLanguageCombo, CB_ADDSTRING, 0, (LPARAM)L"Deutsch (Operator)");
    SendMessage(hLanguageCombo, CB_ADDSTRING, 0, (LPARAM)L"Français (Opérateur)");
    SendMessage(hLanguageCombo, CB_ADDSTRING, 0, (LPARAM)L"日本語 (オペレーター)");
    SendMessage(hLanguageCombo, CB_SETCURSEL, 0, 0);
    
    // Theme selection
    CreateWindowEx(
        0, WC_STATIC, L"🎨 Interface Theme:",
        WS_CHILD | WS_VISIBLE,
        tabRect.left + 20, tabRect.top + 160, 150, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    HWND hThemeCombo = CreateWindowEx(
        0, WC_COMBOBOX, nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        tabRect.left + 180, tabRect.top + 158, 200, 200,
        m_hTabControl, (HMENU)IDC_THEME, GetModuleHandle(nullptr), nullptr);
    
    SendMessage(hThemeCombo, CB_ADDSTRING, 0, (LPARAM)L"🌈 80s Neon Cyber");
    SendMessage(hThemeCombo, CB_ADDSTRING, 0, (LPARAM)L"🖤 Dark Matrix");
    SendMessage(hThemeCombo, CB_ADDSTRING, 0, (LPARAM)L"🔥 Fire Protocol");
    SendMessage(hThemeCombo, CB_ADDSTRING, 0, (LPARAM)L"❄️ Ice Terminal");
    SendMessage(hThemeCombo, CB_SETCURSEL, 0, 0);
}

void SettingsPanel::CreateSecurityTab() {
    RECT tabRect;
    GetClientRect(m_hTabControl, &tabRect);
    TabCtrl_AdjustRect(m_hTabControl, FALSE, &tabRect);
    
    // Encryption level
    CreateWindowEx(
        0, WC_STATIC, L"🔐 Encryption Level:",
        WS_CHILD | BS_GROUPBOX,
        tabRect.left + 20, tabRect.top + 20, 350, 100,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🔒 Standard (AES-256)",
        WS_CHILD | BS_AUTORADIOBUTTON | WS_GROUP,
        tabRect.left + 30, tabRect.top + 45, 200, 20,
        m_hTabControl, (HMENU)IDC_ENC_STANDARD, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🔥 Fire Seal (10-Layer)",
        WS_CHILD | BS_AUTORADIOBUTTON,
        tabRect.left + 30, tabRect.top + 70, 200, 20,
        m_hTabControl, (HMENU)IDC_ENC_FIRE, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"⚛️ Quantum Resistant",
        WS_CHILD | BS_AUTORADIOBUTTON,
        tabRect.left + 30, tabRect.top + 95, 200, 20,
        m_hTabControl, (HMENU)IDC_ENC_QUANTUM, GetModuleHandle(nullptr), nullptr);
    
    // Security features
    CreateWindowEx(
        0, WC_BUTTON, L"👻 Enable Ghost Mode",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 140, 300, 25,
        m_hTabControl, (HMENU)IDC_GHOST_MODE, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🛡️ Anti-Forensics Protection",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 170, 300, 25,
        m_hTabControl, (HMENU)IDC_ANTI_FORENSICS, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🔀 Binary Mutation Engine",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 200, 300, 25,
        m_hTabControl, (HMENU)IDC_BINARY_MUTATION, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🕵️ Real-time Threat Detection",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 230, 300, 25,
        m_hTabControl, (HMENU)IDC_THREAT_DETECTION, GetModuleHandle(nullptr), nullptr);
    
    // Kill switch
    CreateWindowEx(
        0, WC_BUTTON, L"💀 Enable VPN Kill Switch",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 260, 300, 25,
        m_hTabControl, (HMENU)IDC_KILL_SWITCH, GetModuleHandle(nullptr), nullptr);
}

void SettingsPanel::CreateNetworkTab() {
    RECT tabRect;
    GetClientRect(m_hTabControl, &tabRect);
    TabCtrl_AdjustRect(m_hTabControl, FALSE, &tabRect);
    
    // DNS settings
    CreateWindowEx(
        0, WC_STATIC, L"🌐 DNS Configuration:",
        WS_CHILD | BS_GROUPBOX,
        tabRect.left + 20, tabRect.top + 20, 350, 120,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🔒 Use VPN DNS",
        WS_CHILD | BS_AUTORADIOBUTTON | WS_GROUP,
        tabRect.left + 30, tabRect.top + 45, 150, 20,
        m_hTabControl, (HMENU)IDC_DNS_VPN, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🛡️ Secure DNS (DoH)",
        WS_CHILD | BS_AUTORADIOBUTTON,
        tabRect.left + 30, tabRect.top + 70, 150, 20,
        m_hTabControl, (HMENU)IDC_DNS_DOH, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🏠 Custom DNS",
        WS_CHILD | BS_AUTORADIOBUTTON,
        tabRect.left + 30, tabRect.top + 95, 150, 20,
        m_hTabControl, (HMENU)IDC_DNS_CUSTOM, GetModuleHandle(nullptr), nullptr);
    
    // Custom DNS input
    CreateWindowEx(
        0, WC_EDIT, L"1.1.1.1, 8.8.8.8",
        WS_CHILD | WS_VISIBLE | WS_BORDER,
        tabRect.left + 200, tabRect.top + 93, 150, 22,
        m_hTabControl, (HMENU)IDC_DNS_SERVERS, GetModuleHandle(nullptr), nullptr);
    
    // Protocol settings
    CreateWindowEx(
        0, WC_STATIC, L"📡 VPN Protocol:",
        WS_CHILD | WS_VISIBLE,
        tabRect.left + 20, tabRect.top + 160, 150, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    HWND hProtocolCombo = CreateWindowEx(
        0, WC_COMBOBOX, nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        tabRect.left + 180, tabRect.top + 158, 200, 200,
        m_hTabControl, (HMENU)IDC_PROTOCOL, GetModuleHandle(nullptr), nullptr);
    
    SendMessage(hProtocolCombo, CB_ADDSTRING, 0, (LPARAM)L"🚀 OpenVPN (Recommended)");
    SendMessage(hProtocolCombo, CB_ADDSTRING, 0, (LPARAM)L"⚡ IKEv2/IPSec");
    SendMessage(hProtocolCombo, CB_ADDSTRING, 0, (LPARAM)L"🛡️ WireGuard");
    SendMessage(hProtocolCombo, CB_ADDSTRING, 0, (LPARAM)L"🔥 LACKYVPN Hybrid");
    SendMessage(hProtocolCombo, CB_SETCURSEL, 3, 0);
    
    // Port configuration
    CreateWindowEx(
        0, WC_STATIC, L"🔌 Connection Port:",
        WS_CHILD | WS_VISIBLE,
        tabRect.left + 20, tabRect.top + 200, 150, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_EDIT, L"443",
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_NUMBER,
        tabRect.left + 180, tabRect.top + 198, 100, 22,
        m_hTabControl, (HMENU)IDC_PORT, GetModuleHandle(nullptr), nullptr);
    
    // Advanced network options
    CreateWindowEx(
        0, WC_BUTTON, L"🌐 IPv6 Support",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 240, 300, 25,
        m_hTabControl, (HMENU)IDC_IPV6, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🔀 Randomize MAC Address",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 270, 300, 25,
        m_hTabControl, (HMENU)IDC_MAC_RANDOM, GetModuleHandle(nullptr), nullptr);
}

void SettingsPanel::CreateAdvancedTab() {
    RECT tabRect;
    GetClientRect(m_hTabControl, &tabRect);
    TabCtrl_AdjustRect(m_hTabControl, FALSE, &tabRect);
    
    // Logging options
    CreateWindowEx(
        0, WC_STATIC, L"📝 Logging Configuration:",
        WS_CHILD | BS_GROUPBOX,
        tabRect.left + 20, tabRect.top + 20, 350, 100,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"📊 Enable Debug Logging",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 30, tabRect.top + 45, 200, 20,
        m_hTabControl, (HMENU)IDC_DEBUG_LOG, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🔒 Encrypt Log Files",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 30, tabRect.top + 70, 200, 20,
        m_hTabControl, (HMENU)IDC_ENCRYPT_LOGS, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🗑️ Auto-delete Old Logs",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 30, tabRect.top + 95, 200, 20,
        m_hTabControl, (HMENU)IDC_AUTO_DELETE_LOGS, GetModuleHandle(nullptr), nullptr);
    
    // Performance settings
    CreateWindowEx(
        0, WC_STATIC, L"⚡ Performance Tuning:",
        WS_CHILD | WS_VISIBLE,
        tabRect.left + 20, tabRect.top + 140, 150, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_STATIC, L"CPU Priority:",
        WS_CHILD | WS_VISIBLE,
        tabRect.left + 20, tabRect.top + 170, 100, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    HWND hPriorityCombo = CreateWindowEx(
        0, WC_COMBOBOX, nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        tabRect.left + 130, tabRect.top + 168, 150, 200,
        m_hTabControl, (HMENU)IDC_CPU_PRIORITY, GetModuleHandle(nullptr), nullptr);
    
    SendMessage(hPriorityCombo, CB_ADDSTRING, 0, (LPARAM)L"🐌 Low Priority");
    SendMessage(hPriorityCombo, CB_ADDSTRING, 0, (LPARAM)L"⚖️ Normal Priority");
    SendMessage(hPriorityCombo, CB_ADDSTRING, 0, (LPARAM)L"⚡ High Priority");
    SendMessage(hPriorityCombo, CB_ADDSTRING, 0, (LPARAM)L"🚀 Real-time Priority");
    SendMessage(hPriorityCombo, CB_SETCURSEL, 2, 0);
    
    // Update settings
    CreateWindowEx(
        0, WC_BUTTON, L"🔄 Check for Updates Automatically",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 210, 300, 25,
        m_hTabControl, (HMENU)IDC_AUTO_UPDATE, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"📊 Send Anonymous Usage Stats",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 240, 300, 25,
        m_hTabControl, (HMENU)IDC_USAGE_STATS, GetModuleHandle(nullptr), nullptr);
    
    // Expert mode
    CreateWindowEx(
        0, WC_BUTTON, L"🧠 Enable Expert Mode",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 20, tabRect.top + 270, 300, 25,
        m_hTabControl, (HMENU)IDC_EXPERT_MODE, GetModuleHandle(nullptr), nullptr);
}

void SettingsPanel::CreateDistressTab() {
    RECT tabRect;
    GetClientRect(m_hTabControl, &tabRect);
    TabCtrl_AdjustRect(m_hTabControl, FALSE, &tabRect);
    
    // Warning text
    CreateWindowEx(
        0, WC_STATIC, L"⚠️ WARNING: CLASSIFIED EMERGENCY PROTOCOLS ⚠️",
        WS_CHILD | WS_VISIBLE | SS_CENTER,
        tabRect.left + 20, tabRect.top + 20, 350, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    // Distress mode settings
    CreateWindowEx(
        0, WC_STATIC, L"🚨 Distress Mode Configuration:",
        WS_CHILD | BS_GROUPBOX,
        tabRect.left + 20, tabRect.top + 50, 350, 120,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🎭 Enable UI Camouflage",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 30, tabRect.top + 75, 200, 20,
        m_hTabControl, (HMENU)IDC_UI_CAMOUFLAGE, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🔥 Auto Evidence Destruction",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 30, tabRect.top + 100, 200, 20,
        m_hTabControl, (HMENU)IDC_AUTO_DESTROY, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"📱 Hardware Kill Switch",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 30, tabRect.top + 125, 200, 20,
        m_hTabControl, (HMENU)IDC_HARDWARE_KILL, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🚪 Panic Room Mode",
        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
        tabRect.left + 30, tabRect.top + 150, 200, 20,
        m_hTabControl, (HMENU)IDC_PANIC_ROOM, GetModuleHandle(nullptr), nullptr);
    
    // Destruction level
    CreateWindowEx(
        0, WC_STATIC, L"💀 Evidence Destruction Level:",
        WS_CHILD | WS_VISIBLE,
        tabRect.left + 20, tabRect.top + 190, 200, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    HWND hDestroyCombo = CreateWindowEx(
        0, WC_COMBOBOX, nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        tabRect.left + 230, tabRect.top + 188, 140, 200,
        m_hTabControl, (HMENU)IDC_DESTROY_LEVEL, GetModuleHandle(nullptr), nullptr);
    
    SendMessage(hDestroyCombo, CB_ADDSTRING, 0, (LPARAM)L"🧹 Minimal Cleanup");
    SendMessage(hDestroyCombo, CB_ADDSTRING, 0, (LPARAM)L"🔥 Standard Burn");
    SendMessage(hDestroyCombo, CB_ADDSTRING, 0, (LPARAM)L"💀 Scorched Earth");
    SendMessage(hDestroyCombo, CB_ADDSTRING, 0, (LPARAM)L"🌋 Nuclear Option");
    SendMessage(hDestroyCombo, CB_SETCURSEL, 1, 0);
    
    // Emergency hotkey
    CreateWindowEx(
        0, WC_STATIC, L"⌨️ Emergency Hotkey:",
        WS_CHILD | WS_VISIBLE,
        tabRect.left + 20, tabRect.top + 230, 150, 20,
        m_hTabControl, nullptr, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_EDIT, L"Ctrl+Alt+Shift+F12",
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
        tabRect.left + 180, tabRect.top + 228, 150, 22,
        m_hTabControl, (HMENU)IDC_EMERGENCY_HOTKEY, GetModuleHandle(nullptr), nullptr);
    
    CreateWindowEx(
        0, WC_BUTTON, L"🔧 Configure",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        tabRect.left + 340, tabRect.top + 228, 60, 22,
        m_hTabControl, (HMENU)IDC_CONFIG_HOTKEY, GetModuleHandle(nullptr), nullptr);
}

void SettingsPanel::ApplyCyberTheme() {
    // Set dark background and neon text colors for all controls
    EnumChildWindows(m_hDlg, SetCyberThemeProc, 0);
    EnumChildWindows(m_hTabControl, SetCyberThemeProc, 0);
}

BOOL CALLBACK SettingsPanel::SetCyberThemeProc(HWND hwnd, LPARAM lParam) {
    UNREFERENCED_PARAMETER(lParam);
    
    wchar_t className[256];
    GetClassName(hwnd, className, 256);
    
    // Set font for all controls
    static HFONT hCyberFont = CreateFont(
        14, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");
    
    SendMessage(hwnd, WM_SETFONT, (WPARAM)hCyberFont, TRUE);
    
    return TRUE;
}

BOOL SettingsPanel::OnCommand(WORD id, WORD notifyCode) {
    switch (id) {
        case IDOK:
            SaveSettings();
            EndDialog(m_hDlg, IDOK);
            return TRUE;
            
        case IDCANCEL:
            EndDialog(m_hDlg, IDCANCEL);
            return TRUE;
            
        case IDC_CONFIG_HOTKEY:
            ConfigureHotkey();
            return TRUE;
            
        default:
            // Handle other control notifications
            break;
    }
    
    return FALSE;
}

BOOL SettingsPanel::OnNotify(LPNMHDR pnmh) {
    if (pnmh->hwndFrom == m_hTabControl && pnmh->code == TCN_SELCHANGE) {
        int newTab = TabCtrl_GetCurSel(m_hTabControl);
        if (newTab != m_currentTab) {
            ShowTabContent(newTab);
            m_currentTab = newTab;
        }
    }
    
    return FALSE;
}

void SettingsPanel::ShowTabContent(int tabIndex) {
    // Hide all tab content first
    HWND hChild = GetWindow(m_hTabControl, GW_CHILD);
    while (hChild) {
        ShowWindow(hChild, SW_HIDE);
        hChild = GetWindow(hChild, GW_HWNDNEXT);
    }
    
    // Show content for selected tab
    hChild = GetWindow(m_hTabControl, GW_CHILD);
    int controlsPerTab = 20; // Approximate
    int startIndex = tabIndex * controlsPerTab;
    int endIndex = startIndex + controlsPerTab;
    
    for (int i = 0; i < endIndex && hChild; ++i) {
        if (i >= startIndex) {
            ShowWindow(hChild, SW_SHOW);
        }
        hChild = GetWindow(hChild, GW_HWNDNEXT);
    }
}

void SettingsPanel::LoadSettings() {
    // Load settings from registry or config file
    HKEY hKey;
    if (RegOpenKeyEx(HKEY_CURRENT_USER, L"Software\\Lackadaisical\\LACKYVPN",
                     0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        
        // Load individual settings
        DWORD size = sizeof(DWORD);
        DWORD value;
        
        if (RegQueryValueEx(hKey, L"AutoStart", nullptr, nullptr, 
                           (LPBYTE)&value, &size) == ERROR_SUCCESS) {
            m_settings.autoStart = (value != 0);
        }
        
        if (RegQueryValueEx(hKey, L"AutoConnect", nullptr, nullptr,
                           (LPBYTE)&value, &size) == ERROR_SUCCESS) {
            m_settings.autoConnect = (value != 0);
        }
        
        // Load other settings...
        
        RegCloseKey(hKey);
    } else {
        // Set default values
        SetDefaultSettings();
    }
}

void SettingsPanel::SaveSettings() {
    // Save settings to registry
    HKEY hKey;
    if (RegCreateKeyEx(HKEY_CURRENT_USER, L"Software\\Lackadaisical\\LACKYVPN",
                       0, nullptr, REG_OPTION_NON_VOLATILE, KEY_WRITE,
                       nullptr, &hKey, nullptr) == ERROR_SUCCESS) {
        
        // Save individual settings
        DWORD value = m_settings.autoStart ? 1 : 0;
        RegSetValueEx(hKey, L"AutoStart", 0, REG_DWORD, (LPBYTE)&value, sizeof(value));
        
        value = m_settings.autoConnect ? 1 : 0;
        RegSetValueEx(hKey, L"AutoConnect", 0, REG_DWORD, (LPBYTE)&value, sizeof(value));
        
        // Save other settings...
        
        RegCloseKey(hKey);
    }
}

void SettingsPanel::LoadCurrentSettings() {
    // Load current settings into dialog controls
    if (m_hDlg) {
        CheckDlgButton(m_hDlg, IDC_AUTOSTART, m_settings.autoStart ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(m_hDlg, IDC_AUTOCONNECT, m_settings.autoConnect ? BST_CHECKED : BST_UNCHECKED);
        CheckDlgButton(m_hDlg, IDC_MINIMIZE_TRAY, m_settings.minimizeToTray ? BST_CHECKED : BST_UNCHECKED);
        
        // Set other controls...
    }
}

void SettingsPanel::SetDefaultSettings() {
    m_settings.autoStart = false;
    m_settings.autoConnect = false;
    m_settings.minimizeToTray = true;
    m_settings.language = 0; // English
    m_settings.theme = 0; // 80s Neon Cyber
    m_settings.encryptionLevel = 1; // Fire Seal
    m_settings.ghostMode = true;
    m_settings.antiForensics = true;
    m_settings.binaryMutation = true;
    m_settings.threatDetection = true;
    m_settings.killSwitch = true;
    m_settings.dnsMode = 0; // VPN DNS
    m_settings.protocol = 3; // LACKYVPN Hybrid
    m_settings.port = 443;
    m_settings.ipv6Support = true;
    m_settings.macRandomization = true;
    m_settings.debugLogging = false;
    m_settings.encryptLogs = true;
    m_settings.autoDeleteLogs = true;
    m_settings.cpuPriority = 2; // High
    m_settings.autoUpdate = true;
    m_settings.usageStats = false;
    m_settings.expertMode = false;
    m_settings.uiCamouflage = true;
    m_settings.autoDestroy = false;
    m_settings.hardwareKill = false;
    m_settings.panicRoom = false;
    m_settings.destroyLevel = 1; // Standard Burn
    wcscpy_s(m_settings.emergencyHotkey, L"Ctrl+Alt+Shift+F12");
    wcscpy_s(m_settings.dnsServers, L"1.1.1.1, 8.8.8.8");
}

void SettingsPanel::ConfigureHotkey() {
    MessageBox(m_hDlg,
              L"🔧 HOTKEY CONFIGURATION\n\n"
              L"Current Emergency Hotkey: Ctrl+Alt+Shift+F12\n\n"
              L"This hotkey will instantly activate distress mode.\n"
              L"Choose a combination that's easy to remember but\n"
              L"unlikely to be pressed accidentally.\n\n"
              L"⚠️ WARNING: This is a one-way action in emergency mode!",
              L"Emergency Hotkey Configuration",
              MB_OK | MB_ICONINFORMATION);
}
