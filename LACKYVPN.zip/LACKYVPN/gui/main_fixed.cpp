/**
 * LACKYVPN - Native Windows GUI Application (Fixed Version)
 * Zero-dependency operator-class privacy framework
 * 80s Retro-Cyber Security Theme with Proxy Support
 */

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <d2d1.h>
#include <dwrite.h>
#include <commdlg.h>
#include <shellapi.h>
#include <wininet.h>
#include <vector>
#include <string>

#include "resource.h"

#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "wininet.lib")

// Window class name and title
#define LACKYVPN_CLASS_NAME L"LackyVPNWindow"
#define LACKYVPN_WINDOW_TITLE L"LACKYVPN - OPERATOR TERMINAL v1.0 [CYBERNIGHT]"

// Control IDs
#define ID_CONNECT_BTN      1001
#define ID_DISCONNECT_BTN   1002
#define ID_SETTINGS_BTN     1003
#define ID_DISTRESS_BTN     1004
#define ID_STATUS_LIST      1005
#define ID_SERVER_COMBO     1006
#define ID_MODE_COMBO       1007
#define ID_ENCRYPTION_COMBO 1008
#define ID_PROXY_BTN        1009
#define ID_PROXY_TYPE_COMBO 1010
#define ID_PROXY_HOST_EDIT  1011
#define ID_PROXY_PORT_EDIT  1012
#define ID_PROXY_USER_EDIT  1013
#define ID_PROXY_PASS_EDIT  1014
#define ID_PROXY_ENABLE_CHECK 1015

// Proxy configuration structure
typedef struct {
    bool enabled;
    int type; // 0=HTTP, 1=HTTPS, 2=SOCKS5
    wchar_t host[256];
    int port;
    wchar_t username[64];
    wchar_t password[64];
} proxy_config_t;

// Template for COM interface release
template<class Interface>
inline void SafeRelease(Interface **ppInterfaceToRelease) {
    if (*ppInterfaceToRelease != NULL) {
        (*ppInterfaceToRelease)->Release();
        (*ppInterfaceToRelease) = NULL;
    }
}

// ========== MAIN INTERFACE CLASS ==========
class CyberInterface {
private:
    // Window handles
    HWND m_hWnd;
    HWND m_hConnectBtn;
    HWND m_hDisconnectBtn;
    HWND m_hSettingsBtn;
    HWND m_hDistressBtn;
    HWND m_hStatusList;
    HWND m_hEncryptionCombo;
    HWND m_hLocationCombo;
    HWND m_hProxyBtn;
    HWND m_hProxyDialog;
    
    // Proxy controls
    HWND m_hProxyTypeCombo;
    HWND m_hProxyHostEdit;
    HWND m_hProxyPortEdit;
    HWND m_hProxyUserEdit;
    HWND m_hProxyPassEdit;
    HWND m_hProxyEnableCheck;
    
    // Direct2D resources
    ID2D1Factory* m_pD2DFactory;
    ID2D1HwndRenderTarget* m_pRenderTarget;
    ID2D1SolidColorBrush* m_pNeonGreenBrush;
    ID2D1SolidColorBrush* m_pNeonBlueBrush;
    ID2D1SolidColorBrush* m_pNeonPinkBrush;
    ID2D1SolidColorBrush* m_pNeonOrangeBrush;
    ID2D1SolidColorBrush* m_pBackgroundBrush;
    
    // DirectWrite resources
    IDWriteFactory* m_pWriteFactory;
    IDWriteTextFormat* m_pTextFormat;
    
    // Status tracking
    bool m_connected;
    bool m_distressActive;
    
    // Proxy configuration
    proxy_config_t m_proxyConfig;
    
    // Animation state
    float m_animTime;
    std::vector<D2D1_POINT_2F> m_matrixDrops;

public:
    CyberInterface() :
        m_hWnd(nullptr),
        m_hConnectBtn(nullptr),
        m_hDisconnectBtn(nullptr),
        m_hSettingsBtn(nullptr),
        m_hDistressBtn(nullptr),
        m_hStatusList(nullptr),
        m_hEncryptionCombo(nullptr),
        m_hLocationCombo(nullptr),
        m_hProxyBtn(nullptr),
        m_hProxyDialog(nullptr),
        m_hProxyTypeCombo(nullptr),
        m_hProxyHostEdit(nullptr),
        m_hProxyPortEdit(nullptr),
        m_hProxyUserEdit(nullptr),
        m_hProxyPassEdit(nullptr),
        m_hProxyEnableCheck(nullptr),
        m_pD2DFactory(nullptr),
        m_pRenderTarget(nullptr),
        m_pNeonGreenBrush(nullptr),
        m_pNeonBlueBrush(nullptr),
        m_pNeonPinkBrush(nullptr),
        m_pNeonOrangeBrush(nullptr),
        m_pBackgroundBrush(nullptr),
        m_pWriteFactory(nullptr),
        m_pTextFormat(nullptr),
        m_connected(false),
        m_distressActive(false),
        m_animTime(0.0f)
    {
        // Initialize proxy config
        memset(&m_proxyConfig, 0, sizeof(m_proxyConfig));
        m_proxyConfig.port = 8080; // Default HTTP proxy port
    }

    ~CyberInterface() {
        Cleanup();
    }

    bool Initialize(HINSTANCE hInstance);
    void Cleanup();
    HWND GetWindow() const { return m_hWnd; }
    
    // Proxy management
    void ShowProxySettings();
    void SaveProxySettings();
    void LoadProxySettings();
    void ApplyProxySettings();
    bool TestProxyConnection();
    
    // Event handlers
    void OnConnect();
    void OnDisconnect();
    void OnSettings();
    void OnDistress();
    void OnProxySettings();
    
    // Rendering
    void OnPaint();
    void OnTimer();
    
    // Window procedure
    static LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    static INT_PTR CALLBACK ProxyDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
    
private:
    bool CreateMainWindow(HINSTANCE hInstance);
    bool CreateControls();
    bool InitializeDirectX();
    void CreateRenderTarget();
    void CreateBrushes();
    void CreateTextFormat();
    void DrawBackground();
    void DrawMatrixRain();
    void DrawStatusDisplay();
    void DrawControls();
    void UpdateMatrixAnimation();
    void AddStatusMessage(const wchar_t* message);
    
    // Proxy helper functions
    void InitializeProxyDialog(HWND hDlg);
    void PopulateProxySettings(HWND hDlg);
    void SaveProxyConfig();
    void LoadProxyConfig();
    std::wstring GetProxyUrl();
};

// Global interface pointer
CyberInterface* g_pInterface = nullptr;

// ========== PROXY CONFIGURATION FUNCTIONS ==========

void CyberInterface::ShowProxySettings() {
    DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_PROXY_DIALOG), m_hWnd, ProxyDialogProc);
}

INT_PTR CALLBACK CyberInterface::ProxyDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_INITDIALOG:
            if (g_pInterface) {
                g_pInterface->InitializeProxyDialog(hDlg);
                g_pInterface->PopulateProxySettings(hDlg);
            }
            return TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK) {
                if (g_pInterface) {
                    g_pInterface->SaveProxySettings();
                }
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            } else if (LOWORD(wParam) == IDCANCEL) {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            } else if (LOWORD(wParam) == ID_PROXY_ENABLE_CHECK) {
                // Enable/disable proxy controls based on checkbox
                BOOL enabled = IsDlgButtonChecked(hDlg, ID_PROXY_ENABLE_CHECK);
                EnableWindow(GetDlgItem(hDlg, ID_PROXY_TYPE_COMBO), enabled);
                EnableWindow(GetDlgItem(hDlg, ID_PROXY_HOST_EDIT), enabled);
                EnableWindow(GetDlgItem(hDlg, ID_PROXY_PORT_EDIT), enabled);
                EnableWindow(GetDlgItem(hDlg, ID_PROXY_USER_EDIT), enabled);
                EnableWindow(GetDlgItem(hDlg, ID_PROXY_PASS_EDIT), enabled);
                return TRUE;
            }
            break;
    }
    return FALSE;
}

void CyberInterface::InitializeProxyDialog(HWND hDlg) {
    // Store dialog handle
    m_hProxyDialog = hDlg;
    
    // Get control handles
    m_hProxyEnableCheck = GetDlgItem(hDlg, ID_PROXY_ENABLE_CHECK);
    m_hProxyTypeCombo = GetDlgItem(hDlg, ID_PROXY_TYPE_COMBO);
    m_hProxyHostEdit = GetDlgItem(hDlg, ID_PROXY_HOST_EDIT);
    m_hProxyPortEdit = GetDlgItem(hDlg, ID_PROXY_PORT_EDIT);
    m_hProxyUserEdit = GetDlgItem(hDlg, ID_PROXY_USER_EDIT);
    m_hProxyPassEdit = GetDlgItem(hDlg, ID_PROXY_PASS_EDIT);
    
    // Populate proxy type combo
    SendMessage(m_hProxyTypeCombo, CB_ADDSTRING, 0, (LPARAM)L"HTTP");
    SendMessage(m_hProxyTypeCombo, CB_ADDSTRING, 0, (LPARAM)L"HTTPS");
    SendMessage(m_hProxyTypeCombo, CB_ADDSTRING, 0, (LPARAM)L"SOCKS5");
    SendMessage(m_hProxyTypeCombo, CB_SETCURSEL, 0, 0);
}

void CyberInterface::PopulateProxySettings(HWND hDlg) {
    // Load current proxy configuration
    LoadProxyConfig();
    
    // Set checkbox state
    CheckDlgButton(hDlg, ID_PROXY_ENABLE_CHECK, m_proxyConfig.enabled ? BST_CHECKED : BST_UNCHECKED);
    
    // Set proxy type
    SendMessage(m_hProxyTypeCombo, CB_SETCURSEL, m_proxyConfig.type, 0);
    
    // Set text fields
    SetWindowText(m_hProxyHostEdit, m_proxyConfig.host);
    SetWindowText(m_hProxyUserEdit, m_proxyConfig.username);
    SetWindowText(m_hProxyPassEdit, m_proxyConfig.password);
    
    // Set port
    wchar_t portStr[16];
    swprintf_s(portStr, L"%d", m_proxyConfig.port);
    SetWindowText(m_hProxyPortEdit, portStr);
    
    // Enable/disable controls based on checkbox
    BOOL enabled = m_proxyConfig.enabled;
    EnableWindow(m_hProxyTypeCombo, enabled);
    EnableWindow(m_hProxyHostEdit, enabled);
    EnableWindow(m_hProxyPortEdit, enabled);
    EnableWindow(m_hProxyUserEdit, enabled);
    EnableWindow(m_hProxyPassEdit, enabled);
}

void CyberInterface::SaveProxySettings() {
    if (!m_hProxyDialog) return;
    
    // Get checkbox state
    m_proxyConfig.enabled = IsDlgButtonChecked(m_hProxyDialog, ID_PROXY_ENABLE_CHECK) == BST_CHECKED;
    
    // Get proxy type
    m_proxyConfig.type = (int)SendMessage(m_hProxyTypeCombo, CB_GETCURSEL, 0, 0);
    
    // Get text fields
    GetWindowText(m_hProxyHostEdit, m_proxyConfig.host, 256);
    GetWindowText(m_hProxyUserEdit, m_proxyConfig.username, 64);
    GetWindowText(m_hProxyPassEdit, m_proxyConfig.password, 64);
    
    // Get port
    wchar_t portStr[16];
    GetWindowText(m_hProxyPortEdit, portStr, 16);
    m_proxyConfig.port = _wtoi(portStr);
    if (m_proxyConfig.port <= 0 || m_proxyConfig.port > 65535) {
        m_proxyConfig.port = 8080; // Default
    }
    
    // Save to registry/file
    SaveProxyConfig();
    
    // Apply settings
    ApplyProxySettings();
    
    // Update status
    if (m_proxyConfig.enabled) {
        AddStatusMessage(L"[PROXY] Configuration updated and applied");
    } else {
        AddStatusMessage(L"[PROXY] Disabled");
    }
}

void CyberInterface::SaveProxyConfig() {
    // Save to Windows registry
    HKEY hKey;
    if (RegCreateKeyEx(HKEY_CURRENT_USER, L"Software\\LACKYVPN\\Proxy", 0, NULL, 
                       REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        
        DWORD enabled = m_proxyConfig.enabled ? 1 : 0;
        RegSetValueEx(hKey, L"Enabled", 0, REG_DWORD, (BYTE*)&enabled, sizeof(DWORD));
        RegSetValueEx(hKey, L"Type", 0, REG_DWORD, (BYTE*)&m_proxyConfig.type, sizeof(DWORD));
        RegSetValueEx(hKey, L"Host", 0, REG_SZ, (BYTE*)m_proxyConfig.host, 
                      (DWORD)(wcslen(m_proxyConfig.host) + 1) * sizeof(wchar_t));
        RegSetValueEx(hKey, L"Port", 0, REG_DWORD, (BYTE*)&m_proxyConfig.port, sizeof(DWORD));
        RegSetValueEx(hKey, L"Username", 0, REG_SZ, (BYTE*)m_proxyConfig.username, 
                      (DWORD)(wcslen(m_proxyConfig.username) + 1) * sizeof(wchar_t));
        
        // Note: In production, password should be encrypted
        RegSetValueEx(hKey, L"Password", 0, REG_SZ, (BYTE*)m_proxyConfig.password, 
                      (DWORD)(wcslen(m_proxyConfig.password) + 1) * sizeof(wchar_t));
        
        RegCloseKey(hKey);
    }
}

void CyberInterface::LoadProxyConfig() {
    // Load from Windows registry
    HKEY hKey;
    if (RegOpenKeyEx(HKEY_CURRENT_USER, L"Software\\LACKYVPN\\Proxy", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        
        DWORD dataSize, type;
        
        // Load enabled state
        dataSize = sizeof(DWORD);
        DWORD enabled = 0;
        if (RegQueryValueEx(hKey, L"Enabled", NULL, &type, (BYTE*)&enabled, &dataSize) == ERROR_SUCCESS) {
            m_proxyConfig.enabled = (enabled != 0);
        }
        
        // Load type
        dataSize = sizeof(DWORD);
        RegQueryValueEx(hKey, L"Type", NULL, &type, (BYTE*)&m_proxyConfig.type, &dataSize);
        
        // Load host
        dataSize = sizeof(m_proxyConfig.host);
        RegQueryValueEx(hKey, L"Host", NULL, &type, (BYTE*)m_proxyConfig.host, &dataSize);
        
        // Load port
        dataSize = sizeof(DWORD);
        RegQueryValueEx(hKey, L"Port", NULL, &type, (BYTE*)&m_proxyConfig.port, &dataSize);
        
        // Load username
        dataSize = sizeof(m_proxyConfig.username);
        RegQueryValueEx(hKey, L"Username", NULL, &type, (BYTE*)m_proxyConfig.username, &dataSize);
        
        // Load password
        dataSize = sizeof(m_proxyConfig.password);
        RegQueryValueEx(hKey, L"Password", NULL, &type, (BYTE*)m_proxyConfig.password, &dataSize);
        
        RegCloseKey(hKey);
    }
}

void CyberInterface::ApplyProxySettings() {
    if (!m_proxyConfig.enabled) {
        // Disable proxy
        INTERNET_PER_CONN_OPTION_LIST list;
        INTERNET_PER_CONN_OPTION options[2];
        
        options[0].dwOption = INTERNET_PER_CONN_FLAGS;
        options[0].Value.dwValue = PROXY_TYPE_DIRECT;
        
        options[1].dwOption = INTERNET_PER_CONN_PROXY_SERVER;
        options[1].Value.pszValue = NULL;
        
        list.dwSize = sizeof(INTERNET_PER_CONN_OPTION_LIST);
        list.pszConnection = NULL; // Default connection
        list.dwOptionCount = 2;
        list.pOptions = options;
        
        InternetSetOption(NULL, INTERNET_OPTION_PER_CONNECTION_OPTION, &list, sizeof(list));
        return;
    }
    
    // Build proxy URL
    std::wstring proxyUrl = GetProxyUrl();
    
    // Apply proxy settings to system
    INTERNET_PER_CONN_OPTION_LIST list;
    INTERNET_PER_CONN_OPTION options[2];
    
    options[0].dwOption = INTERNET_PER_CONN_FLAGS;
    options[0].Value.dwValue = PROXY_TYPE_PROXY;
    
    options[1].dwOption = INTERNET_PER_CONN_PROXY_SERVER;
    options[1].Value.pszValue = (wchar_t*)proxyUrl.c_str();
    
    list.dwSize = sizeof(INTERNET_PER_CONN_OPTION_LIST);
    list.pszConnection = NULL; // Default connection
    list.dwOptionCount = 2;
    list.pOptions = options;
    
    InternetSetOption(NULL, INTERNET_OPTION_PER_CONNECTION_OPTION, &list, sizeof(list));
    
    // Notify that proxy settings have changed
    InternetSetOption(NULL, INTERNET_OPTION_SETTINGS_CHANGED, NULL, 0);
    InternetSetOption(NULL, INTERNET_OPTION_REFRESH, NULL, 0);
}

std::wstring CyberInterface::GetProxyUrl() {
    std::wstring url;
    
    // Build proxy URL based on type
    switch (m_proxyConfig.type) {
        case 0: // HTTP
            url = L"http://";
            break;
        case 1: // HTTPS
            url = L"https://";
            break;
        case 2: // SOCKS5
            url = L"socks5://";
            break;
        default:
            url = L"http://";
            break;
    }
    
    // Add authentication if provided
    if (wcslen(m_proxyConfig.username) > 0) {
        url += m_proxyConfig.username;
        if (wcslen(m_proxyConfig.password) > 0) {
            url += L":";
            url += m_proxyConfig.password;
        }
        url += L"@";
    }
    
    // Add host and port
    url += m_proxyConfig.host;
    url += L":";
    url += std::to_wstring(m_proxyConfig.port);
    
    return url;
}

bool CyberInterface::TestProxyConnection() {
    if (!m_proxyConfig.enabled) return true;
    
    // Test connection through proxy
    HINTERNET hInternet = InternetOpen(L"LACKYVPN-ProxyTest", 
                                       INTERNET_OPEN_TYPE_PROXY,
                                       GetProxyUrl().c_str(),
                                       NULL, 0);
    
    if (!hInternet) return false;
    
    HINTERNET hConnect = InternetOpenUrl(hInternet, L"http://www.google.com",
                                         NULL, 0, INTERNET_FLAG_RELOAD, 0);
    
    bool success = (hConnect != NULL);
    
    if (hConnect) InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);
    
    return success;
}

// ========== MAIN INTERFACE IMPLEMENTATION ==========

bool CyberInterface::Initialize(HINSTANCE hInstance) {
    // Load proxy configuration
    LoadProxyConfig();
    
    if (!CreateMainWindow(hInstance)) return false;
    if (!CreateControls()) return false;
    if (!InitializeDirectX()) return false;
    
    // Initialize matrix rain animation
    m_matrixDrops.resize(20);
    for (auto& drop : m_matrixDrops) {
        drop.x = (float)(rand() % 800);
        drop.y = (float)(rand() % 600);
    }
    
    // Set timer for animation
    SetTimer(m_hWnd, 1, 50, NULL); // 20 FPS
    
    AddStatusMessage(L"[SYSTEM] LACKYVPN Operator Terminal Initialized");
    AddStatusMessage(L"[SYSTEM] Quantum-Safe Cryptographic Subsystems Online");
    AddStatusMessage(L"[SYSTEM] Ghost Engine Standing By");
    
    if (m_proxyConfig.enabled) {
        AddStatusMessage(L"[PROXY] Custom proxy configuration loaded");
    }
    
    return true;
}

void CyberInterface::Cleanup() {
    // Cleanup Direct2D resources
    SafeRelease(&m_pNeonGreenBrush);
    SafeRelease(&m_pNeonBlueBrush);
    SafeRelease(&m_pNeonPinkBrush);
    SafeRelease(&m_pNeonOrangeBrush);
    SafeRelease(&m_pBackgroundBrush);
    SafeRelease(&m_pRenderTarget);
    SafeRelease(&m_pD2DFactory);
    
    // Cleanup DirectWrite resources
    SafeRelease(&m_pTextFormat);
    SafeRelease(&m_pWriteFactory);
}

// Event handlers
void CyberInterface::OnConnect() {
    if (m_connected) return;
    
    AddStatusMessage(L"[VPN] Initiating secure tunnel establishment...");
    AddStatusMessage(L"[CRYPTO] Quantum-safe key exchange in progress...");
    
    if (m_proxyConfig.enabled) {
        if (TestProxyConnection()) {
            AddStatusMessage(L"[PROXY] Connection verified through proxy");
        } else {
            AddStatusMessage(L"[PROXY] WARNING: Proxy connection test failed");
        }
    }
    
    // Simulate connection process
    Sleep(1000);
    m_connected = true;
    EnableWindow(m_hConnectBtn, FALSE);
    EnableWindow(m_hDisconnectBtn, TRUE);
    
    AddStatusMessage(L"[VPN] *** SECURE TUNNEL ESTABLISHED ***");
    AddStatusMessage(L"[GHOST] Traffic obfuscation active");
}

void CyberInterface::OnDisconnect() {
    if (!m_connected) return;
    
    AddStatusMessage(L"[VPN] Terminating secure tunnel...");
    
    m_connected = false;
    EnableWindow(m_hConnectBtn, TRUE);
    EnableWindow(m_hDisconnectBtn, FALSE);
    
    AddStatusMessage(L"[VPN] Tunnel terminated");
    AddStatusMessage(L"[SYSTEM] Standing by for orders");
}

void CyberInterface::OnSettings() {
    AddStatusMessage(L"[SYSTEM] Accessing operator configuration panel...");
    MessageBox(m_hWnd, L"Advanced Settings Panel\n\nConfiguration options coming soon...", 
               L"LACKYVPN Settings", MB_OK | MB_ICONINFORMATION);
}

void CyberInterface::OnDistress() {
    if (m_distressActive) return;
    
    int result = MessageBox(m_hWnd, 
        L"⚠️ DISTRESS PROTOCOL ACTIVATION ⚠️\n\n"
        L"This will immediately:\n"
        L"• Destroy all evidence\n"
        L"• Wipe temporary files\n"
        L"• Activate UI camouflage\n"
        L"• Emergency network isolation\n\n"
        L"Are you sure you want to continue?", 
        L"DISTRESS MODE", MB_YESNO | MB_ICONWARNING);
    
    if (result == IDYES) {
        m_distressActive = true;
        AddStatusMessage(L"[DISTRESS] *** EMERGENCY PROTOCOL ACTIVATED ***");
        AddStatusMessage(L"[DISTRESS] Evidence destruction in progress...");
        AddStatusMessage(L"[DISTRESS] UI camouflage active");
        AddStatusMessage(L"[DISTRESS] Network isolation complete");
        
        // Change window title for camouflage
        SetWindowText(m_hWnd, L"System Monitor v2.1");
    }
}

void CyberInterface::OnProxySettings() {
    ShowProxySettings();
}

// Placeholder implementations for the rest of the class
bool CyberInterface::CreateMainWindow(HINSTANCE hInstance) {
    // Register window class
    WNDCLASSEX wcex = {};
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WindowProc;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszClassName = LACKYVPN_CLASS_NAME;
    wcex.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
    
    RegisterClassEx(&wcex);
    
    // Create window
    m_hWnd = CreateWindowEx(
        WS_EX_CLIENTEDGE,
        LACKYVPN_CLASS_NAME,
        LACKYVPN_WINDOW_TITLE,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        1000, 700,
        NULL, NULL, hInstance, NULL
    );
    
    return (m_hWnd != NULL);
}

bool CyberInterface::CreateControls() {
    // Create connect button
    m_hConnectBtn = CreateWindow(L"BUTTON", L"ESTABLISH TUNNEL",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        20, 20, 150, 40, m_hWnd, (HMENU)ID_CONNECT_BTN, NULL, NULL);
    
    // Create disconnect button
    m_hDisconnectBtn = CreateWindow(L"BUTTON", L"TERMINATE",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        180, 20, 150, 40, m_hWnd, (HMENU)ID_DISCONNECT_BTN, NULL, NULL);
    EnableWindow(m_hDisconnectBtn, FALSE);
    
    // Create proxy settings button
    m_hProxyBtn = CreateWindow(L"BUTTON", L"PROXY CONFIG",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        340, 20, 150, 40, m_hWnd, (HMENU)ID_PROXY_BTN, NULL, NULL);
    
    // Create settings button
    m_hSettingsBtn = CreateWindow(L"BUTTON", L"OPERATOR CONFIG",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        500, 20, 150, 40, m_hWnd, (HMENU)ID_SETTINGS_BTN, NULL, NULL);
    
    // Create distress button
    m_hDistressBtn = CreateWindow(L"BUTTON", L"🚨 DISTRESS 🚨",
        WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        660, 20, 150, 40, m_hWnd, (HMENU)ID_DISTRESS_BTN, NULL, NULL);
    
    // Create status list
    m_hStatusList = CreateWindow(L"LISTBOX", NULL,
        WS_VISIBLE | WS_CHILD | WS_BORDER | WS_VSCROLL,
        20, 80, 950, 500, m_hWnd, (HMENU)ID_STATUS_LIST, NULL, NULL);
    
    return true;
}

bool CyberInterface::InitializeDirectX() {
    HRESULT hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &m_pD2DFactory);
    if (FAILED(hr)) return false;
    
    hr = DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(m_pWriteFactory),
                             reinterpret_cast<IUnknown**>(&m_pWriteFactory));
    if (FAILED(hr)) return false;
    
    CreateRenderTarget();
    CreateBrushes();
    CreateTextFormat();
    
    return true;
}

void CyberInterface::CreateRenderTarget() {
    if (m_pRenderTarget) return;
    
    RECT rc;
    GetClientRect(m_hWnd, &rc);
    
    D2D1_SIZE_U size = D2D1::SizeU(rc.right, rc.bottom);
    
    m_pD2DFactory->CreateHwndRenderTarget(
        D2D1::RenderTargetProperties(),
        D2D1::HwndRenderTargetProperties(m_hWnd, size),
        &m_pRenderTarget
    );
}

void CyberInterface::CreateBrushes() {
    if (!m_pRenderTarget) return;
    
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 1.0f, 0.0f, 1.0f), &m_pNeonGreenBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.8f, 1.0f, 1.0f), &m_pNeonBlueBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.0f, 1.0f, 1.0f), &m_pNeonPinkBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.5f, 0.0f, 1.0f), &m_pNeonOrangeBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.05f, 0.05f, 0.1f, 1.0f), &m_pBackgroundBrush);
}

void CyberInterface::CreateTextFormat() {
    if (!m_pWriteFactory) return;
    
    m_pWriteFactory->CreateTextFormat(
        L"Consolas",
        NULL,
        DWRITE_FONT_WEIGHT_NORMAL,
        DWRITE_FONT_STYLE_NORMAL,
        DWRITE_FONT_STRETCH_NORMAL,
        12.0f,
        L"",
        &m_pTextFormat
    );
}

void CyberInterface::OnPaint() {
    if (!m_pRenderTarget) {
        CreateRenderTarget();
        CreateBrushes();
    }
    
    if (!m_pRenderTarget) return;
    
    m_pRenderTarget->BeginDraw();
    
    DrawBackground();
    DrawMatrixRain();
    
    m_pRenderTarget->EndDraw();
}

void CyberInterface::DrawBackground() {
    if (!m_pRenderTarget || !m_pBackgroundBrush) return;
    
    D2D1_SIZE_F rtSize = m_pRenderTarget->GetSize();
    m_pRenderTarget->Clear(D2D1::ColorF(D2D1::ColorF::Black));
    
    // Draw cyberpunk grid pattern
    if (m_pNeonGreenBrush) {
        for (float x = 0; x < rtSize.width; x += 50) {
            m_pRenderTarget->DrawLine(
                D2D1::Point2F(x, 0),
                D2D1::Point2F(x, rtSize.height),
                m_pNeonGreenBrush,
                0.3f
            );
        }
        
        for (float y = 0; y < rtSize.height; y += 50) {
            m_pRenderTarget->DrawLine(
                D2D1::Point2F(0, y),
                D2D1::Point2F(rtSize.width, y),
                m_pNeonGreenBrush,
                0.3f
            );
        }
    }
}

void CyberInterface::DrawMatrixRain() {
    if (!m_pRenderTarget || !m_pNeonGreenBrush || !m_pTextFormat) return;
    
    for (size_t i = 0; i < m_matrixDrops.size(); ++i) {
        wchar_t ch = L'0' + (rand() % 10);
        std::wstring str(1, ch);
        
        D2D1_RECT_F textRect = D2D1::RectF(
            m_matrixDrops[i].x, m_matrixDrops[i].y,
            m_matrixDrops[i].x + 20, m_matrixDrops[i].y + 20
        );
        
        m_pRenderTarget->DrawTextW(
            str.c_str(),
            (UINT32)str.length(),
            m_pTextFormat,
            textRect,
            m_pNeonGreenBrush
        );
    }
}

void CyberInterface::UpdateMatrixAnimation() {
    D2D1_SIZE_F rtSize = m_pRenderTarget ? m_pRenderTarget->GetSize() : D2D1::SizeF(800, 600);
    
    for (auto& drop : m_matrixDrops) {
        drop.y += 2.0f;
        if (drop.y > rtSize.height) {
            drop.y = -20.0f;
            drop.x = (float)(rand() % (int)rtSize.width);
        }
    }
}

void CyberInterface::OnTimer() {
    UpdateMatrixAnimation();
    InvalidateRect(m_hWnd, NULL, FALSE);
}

void CyberInterface::AddStatusMessage(const wchar_t* message) {
    if (!m_hStatusList) return;
    
    // Get current time
    SYSTEMTIME st;
    GetLocalTime(&st);
    
    wchar_t timestamp[32];
    swprintf_s(timestamp, L"%02d:%02d:%02d ", st.wHour, st.wMinute, st.wSecond);
    
    std::wstring fullMessage = timestamp;
    fullMessage += message;
    
    SendMessage(m_hStatusList, LB_ADDSTRING, 0, (LPARAM)fullMessage.c_str());
    
    // Auto-scroll to bottom
    int count = (int)SendMessage(m_hStatusList, LB_GETCOUNT, 0, 0);
    SendMessage(m_hStatusList, LB_SETTOPINDEX, count - 1, 0);
}

LRESULT CALLBACK CyberInterface::WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_CREATE:
            g_pInterface = new CyberInterface();
            SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR)g_pInterface);
            break;
            
        case WM_COMMAND:
            if (g_pInterface) {
                switch (LOWORD(wParam)) {
                    case ID_CONNECT_BTN:
                        g_pInterface->OnConnect();
                        break;
                    case ID_DISCONNECT_BTN:
                        g_pInterface->OnDisconnect();
                        break;
                    case ID_SETTINGS_BTN:
                        g_pInterface->OnSettings();
                        break;
                    case ID_DISTRESS_BTN:
                        g_pInterface->OnDistress();
                        break;
                    case ID_PROXY_BTN:
                        g_pInterface->OnProxySettings();
                        break;
                }
            }
            break;
            
        case WM_PAINT:
            if (g_pInterface) {
                g_pInterface->OnPaint();
            }
            break;
            
        case WM_TIMER:
            if (g_pInterface) {
                g_pInterface->OnTimer();
            }
            break;
            
        case WM_SIZE:
            if (g_pInterface && g_pInterface->m_pRenderTarget) {
                RECT rc;
                GetClientRect(hwnd, &rc);
                D2D1_SIZE_U size = D2D1::SizeU(rc.right, rc.bottom);
                g_pInterface->m_pRenderTarget->Resize(size);
            }
            break;
            
        case WM_DESTROY:
            if (g_pInterface) {
                delete g_pInterface;
                g_pInterface = nullptr;
            }
            PostQuitMessage(0);
            break;
            
        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0;
}

// ========== APPLICATION ENTRY POINT ==========

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
    // Initialize COM
    CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    
    // Initialize common controls
    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_LISTVIEW_CLASSES | ICC_TREEVIEW_CLASSES;
    InitCommonControlsEx(&icex);
    
    CyberInterface interface;
    g_pInterface = &interface;
    
    if (!interface.Initialize(hInstance)) {
        MessageBox(NULL, L"Failed to initialize LACKYVPN interface", L"Error", MB_OK | MB_ICONERROR);
        return -1;
    }
    
    ShowWindow(interface.GetWindow(), nCmdShow);
    UpdateWindow(interface.GetWindow());
    
    // Main message loop
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    
    CoUninitialize();
    return (int)msg.wParam;
}
