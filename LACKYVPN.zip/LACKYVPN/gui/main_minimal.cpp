/**
 * LACKYVPN - Native Windows GUI Application
 * Minimal working version for testing compilation
 */

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <d2d1.h>
#include <dwrite.h>
#include <vector>

#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "comctl32.lib")

// ========== 80s CYBER THEME CONSTANTS ==========
#define CYBER_BACKGROUND RGB(10, 10, 25)
#define CYBER_NEON_GREEN RGB(0, 255, 65)
#define CYBER_NEON_BLUE RGB(0, 191, 255)
#define CYBER_NEON_PINK RGB(255, 20, 147)
#define CYBER_TEXT_PRIMARY RGB(0, 255, 65)

#define LACKYVPN_WINDOW_CLASS L"LackyVPNCyberInterface"
#define LACKYVPN_WINDOW_TITLE L"LACKYVPN - OPERATOR TERMINAL v1.0 [CYBERNIGHT]"

// Control IDs
#define ID_CONNECT_BTN      1001
#define ID_DISCONNECT_BTN   1002
#define ID_SETTINGS_BTN     1003
#define ID_DISTRESS_BTN     1004
#define ID_STATUS_LIST      1005

// Template for COM interface release
template<class Interface>
inline void SafeRelease(Interface **ppInterfaceToRelease) {
    if (*ppInterfaceToRelease != NULL) {
        (*ppInterfaceToRelease)->Release();
        (*ppInterfaceToRelease) = NULL;
    }
}

// ========== MAIN INTERFACE CLASS ==========
class CyberInterface {
private:
    HWND m_hWnd;
    HWND m_hConnectBtn;
    HWND m_hDisconnectBtn;
    HWND m_hSettingsBtn;
    HWND m_hDistressBtn;
    HWND m_hStatusList;
    
    ID2D1Factory* m_pD2DFactory;
    ID2D1HwndRenderTarget* m_pRenderTarget;
    ID2D1SolidColorBrush* m_pNeonGreenBrush;
    
    bool m_connected;

public:
    CyberInterface() :
        m_hWnd(nullptr),
        m_hConnectBtn(nullptr),
        m_hDisconnectBtn(nullptr),
        m_hSettingsBtn(nullptr),
        m_hDistressBtn(nullptr),
        m_hStatusList(nullptr),
        m_pD2DFactory(nullptr),
        m_pRenderTarget(nullptr),
        m_pNeonGreenBrush(nullptr),
        m_connected(false)
    {
    }

    ~CyberInterface() {
        Cleanup();
    }

    bool Initialize(HINSTANCE hInstance);
    void Cleanup();
    void CreateControls();
    LRESULT HandleMessage(UINT message, WPARAM wParam, LPARAM lParam);
    void OnPaint();
    void OnCommand(WPARAM wParam);
    
    HWND GetWindow() const { return m_hWnd; }
    bool IsConnected() const { return m_connected; }
};

// Global instance
static CyberInterface* g_pInterface = nullptr;

// ========== IMPLEMENTATION ==========

bool CyberInterface::Initialize(HINSTANCE hInstance) {
    // Register window class
    WNDCLASSEXW wcex = {};
    wcex.cbSize = sizeof(WNDCLASSEXW);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = [](HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) -> LRESULT {
        if (message == WM_CREATE) {
            CREATESTRUCT* pcs = reinterpret_cast<CREATESTRUCT*>(lParam);
            CyberInterface* pInterface = reinterpret_cast<CyberInterface*>(pcs->lpCreateParams);
            SetWindowLongPtrW(hWnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pInterface));
            pInterface->m_hWnd = hWnd;
            return 0;
        }
        
        CyberInterface* pInterface = reinterpret_cast<CyberInterface*>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));
        if (pInterface) {
            return pInterface->HandleMessage(message, wParam, lParam);
        }
        
        return DefWindowProcW(hWnd, message, wParam, lParam);
    };
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_APPLICATION));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = CreateSolidBrush(CYBER_BACKGROUND);
    wcex.lpszMenuName = nullptr;
    wcex.lpszClassName = LACKYVPN_WINDOW_CLASS;
    wcex.hIconSm = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_APPLICATION));

    if (!RegisterClassExW(&wcex)) {
        return false;
    }

    // Create window
    m_hWnd = CreateWindowExW(
        WS_EX_APPWINDOW,
        LACKYVPN_WINDOW_CLASS,
        LACKYVPN_WINDOW_TITLE,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        1200, 800,
        nullptr,
        nullptr,
        hInstance,
        this);

    if (!m_hWnd) {
        return false;
    }

    // Initialize Direct2D
    HRESULT hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &m_pD2DFactory);
    if (FAILED(hr)) return false;

    // Create render target
    RECT rc;
    GetClientRect(m_hWnd, &rc);
    D2D1_SIZE_U size = D2D1::SizeU(rc.right, rc.bottom);

    hr = m_pD2DFactory->CreateHwndRenderTarget(
        D2D1::RenderTargetProperties(),
        D2D1::HwndRenderTargetProperties(m_hWnd, size),
        &m_pRenderTarget);
    if (FAILED(hr)) return false;

    // Create brushes
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 1.0f, 0.25f), &m_pNeonGreenBrush);

    CreateControls();
    return true;
}

void CyberInterface::CreateControls() {
    // Status list
    m_hStatusList = CreateWindowExW(
        WS_EX_CLIENTEDGE,
        L"LISTBOX",
        nullptr,
        WS_CHILD | WS_VISIBLE | WS_VSCROLL,
        20, 100, 400, 300,
        m_hWnd, 
        reinterpret_cast<HMENU>(ID_STATUS_LIST),
        GetModuleHandleW(nullptr), 
        nullptr);

    // Connect button
    m_hConnectBtn = CreateWindowExW(
        0,
        L"BUTTON",
        L"🚀 ESTABLISH SECURE LINK",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        450, 120, 200, 40,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_CONNECT_BTN),
        GetModuleHandleW(nullptr),
        nullptr);

    // Disconnect button
    m_hDisconnectBtn = CreateWindowExW(
        0,
        L"BUTTON", 
        L"🔌 TERMINATE CONNECTION",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        680, 120, 200, 40,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_DISCONNECT_BTN),
        GetModuleHandleW(nullptr),
        nullptr);

    // Settings button
    m_hSettingsBtn = CreateWindowExW(
        0,
        L"BUTTON",
        L"⚙️ OPERATOR CONTROLS",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        450, 180, 200, 40,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_SETTINGS_BTN),
        GetModuleHandleW(nullptr),
        nullptr);

    // Distress button
    m_hDistressBtn = CreateWindowExW(
        0,
        L"BUTTON",
        L"🚨 DISTRESS PROTOCOL",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        680, 180, 200, 40,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_DISTRESS_BTN),
        GetModuleHandleW(nullptr),
        nullptr);
}

LRESULT CyberInterface::HandleMessage(UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_PAINT:
            OnPaint();
            return 0;

        case WM_COMMAND:
            OnCommand(wParam);
            return 0;

        case WM_SIZE:
            if (m_pRenderTarget) {
                RECT rc;
                GetClientRect(m_hWnd, &rc);
                D2D1_SIZE_U size = D2D1::SizeU(rc.right, rc.bottom);
                m_pRenderTarget->Resize(size);
            }
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;

        default:
            return DefWindowProcW(m_hWnd, message, wParam, lParam);
    }
}

void CyberInterface::OnPaint() {
    PAINTSTRUCT ps;
    BeginPaint(m_hWnd, &ps);

    if (m_pRenderTarget) {
        m_pRenderTarget->BeginDraw();
        m_pRenderTarget->Clear(D2D1::ColorF(0.04f, 0.04f, 0.1f));
        
        // Simple status display
        const wchar_t* status = m_connected ? L"🔗 CONNECTED" : L"🔌 DISCONNECTED";
        SendMessageW(m_hStatusList, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(status));
        
        HRESULT hr = m_pRenderTarget->EndDraw();
        if (hr == D2DERR_RECREATE_TARGET) {
            SafeRelease(&m_pRenderTarget);
        }
    }

    EndPaint(m_hWnd, &ps);
}

void CyberInterface::OnCommand(WPARAM wParam) {
    WORD id = LOWORD(wParam);

    switch (id) {
        case ID_CONNECT_BTN:
            m_connected = true;
            SendMessageW(m_hStatusList, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"🚀 VPN CONNECTION ESTABLISHED"));
            InvalidateRect(m_hWnd, nullptr, FALSE);
            break;

        case ID_DISCONNECT_BTN:
            m_connected = false;
            SendMessageW(m_hStatusList, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"🔌 VPN CONNECTION TERMINATED"));
            InvalidateRect(m_hWnd, nullptr, FALSE);
            break;

        case ID_SETTINGS_BTN:
            MessageBoxW(m_hWnd, L"Settings panel will be implemented next", L"Settings", MB_OK);
            break;

        case ID_DISTRESS_BTN:
            MessageBoxW(m_hWnd, L"🚨 DISTRESS PROTOCOL ACTIVATED", L"Emergency Mode", MB_OK | MB_ICONWARNING);
            break;
    }
}

void CyberInterface::Cleanup() {
    SafeRelease(&m_pNeonGreenBrush);
    SafeRelease(&m_pRenderTarget);
    SafeRelease(&m_pD2DFactory);
}

// ========== ENTRY POINT ==========

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(pCmdLine);

    // Initialize COM
    HRESULT hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    if (FAILED(hr)) return -1;

    // Initialize common controls
    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(icex);
    icex.dwICC = ICC_WIN95_CLASSES;
    InitCommonControlsEx(&icex);

    // Create and initialize interface
    CyberInterface interface;
    g_pInterface = &interface;

    if (!interface.Initialize(hInstance)) {
        CoUninitialize();
        return -1;
    }

    // Show window
    ShowWindow(interface.GetWindow(), nCmdShow);
    UpdateWindow(interface.GetWindow());

    // Message loop
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    CoUninitialize();
    return static_cast<int>(msg.wParam);
}
