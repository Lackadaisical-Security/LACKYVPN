/*
 * LACKYVPN - Native Windows GUI Application
 * =========================================
 * 
 * 80s Retro Cyber Tech Theme Windows Application
 * Professional operator-class interface with full feature support
 * 
 * Security Level: CLASSIFIED
 * Built by: Lackadaisical Security
 */

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <richedit.h>
#include <d2d1.h>
#include <dwrite.h>
#include <wincodec.h>
#include <shellapi.h>
#include <shlobj.h>
#include <string>
#include <vector>
#include <memory>
#include <thread>
#include <mutex>
#include <chrono>
#include "resource.h"

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "shell32.lib")

// Include LACKYVPN core modules
extern "C" {
    #include "../core/integration/system_integration.h"
    #include "../core/distress/distress_mode.h"
    #include "../core/monitoring/system_monitoring.h"
    #include "../core/encryption/encryption_engine.h"
}

//=============================================================================
// 80s RETRO CYBER CONSTANTS AND COLORS
//=============================================================================

// Neon color scheme
#define CYBER_BLACK         RGB(0, 0, 0)
#define CYBER_NEON_GREEN    RGB(0, 255, 41)
#define CYBER_NEON_BLUE     RGB(0, 191, 255)
#define CYBER_NEON_PINK     RGB(255, 20, 147)
#define CYBER_NEON_ORANGE   RGB(255, 165, 0)
#define CYBER_DARK_BLUE     RGB(0, 20, 40)
#define CYBER_DARK_GREEN    RGB(0, 40, 20)
#define CYBER_GRID_COLOR    RGB(0, 100, 100)

// Window dimensions
#define MAIN_WINDOW_WIDTH   1200
#define MAIN_WINDOW_HEIGHT  800
#define MIN_WINDOW_WIDTH    800
#define MIN_WINDOW_HEIGHT   600

// Control IDs
#define ID_CONNECT_BTN      1001
#define ID_DISCONNECT_BTN   1002
#define ID_SETTINGS_BTN     1003
#define ID_DISTRESS_BTN     1004
#define ID_STATUS_LIST      1005
#define ID_SERVER_COMBO     1006
#define ID_MODE_COMBO       1007
#define ID_ENCRYPTION_COMBO 1008
#define ID_MONITOR_TAB      1009
#define ID_TIMER_UPDATE     1010

// Animation timer IDs
#define TIMER_ANIMATION     2001
#define TIMER_STATUS_UPDATE 2002
#define TIMER_GRID_ANIM     2003

//=============================================================================
// FORWARD DECLARATIONS
//=============================================================================

class CyberInterface;
class StatusMonitor;
class SettingsPanel;
class DistressController;

//=============================================================================
// CYBER INTERFACE MAIN CLASS
//=============================================================================

class CyberInterface {
private:
    HWND m_hwnd;
    HWND m_hStatusList;
    HWND m_hServerCombo;
    HWND m_hModeCombo;
    HWND m_hEncryptionCombo;
    HWND m_hConnectBtn;
    HWND m_hDisconnectBtn;
    HWND m_hSettingsBtn;
    HWND m_hDistressBtn;
    
    // Direct2D resources
    ID2D1Factory* m_pD2DFactory;
    ID2D1HwndRenderTarget* m_pRenderTarget;
    ID2D1SolidColorBrush* m_pNeonGreenBrush;
    ID2D1SolidColorBrush* m_pNeonBlueBrush;
    ID2D1SolidColorBrush* m_pNeonPinkBrush;
    ID2D1SolidColorBrush* m_pBlackBrush;
    ID2D1SolidColorBrush* m_pGridBrush;
    
    // DirectWrite resources
    IDWriteFactory* m_pDWriteFactory;
    IDWriteTextFormat* m_pMonospaceFormat;
    IDWriteTextFormat* m_pTitleFormat;
    
    // Animation state
    DWORD m_animationTick;
    float m_gridOffset;
    bool m_isConnected;
    bool m_distressActive;
    
    // Core system integration
    lackyvpn_system_t* m_pSystem;
    system_monitor_t* m_pMonitor;
    distress_context_t* m_pDistress;
    
    std::mutex m_statusMutex;
    std::vector<std::wstring> m_statusLog;
    
    // Core initialization methods
    void CreateControls();
    void InitializeLackyVPN();
    void UpdateConnectionStatus();
    void UpdateMetrics();
    
    // Make distress status public so it can be accessed
public:
    bool m_distressActive;
    CyberInterface() :
        m_hwnd(nullptr),
        m_hStatusList(nullptr),
        m_pD2DFactory(nullptr),
        m_pRenderTarget(nullptr),
        m_pNeonGreenBrush(nullptr),
        m_pNeonBlueBrush(nullptr),
        m_pNeonPinkBrush(nullptr),
        m_pBlackBrush(nullptr),
        m_pGridBrush(nullptr),
        m_pDWriteFactory(nullptr),
        m_pMonospaceFormat(nullptr),
        m_pTitleFormat(nullptr),
        m_animationTick(0),
        m_gridOffset(0.0f),
        m_isConnected(false),
        m_distressActive(false),
        m_pSystem(nullptr),
        m_pMonitor(nullptr),
        m_pDistress(nullptr)
    {
    }
    
    ~CyberInterface() {
        Cleanup();
    }
    
    HRESULT Initialize(HWND hwnd);
    void Cleanup();
    void OnPaint();
    void OnResize(UINT width, UINT height);
    void OnCommand(WPARAM wParam, LPARAM lParam);
    void OnTimer(WPARAM wParam);
    void UpdateStatus();
    void AddStatusMessage(const std::wstring& message, COLORREF color = CYBER_NEON_GREEN);
    
    // VPN control functions
    void ConnectVPN();
    void DisconnectVPN();
    void ShowSettings();
    void ActivateDistress();
    
    // Drawing functions
    void DrawCyberGrid();
    void DrawNeonBorder();
    void DrawStatusIndicators();
    void DrawMatrixRain();
    void DrawSystemMetrics();
};

//=============================================================================
// WINDOW PROCEDURE
//=============================================================================

LRESULT CALLBACK MainWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    CyberInterface* pInterface = reinterpret_cast<CyberInterface*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
    
    switch (msg) {
        case WM_CREATE: {
            CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
            pInterface = reinterpret_cast<CyberInterface*>(pCreate->lpCreateParams);
            SetWindowLongPtr(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pInterface));
            
            if (pInterface) {
                pInterface->Initialize(hwnd);
            }
            return 0;
        }
        
        case WM_PAINT:
            if (pInterface) {
                pInterface->OnPaint();
            }
            return 0;
            
        case WM_SIZE:
            if (pInterface) {
                pInterface->OnResize(LOWORD(lParam), HIWORD(lParam));
            }
            return 0;
            
        case WM_COMMAND:
            if (pInterface) {
                pInterface->OnCommand(wParam, lParam);
            }
            return 0;
            
        case WM_TIMER:
            if (pInterface) {
                pInterface->OnTimer(wParam);
            }
            return 0;
            
        case WM_GETMINMAXINFO: {
            MINMAXINFO* pInfo = reinterpret_cast<MINMAXINFO*>(lParam);
            pInfo->ptMinTrackSize.x = MIN_WINDOW_WIDTH;
            pInfo->ptMinTrackSize.y = MIN_WINDOW_HEIGHT;
            return 0;
        }
        
        case WM_CLOSE:
            if (pInterface && pInterface->m_distressActive) {
                // In distress mode, hide window instead of closing
                ShowWindow(hwnd, SW_HIDE);
                return 0;
            }
            break;
            
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    
    return DefWindowProc(hwnd, msg, wParam, lParam);
}

//=============================================================================
// CYBER INTERFACE IMPLEMENTATION
//=============================================================================

HRESULT CyberInterface::Initialize(HWND hwnd) {
    m_hwnd = hwnd;
    HRESULT hr = S_OK;
    
    // Initialize Direct2D
    hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &m_pD2DFactory);
    if (FAILED(hr)) return hr;
    
    // Initialize DirectWrite
    hr = DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(m_pDWriteFactory),
                            reinterpret_cast<IUnknown**>(&m_pDWriteFactory));
    if (FAILED(hr)) return hr;
    
    // Create render target
    RECT rc;
    GetClientRect(hwnd, &rc);
    
    D2D1_SIZE_U size = D2D1::SizeU(rc.right, rc.bottom);
    hr = m_pD2DFactory->CreateHwndRenderTarget(
        D2D1::RenderTargetProperties(),
        D2D1::HwndRenderTargetProperties(hwnd, size),
        &m_pRenderTarget);
    if (FAILED(hr)) return hr;
    
    // Create brushes
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 1.0f, 0.16f, 1.0f), &m_pNeonGreenBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.75f, 1.0f, 1.0f), &m_pNeonBlueBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.08f, 0.58f, 1.0f), &m_pNeonPinkBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f), &m_pBlackBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.4f, 0.4f, 0.3f), &m_pGridBrush);
    
    // Create text formats
    m_pDWriteFactory->CreateTextFormat(
        L"Consolas", nullptr, DWRITE_FONT_WEIGHT_BOLD, DWRITE_FONT_STYLE_NORMAL,
        DWRITE_FONT_STRETCH_NORMAL, 12.0f, L"", &m_pMonospaceFormat);
    
    m_pDWriteFactory->CreateTextFormat(
        L"Orbitron", nullptr, DWRITE_FONT_WEIGHT_BOLD, DWRITE_FONT_STYLE_NORMAL,
        DWRITE_FONT_STRETCH_NORMAL, 24.0f, L"", &m_pTitleFormat);
    
    // Create controls
    CreateControls();
    
    // Initialize LACKYVPN systems
    InitializeLackyVPN();
    
    // Start timers
    SetTimer(hwnd, TIMER_ANIMATION, 50, nullptr);      // 20 FPS animation
    SetTimer(hwnd, TIMER_STATUS_UPDATE, 1000, nullptr); // 1 second status updates
    SetTimer(hwnd, TIMER_GRID_ANIM, 100, nullptr);     // Grid animation
    
    return hr;
}

void CyberInterface::CreateControls() {
    // Status list (terminal-style output)
    m_hStatusList = CreateWindowEx(
        WS_EX_CLIENTEDGE,
        WC_LISTBOX,
        nullptr,
        WS_CHILD | WS_VISIBLE | WS_VSCROLL | LBS_NOINTEGRALHEIGHT | LBS_OWNERDRAWFIXED,
        20, 100, 400, 300,
        m_hwnd, (HMENU)ID_STATUS_LIST, GetModuleHandle(nullptr), nullptr);
    
    // Server selection combo
    m_hServerCombo = CreateWindowEx(
        0, WC_COMBOBOX, nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        450, 120, 200, 200,
        m_hwnd, (HMENU)ID_SERVER_COMBO, GetModuleHandle(nullptr), nullptr);
    
    // Populate server list
    SendMessage(m_hServerCombo, CB_ADDSTRING, 0, (LPARAM)L"🌐 AUTO SELECT (SECURE)");
    SendMessage(m_hServerCombo, CB_ADDSTRING, 0, (LPARAM)L"🇺🇸 USA - GHOST NODE");
    SendMessage(m_hServerCombo, CB_ADDSTRING, 0, (LPARAM)L"🇩🇪 GERMANY - QUANTUM");
    SendMessage(m_hServerCombo, CB_ADDSTRING, 0, (LPARAM)L"🇯🇵 JAPAN - STEALTH");
    SendMessage(m_hServerCombo, CB_ADDSTRING, 0, (LPARAM)L"🇨🇭 SWITZERLAND - VAULT");
    SendMessage(m_hServerCombo, CB_SETCURSEL, 0, 0);
    
    // Mode selection combo
    m_hModeCombo = CreateWindowEx(
        0, WC_COMBOBOX, nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        680, 120, 180, 200,
        m_hwnd, (HMENU)ID_MODE_COMBO, GetModuleHandle(nullptr), nullptr);
    
    SendMessage(m_hModeCombo, CB_ADDSTRING, 0, (LPARAM)L"🔒 OPERATOR MODE");
    SendMessage(m_hModeCombo, CB_ADDSTRING, 0, (LPARAM)L"👻 GHOST MODE");
    SendMessage(m_hModeCombo, CB_ADDSTRING, 0, (LPARAM)L"⚡ QUANTUM MODE");
    SendMessage(m_hModeCombo, CB_ADDSTRING, 0, (LPARAM)L"🛡️ FORTRESS MODE");
    SendMessage(m_hModeCombo, CB_SETCURSEL, 0, 0);
    
    // Encryption level combo
    m_hEncryptionCombo = CreateWindowEx(
        0, WC_COMBOBOX, nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        880, 120, 200, 200,
        m_hwnd, (HMENU)ID_ENCRYPTION_COMBO, GetModuleHandle(nullptr), nullptr);
    
    SendMessage(m_hEncryptionCombo, CB_ADDSTRING, 0, (LPARAM)L"🔐 10-LAYER QUANTUM");
    SendMessage(m_hEncryptionCombo, CB_ADDSTRING, 0, (LPARAM)L"🔥 FIRE SEAL PROTOCOL");
    SendMessage(m_hEncryptionCombo, CB_ADDSTRING, 0, (LPARAM)L"⚛️ POST-QUANTUM SAFE");
    SendMessage(m_hEncryptionCombo, CB_ADDSTRING, 0, (LPARAM)L"🌊 METAMORPHIC CIPHER");
    SendMessage(m_hEncryptionCombo, CB_SETCURSEL, 0, 0);
    
    // Connect button
    m_hConnectBtn = CreateWindowEx(
        0, WC_BUTTON, L"🚀 INITIATE CONNECTION",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
        450, 180, 200, 50,
        m_hwnd, (HMENU)ID_CONNECT_BTN, GetModuleHandle(nullptr), nullptr);
    
    // Disconnect button
    m_hDisconnectBtn = CreateWindowEx(
        0, WC_BUTTON, L"🔌 TERMINATE LINK",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
        680, 180, 200, 50,
        m_hwnd, (HMENU)ID_DISCONNECT_BTN, GetModuleHandle(nullptr), nullptr);
    
    // Settings button
    m_hSettingsBtn = CreateWindowEx(
        0, WC_BUTTON, L"⚙️ OPERATOR CONTROLS",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
        450, 250, 200, 40,
        m_hwnd, (HMENU)ID_SETTINGS_BTN, GetModuleHandle(nullptr), nullptr);
    
    // Emergency distress button
    m_hDistressBtn = CreateWindowEx(
        0, WC_BUTTON, L"🚨 DISTRESS PROTOCOL",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW,
        680, 250, 200, 40,
        m_hwnd, (HMENU)ID_DISTRESS_BTN, GetModuleHandle(nullptr), nullptr);
    
    // Set custom font for controls
    HFONT hFont = CreateFont(
        14, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");
    
    SendMessage(m_hStatusList, WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(m_hServerCombo, WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(m_hModeCombo, WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(m_hEncryptionCombo, WM_SETFONT, (WPARAM)hFont, TRUE);
}

void CyberInterface::InitializeLackyVPN() {
    // Initialize LACKYVPN core systems
    m_pSystem = (lackyvpn_system_t*)malloc(sizeof(lackyvpn_system_t));
    if (m_pSystem) {        lackyvpn_config_t config;
        memset(&config, 0, sizeof(config));
        config.default_mode = LACKYVPN_MODE_NORMAL;
        config.default_mode = LACKYVPN_MODE_OPERATOR;
        config.encryption_layers = 10;
        config.enable_quantum_crypto = true;
        config.enable_steganography = true;
        config.enable_anti_forensics = true;
        
        if (lackyvpn_initialize(m_pSystem, &config) == 0) {
            AddStatusMessage(L"🔥 LACKYVPN CORE INITIALIZED", CYBER_NEON_GREEN);
            AddStatusMessage(L"📡 QUANTUM ENCRYPTION ACTIVE", CYBER_NEON_BLUE);
            AddStatusMessage(L"🛡️ FIRE SEAL PROTOCOL LOADED", CYBER_NEON_PINK);
        } else {
            AddStatusMessage(L"❌ CORE INITIALIZATION FAILED", RGB(255, 0, 0));
        }
    }
    
    // Initialize monitoring
    m_pMonitor = (system_monitor_t*)malloc(sizeof(system_monitor_t));
    if (m_pMonitor) {
        system_monitor_config_t monitor_config = {0};
        monitor_config.enable_threat_detection = true;
        monitor_config.enable_behavior_analysis = true;
        monitor_config.enable_network_monitoring = true;
        
        if (init_system_monitor(m_pMonitor, &monitor_config) == 0) {
            AddStatusMessage(L"🕵️ THREAT MONITORING ONLINE", CYBER_NEON_GREEN);
        }
    }
    
    // Initialize distress mode
    m_pDistress = (distress_mode_t*)malloc(sizeof(distress_mode_t));
    if (m_pDistress) {
        if (init_distress_mode(m_pDistress)) {
            AddStatusMessage(L"🚨 DISTRESS PROTOCOLS ARMED", CYBER_NEON_ORANGE);
        }
    }
}

void CyberInterface::OnPaint() {
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(m_hwnd, &ps);
    
    if (m_pRenderTarget) {
        m_pRenderTarget->BeginDraw();
        
        // Clear background to cyber black
        m_pRenderTarget->Clear(D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f));
        
        // Draw cyber grid background
        DrawCyberGrid();
        
        // Draw neon borders
        DrawNeonBorder();
        
        // Draw title
        if (m_pTitleFormat) {
            D2D1_RECT_F titleRect = D2D1::RectF(20, 20, 800, 60);
            m_pRenderTarget->DrawTextW(
                L"🌐 LACKYVPN - OPERATOR INTERFACE 🌐",
                wcslen(L"🌐 LACKYVPN - OPERATOR INTERFACE 🌐"),
                m_pTitleFormat,
                titleRect,
                m_pNeonGreenBrush);
        }
        
        // Draw subtitle
        if (m_pMonospaceFormat) {
            D2D1_RECT_F subtitleRect = D2D1::RectF(20, 65, 800, 85);
            m_pRenderTarget->DrawTextW(
                L"\"Sealed with 10-layer fire\" - Classification: OPERATOR USE ONLY",
                wcslen(L"\"Sealed with 10-layer fire\" - Classification: OPERATOR USE ONLY"),
                m_pMonospaceFormat,
                subtitleRect,
                m_pNeonBlueBrush);
        }
        
        // Draw status indicators
        DrawStatusIndicators();
        
        // Draw system metrics
        DrawSystemMetrics();
        
        // Draw matrix rain effect
        DrawMatrixRain();
        
        HRESULT hr = m_pRenderTarget->EndDraw();
        if (hr == D2DERR_RECREATE_TARGET) {
            // Need to recreate render target
            m_pRenderTarget->Release();
            m_pRenderTarget = nullptr;
            // Will be recreated on next paint
        }
    }
    
    EndPaint(m_hwnd, &ps);
}

void CyberInterface::DrawCyberGrid() {
    if (!m_pGridBrush) return;
    
    RECT clientRect;
    GetClientRect(m_hwnd, &clientRect);
    
    float width = static_cast<float>(clientRect.right);
    float height = static_cast<float>(clientRect.bottom);
    
    // Animated grid offset
    float offset = m_gridOffset;
    
    // Draw vertical lines
    for (float x = offset; x < width; x += 40.0f) {
        m_pRenderTarget->DrawLine(
            D2D1::Point2F(x, 0),
            D2D1::Point2F(x, height),
            m_pGridBrush,
            1.0f);
    }
    
    // Draw horizontal lines
    for (float y = offset; y < height; y += 40.0f) {
        m_pRenderTarget->DrawLine(
            D2D1::Point2F(0, y),
            D2D1::Point2F(width, y),
            m_pGridBrush,
            1.0f);
    }
}

void CyberInterface::DrawNeonBorder() {
    RECT clientRect;
    GetClientRect(m_hwnd, &clientRect);
    
    float width = static_cast<float>(clientRect.right);
    float height = static_cast<float>(clientRect.bottom);
    
    // Animated glow effect
    float glowIntensity = 0.5f + 0.5f * sin(m_animationTick * 0.01f);
    
    // Create glowing border
    D2D1_RECT_F borderRect = D2D1::RectF(5, 5, width - 5, height - 5);
    
    ID2D1SolidColorBrush* glowBrush = nullptr;
    m_pRenderTarget->CreateSolidColorBrush(
        D2D1::ColorF(0.0f, 1.0f, 0.16f, glowIntensity),
        &glowBrush);
    
    if (glowBrush) {
        m_pRenderTarget->DrawRectangle(borderRect, glowBrush, 3.0f);
        glowBrush->Release();
    }
}

void CyberInterface::DrawStatusIndicators() {
    // Connection status indicator
    D2D1_ELLIPSE connectionIndicator = D2D1::Ellipse(D2D1::Point2F(950, 50), 15, 15);
    
    if (m_isConnected) {
        m_pRenderTarget->FillEllipse(connectionIndicator, m_pNeonGreenBrush);
        
        if (m_pMonospaceFormat) {
            D2D1_RECT_F statusText = D2D1::RectF(980, 35, 1150, 65);
            m_pRenderTarget->DrawTextW(
                L"🔗 CONNECTED SECURE",
                wcslen(L"🔗 CONNECTED SECURE"),
                m_pMonospaceFormat,
                statusText,
                m_pNeonGreenBrush);
        }
    } else {
        m_pRenderTarget->FillEllipse(connectionIndicator, m_pNeonPinkBrush);
        
        if (m_pMonospaceFormat) {
            D2D1_RECT_F statusText = D2D1::RectF(980, 35, 1150, 65);
            m_pRenderTarget->DrawTextW(
                L"🔌 DISCONNECTED",
                wcslen(L"🔌 DISCONNECTED"),
                m_pMonospaceFormat,
                statusText,
                m_pNeonPinkBrush);
        }
    }
    
    // Distress mode indicator
    if (m_distressActive) {
        D2D1_ELLIPSE distressIndicator = D2D1::Ellipse(D2D1::Point2F(950, 80), 10, 10);
        m_pRenderTarget->FillEllipse(distressIndicator, m_pNeonPinkBrush);
        
        if (m_pMonospaceFormat) {
            D2D1_RECT_F distressText = D2D1::RectF(980, 70, 1150, 90);
            m_pRenderTarget->DrawTextW(
                L"🚨 DISTRESS ACTIVE",
                wcslen(L"🚨 DISTRESS ACTIVE"),
                m_pMonospaceFormat,
                distressText,
                m_pNeonPinkBrush);
        }
    }
}

void CyberInterface::DrawMatrixRain() {
    // Simple matrix rain effect in corner
    static std::vector<float> rainPositions(20, 0.0f);
    static std::vector<wchar_t> rainChars(20);
    
    // Initialize chars if needed
    static bool initialized = false;
    if (!initialized) {
        for (size_t i = 0; i < rainChars.size(); ++i) {
            rainChars[i] = L'0' + (rand() % 10);
        }
        initialized = true;
    }
    
    // Update positions
    for (size_t i = 0; i < rainPositions.size(); ++i) {
        rainPositions[i] += 2.0f;
        if (rainPositions[i] > 400) {
            rainPositions[i] = 0;
            rainChars[i] = L'0' + (rand() % 10);
        }
    }
    
    // Draw rain
    if (m_pMonospaceFormat) {
        for (size_t i = 0; i < rainPositions.size(); ++i) {
            float x = 30.0f + i * 15.0f;
            float y = 420.0f + rainPositions[i];
            
            D2D1_RECT_F charRect = D2D1::RectF(x, y, x + 12, y + 16);
            
            wchar_t charStr[2] = {rainChars[i], 0};
            m_pRenderTarget->DrawTextW(
                charStr, 1,
                m_pMonospaceFormat,
                charRect,
                m_pNeonGreenBrush);
        }
    }
}

void CyberInterface::DrawSystemMetrics() {
    if (!m_pSystem || !m_pMonospaceFormat) return;
    
    // Get system metrics
    MEMORYSTATUSEX memStatus = {0};
    memStatus.dwLength = sizeof(memStatus);
    GlobalMemoryStatusEx(&memStatus);
    
    SYSTEM_INFO sysInfo;
    GetSystemInfo(&sysInfo);
    
    // Draw metrics panel
    D2D1_RECT_F metricsPanel = D2D1::RectF(450, 320, 900, 500);
    m_pRenderTarget->DrawRectangle(metricsPanel, m_pNeonBlueBrush, 2.0f);
    
    // Metrics title
    D2D1_RECT_F titleRect = D2D1::RectF(460, 330, 890, 350);
    m_pRenderTarget->DrawTextW(
        L"🖥️ SYSTEM METRICS",
        wcslen(L"🖥️ SYSTEM METRICS"),
        m_pMonospaceFormat,
        titleRect,
        m_pNeonBlueBrush);
    
    // Memory usage
    wchar_t memText[256];
    swprintf_s(memText, L"RAM: %llu MB / %llu MB (%d%%)",
              (memStatus.ullTotalPhys - memStatus.ullAvailPhys) / 1024 / 1024,
              memStatus.ullTotalPhys / 1024 / 1024,
              (int)memStatus.dwMemoryLoad);
    
    D2D1_RECT_F memRect = D2D1::RectF(460, 360, 890, 380);
    m_pRenderTarget->DrawTextW(memText, wcslen(memText), m_pMonospaceFormat, memRect, m_pNeonGreenBrush);
    
    // CPU info
    wchar_t cpuText[256];
    swprintf_s(cpuText, L"CPU: %d cores detected", sysInfo.dwNumberOfProcessors);
    
    D2D1_RECT_F cpuRect = D2D1::RectF(460, 380, 890, 400);
    m_pRenderTarget->DrawTextW(cpuText, wcslen(cpuText), m_pMonospaceFormat, cpuRect, m_pNeonGreenBrush);
    
    // VPN status
    const wchar_t* vpnStatus = m_isConnected ? L"VPN: CONNECTED - QUANTUM TUNNEL ACTIVE" : L"VPN: DISCONNECTED - STANDBY MODE";
    D2D1_RECT_F vpnRect = D2D1::RectF(460, 400, 890, 420);
    m_pRenderTarget->DrawTextW(vpnStatus, wcslen(vpnStatus), m_pMonospaceFormat, vpnRect,
                              m_isConnected ? m_pNeonGreenBrush : m_pNeonPinkBrush);
    
    // Encryption status
    D2D1_RECT_F encRect = D2D1::RectF(460, 420, 890, 440);
    m_pRenderTarget->DrawTextW(
        L"ENCRYPTION: 10-LAYER FIRE SEAL ACTIVE",
        wcslen(L"ENCRYPTION: 10-LAYER FIRE SEAL ACTIVE"),
        m_pMonospaceFormat, encRect, m_pNeonBlueBrush);
    
    // Threat level
    const wchar_t* threatLevel = m_distressActive ? L"THREAT: DISTRESS MODE ACTIVE" : L"THREAT: ALL SYSTEMS NOMINAL";
    D2D1_RECT_F threatRect = D2D1::RectF(460, 440, 890, 460);
    m_pRenderTarget->DrawTextW(threatLevel, wcslen(threatLevel), m_pMonospaceFormat, threatRect,
                              m_distressActive ? m_pNeonPinkBrush : m_pNeonGreenBrush);
}

void CyberInterface::OnCommand(WPARAM wParam, LPARAM lParam) {
    WORD id = LOWORD(wParam);
    
    switch (id) {
        case ID_CONNECT_BTN:
            ConnectVPN();
            break;
            
        case ID_DISCONNECT_BTN:
            DisconnectVPN();
            break;
            
        case ID_SETTINGS_BTN:
            ShowSettings();
            break;
            
        case ID_DISTRESS_BTN:
            ActivateDistress();
            break;
    }
}

void CyberInterface::ConnectVPN() {
    if (m_isConnected) return;
    
    AddStatusMessage(L"🚀 INITIATING VPN CONNECTION...", CYBER_NEON_BLUE);
    
    if (m_pSystem) {
        lackyvpn_result_t result = lackyvpn_connect(m_pSystem);
        if (result == LACKYVPN_SUCCESS) {
            m_isConnected = true;
            AddStatusMessage(L"🔗 CONNECTION ESTABLISHED", CYBER_NEON_GREEN);
            AddStatusMessage(L"🔥 FIRE SEAL PROTOCOL ACTIVE", CYBER_NEON_GREEN);
            AddStatusMessage(L"⚡ QUANTUM ENCRYPTION ONLINE", CYBER_NEON_BLUE);
            AddStatusMessage(L"👻 GHOST MODE ENGAGED", CYBER_NEON_PINK);
        } else {
            AddStatusMessage(L"❌ CONNECTION FAILED", RGB(255, 0, 0));
        }
    } else {
        AddStatusMessage(L"❌ SYSTEM NOT INITIALIZED", RGB(255, 0, 0));
    }
    
    InvalidateRect(m_hwnd, nullptr, FALSE);
}

void CyberInterface::DisconnectVPN() {
    if (!m_isConnected) return;
    
    AddStatusMessage(L"🔌 TERMINATING VPN CONNECTION...", CYBER_NEON_ORANGE);
    
    if (m_pSystem) {
        lackyvpn_result_t result = lackyvpn_disconnect(m_pSystem);
        if (result == LACKYVPN_SUCCESS) {
            m_isConnected = false;
            AddStatusMessage(L"🔌 CONNECTION TERMINATED", CYBER_NEON_ORANGE);
            AddStatusMessage(L"🛡️ SECURE SHUTDOWN COMPLETE", CYBER_NEON_GREEN);
        } else {
            AddStatusMessage(L"⚠️ DISCONNECT ERROR", RGB(255, 165, 0));
        }
    }
    
    InvalidateRect(m_hwnd, nullptr, FALSE);
}

void CyberInterface::ShowSettings() {
    AddStatusMessage(L"⚙️ OPENING OPERATOR CONTROLS...", CYBER_NEON_BLUE);
    
    // Create settings dialog
    MessageBox(m_hwnd, 
              L"LACKYVPN Operator Settings\n\n"
              L"🔐 Encryption: 10-Layer Fire Seal\n"
              L"👻 Ghost Mode: ACTIVE\n"
              L"⚡ Quantum Protocols: ENABLED\n"
              L"🛡️ Anti-Forensics: ENABLED\n"
              L"🚨 Distress Mode: ARMED\n\n"
              L"All systems operating at maximum security.",
              L"Operator Controls - CLASSIFIED",
              MB_OK | MB_ICONINFORMATION);
}

void CyberInterface::ActivateDistress() {
    int result = MessageBox(m_hwnd,
                           L"⚠️ WARNING: DISTRESS PROTOCOL ACTIVATION ⚠️\n\n"
                           L"This will:\n"
                           L"• Activate emergency UI camouflage\n"
                           L"• Begin evidence destruction protocols\n"
                           L"• Enable maximum stealth mode\n"
                           L"• Trigger emergency procedures\n\n"
                           L"Are you sure you want to proceed?",
                           L"🚨 DISTRESS PROTOCOL - AUTHORIZATION REQUIRED",
                           MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2);
    
    if (result == IDYES) {
        m_distressActive = true;
        AddStatusMessage(L"🚨 DISTRESS PROTOCOL ACTIVATED", RGB(255, 0, 0));
        AddStatusMessage(L"🎭 UI CAMOUFLAGE ENGAGED", CYBER_NEON_ORANGE);
        AddStatusMessage(L"🔥 EVIDENCE DESTRUCTION INITIATED", CYBER_NEON_PINK);
        
        if (m_pDistress) {
            activate_ui_camouflage(m_pDistress);
        }
        
        InvalidateRect(m_hwnd, nullptr, FALSE);
    }
}

void CyberInterface::OnTimer(WPARAM wParam) {
    switch (wParam) {
        case TIMER_ANIMATION:
            m_animationTick++;
            InvalidateRect(m_hwnd, nullptr, FALSE);
            break;
            
        case TIMER_STATUS_UPDATE:
            UpdateStatus();
            break;
            
        case TIMER_GRID_ANIM:
            m_gridOffset += 0.5f;
            if (m_gridOffset > 40.0f) m_gridOffset = 0.0f;
            break;
    }
}

void CyberInterface::UpdateStatus() {
    if (!m_pSystem || !m_pMonitor) return;
    
    // Update system health
    lackyvpn_health_t health = lackyvpn_health_check(m_pSystem);
    
    static lackyvpn_health_t lastHealth = LACKYVPN_HEALTH_UNKNOWN;
    if (health != lastHealth) {
        switch (health) {
            case LACKYVPN_HEALTH_EXCELLENT:
                AddStatusMessage(L"💚 SYSTEM HEALTH: EXCELLENT", CYBER_NEON_GREEN);
                break;
            case LACKYVPN_HEALTH_GOOD:
                AddStatusMessage(L"🟢 SYSTEM HEALTH: GOOD", CYBER_NEON_GREEN);
                break;
            case LACKYVPN_HEALTH_WARNING:
                AddStatusMessage(L"🟡 SYSTEM HEALTH: WARNING", RGB(255, 255, 0));
                break;
            case LACKYVPN_HEALTH_CRITICAL:
                AddStatusMessage(L"🔴 SYSTEM HEALTH: CRITICAL", RGB(255, 0, 0));
                break;
            case LACKYVPN_HEALTH_EMERGENCY:
                AddStatusMessage(L"🚨 EMERGENCY PROTOCOLS TRIGGERED", RGB(255, 0, 0));
                if (!m_distressActive) {
                    ActivateDistress();
                }
                break;
        }
        lastHealth = health;
    }
}

void CyberInterface::AddStatusMessage(const std::wstring& message, COLORREF color) {
    std::lock_guard<std::mutex> lock(m_statusMutex);
    
    // Add timestamp
    SYSTEMTIME st;
    GetLocalTime(&st);
    
    wchar_t timestampedMessage[512];
    swprintf_s(timestampedMessage, L"[%02d:%02d:%02d] %s",
              st.wHour, st.wMinute, st.wSecond, message.c_str());
    
    m_statusLog.push_back(timestampedMessage);
    
    // Limit log size
    if (m_statusLog.size() > 100) {
        m_statusLog.erase(m_statusLog.begin());
    }
    
    // Add to listbox
    if (m_hStatusList) {
        int index = SendMessage(m_hStatusList, LB_ADDSTRING, 0, (LPARAM)timestampedMessage);
        SendMessage(m_hStatusList, LB_SETTOPINDEX, index, 0);
    }
}

void CyberInterface::OnResize(UINT width, UINT height) {
    if (m_pRenderTarget) {
        D2D1_SIZE_U size = D2D1::SizeU(width, height);
        m_pRenderTarget->Resize(size);
    }
    
    // Resize controls
    if (m_hStatusList) {
        MoveWindow(m_hStatusList, 20, 100, 400, height - 150, TRUE);
    }
}

void CyberInterface::Cleanup() {
    // Release Direct2D resources
    if (m_pNeonGreenBrush) { m_pNeonGreenBrush->Release(); m_pNeonGreenBrush = nullptr; }
    if (m_pNeonBlueBrush) { m_pNeonBlueBrush->Release(); m_pNeonBlueBrush = nullptr; }
    if (m_pNeonPinkBrush) { m_pNeonPinkBrush->Release(); m_pNeonPinkBrush = nullptr; }
    if (m_pBlackBrush) { m_pBlackBrush->Release(); m_pBlackBrush = nullptr; }
    if (m_pGridBrush) { m_pGridBrush->Release(); m_pGridBrush = nullptr; }
    if (m_pRenderTarget) { m_pRenderTarget->Release(); m_pRenderTarget = nullptr; }
    if (m_pD2DFactory) { m_pD2DFactory->Release(); m_pD2DFactory = nullptr; }
    
    // Release DirectWrite resources
    if (m_pMonospaceFormat) { m_pMonospaceFormat->Release(); m_pMonospaceFormat = nullptr; }
    if (m_pTitleFormat) { m_pTitleFormat->Release(); m_pTitleFormat = nullptr; }
    if (m_pDWriteFactory) { m_pDWriteFactory->Release(); m_pDWriteFactory = nullptr; }
    
    // Cleanup LACKYVPN systems
    if (m_pSystem) {
        lackyvpn_shutdown(m_pSystem);
        free(m_pSystem);
        m_pSystem = nullptr;
    }
    
    if (m_pMonitor) {
        cleanup_system_monitor(m_pMonitor);
        free(m_pMonitor);
        m_pMonitor = nullptr;
    }
    
    if (m_pDistress) {
        cleanup_distress_mode(m_pDistress);
        free(m_pDistress);
        m_pDistress = nullptr;
    }
}

//=============================================================================
// APPLICATION ENTRY POINT
//=============================================================================

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);
    
    // Initialize COM for Direct2D
    HRESULT hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    if (FAILED(hr)) return -1;
    
    // Initialize common controls
    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(icex);
    icex.dwICC = ICC_WIN95_CLASSES;
    InitCommonControlsEx(&icex);
    
    // Register window class
    WNDCLASSEX wcex = {0};
    wcex.cbSize = sizeof(wcex);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = MainWindowProc;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszClassName = L"LackyVPNMainWindow";
    wcex.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
    
    if (!RegisterClassEx(&wcex)) {
        return -1;
    }
    
    // Create main window
    CyberInterface interface;
    
    HWND hwnd = CreateWindowEx(
        WS_EX_APPWINDOW,
        L"LackyVPNMainWindow",
        L"LACKYVPN - Operator Interface [CLASSIFIED]",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        MAIN_WINDOW_WIDTH, MAIN_WINDOW_HEIGHT,
        nullptr, nullptr, hInstance, &interface);
    
    if (!hwnd) {
        return -1;
    }
    
    // Show window with cyber effect
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
    
    // Message loop
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    
    CoUninitialize();
    return static_cast<int>(msg.wParam);
}
