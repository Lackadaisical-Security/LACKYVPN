/**
 * LACKYVPN - Native Windows GUI Application
 * Zero-dependency operator-class privacy framework
 * 80s Retro-Cyber Security Theme
 */

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <d2d1.h>
#include <dwrite.h>
#include <commdlg.h>
#include <shellapi.h>
#include <wininet.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <wtsapi32.h>
#include <vector>

// LACKYVPN Core Integration
extern "C" {
    #include "../core/distress/distress_mode.h" 
    #include "../core/monitoring/system_monitoring.h"
    #include "../core/integration/system_integration.h"
}

#include "resource.h"
#include "monitoring.h"

#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "wtsapi32.lib")

// ========== 80s CYBER THEME CONSTANTS ==========
#define CYBER_BACKGROUND RGB(10, 10, 25)        // Deep space black
#define CYBER_NEON_GREEN RGB(0, 255, 65)        // Matrix green
#define CYBER_NEON_BLUE RGB(0, 191, 255)        // Electric blue
#define CYBER_NEON_PINK RGB(255, 20, 147)       // Hot pink
#define CYBER_NEON_ORANGE RGB(255, 165, 0)      // Neon orange
#define CYBER_GRID_COLOR RGB(0, 100, 100)       // Dark cyan grid
#define CYBER_TEXT_PRIMARY RGB(0, 255, 65)      // Primary text
#define CYBER_TEXT_SECONDARY RGB(100, 200, 255) // Secondary text
#define CYBER_BORDER_GLOW RGB(0, 255, 255)      // Cyan glow

// Window class name
#define LACKYVPN_WINDOW_CLASS L"LackyVPNCyberInterface"
#define LACKYVPN_WINDOW_TITLE L"LACKYVPN - OPERATOR TERMINAL v1.0 [CYBERNIGHT]"

// Control IDs
#define ID_CONNECT_BTN      1001
#define ID_DISCONNECT_BTN   1002
#define ID_SETTINGS_BTN     1003
#define ID_DISTRESS_BTN     1004
#define ID_STATUS_LIST      1005
#define ID_SERVER_COMBO     1006
#define ID_MODE_COMBO       1007
#define ID_ENCRYPTION_COMBO 1008

// Template for COM interface release
template<class Interface>
inline void SafeRelease(Interface **ppInterfaceToRelease) {
    if (*ppInterfaceToRelease != NULL) {
        (*ppInterfaceToRelease)->Release();
        (*ppInterfaceToRelease) = NULL;
    }
}

// ========== MAIN INTERFACE CLASS ==========
class CyberInterface {
private:
    // Window handles
    HWND m_hWnd;
    HWND m_hConnectBtn;
    HWND m_hDisconnectBtn;
    HWND m_hSettingsBtn;
    HWND m_hDistressBtn;
    HWND m_hStatusList;
    HWND m_hEncryptionCombo;
    HWND m_hLocationCombo;
    
    // Direct2D resources
    ID2D1Factory* m_pD2DFactory;
    ID2D1HwndRenderTarget* m_pRenderTarget;
    ID2D1SolidColorBrush* m_pNeonGreenBrush;
    ID2D1SolidColorBrush* m_pNeonBlueBrush;
    ID2D1SolidColorBrush* m_pNeonPinkBrush;
    ID2D1SolidColorBrush* m_pNeonOrangeBrush;
    ID2D1SolidColorBrush* m_pBackgroundBrush;
    
    // DirectWrite resources
    IDWriteFactory* m_pWriteFactory;
    IDWriteTextFormat* m_pTextFormat;
    
    // LACKYVPN system integration
    lackyvpn_system_t* m_pSystem;
    distress_context_t* m_pDistress;
    system_monitor_t* m_pMonitor;
    
    // Status tracking
    bool m_connected;
    bool m_distressActive;
    
    // Animation state
    float m_animTime;
    std::vector<D2D1_POINT_2F> m_matrixDrops;

public:
    CyberInterface() :
        m_hWnd(nullptr),
        m_hConnectBtn(nullptr),
        m_hDisconnectBtn(nullptr),
        m_hSettingsBtn(nullptr),
        m_hDistressBtn(nullptr),
        m_hStatusList(nullptr),
        m_hEncryptionCombo(nullptr),
        m_hLocationCombo(nullptr),
        m_pD2DFactory(nullptr),
        m_pRenderTarget(nullptr),
        m_pNeonGreenBrush(nullptr),
        m_pNeonBlueBrush(nullptr),
        m_pNeonPinkBrush(nullptr),
        m_pNeonOrangeBrush(nullptr),
        m_pBackgroundBrush(nullptr),
        m_pWriteFactory(nullptr),
        m_pTextFormat(nullptr),
        m_pSystem(nullptr),
        m_pDistress(nullptr),
        m_pMonitor(nullptr),
        m_connected(false),
        m_distressActive(false),
        m_animTime(0.0f)
    {
        InitializeMatrixEffect();
    }

    ~CyberInterface() {
        Cleanup();
    }

    // Core methods
    bool Initialize(HINSTANCE hInstance);
    void Cleanup();
    void CreateControls();
    void InitializeLackyVPN();
    void UpdateConnectionStatus();
    void UpdateMetrics();
    void InitializeMatrixEffect();
    
    // UI event handlers
    LRESULT HandleMessage(UINT message, WPARAM wParam, LPARAM lParam);
    void OnPaint();
    void OnCommand(WPARAM wParam);
    void OnTimer(WPARAM timerId);
    
    // Drawing methods
    void DrawCyberGrid();
    void DrawNeonBorders();
    void DrawMatrixRain();
    void DrawStatusPanel();
    void AddStatusMessage(const wchar_t* message, COLORREF color = CYBER_NEON_GREEN);
    
    // VPN operations
    void ConnectVPN();
    void DisconnectVPN();
    void ShowSettings();
    void ActivateDistress();
    
    // Accessors
    HWND GetWindow() const { return m_hWnd; }
    bool IsDistressActive() const { return m_distressActive; }
};

// Global instance
static CyberInterface* g_pInterface = nullptr;

// ========== IMPLEMENTATION ==========

void CyberInterface::InitializeMatrixEffect() {
    // Initialize matrix rain effect
    for (int i = 0; i < 50; ++i) {
        D2D1_POINT_2F drop;
        drop.x = static_cast<float>(rand() % 800);
        drop.y = static_cast<float>(rand() % 600);
        m_matrixDrops.push_back(drop);
    }
}

bool CyberInterface::Initialize(HINSTANCE hInstance) {
    // Register window class
    WNDCLASSEXW wcex = {};
    wcex.cbSize = sizeof(WNDCLASSEXW);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = [](HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) -> LRESULT {
        if (message == WM_CREATE) {
            CREATESTRUCT* pcs = reinterpret_cast<CREATESTRUCT*>(lParam);
            CyberInterface* pInterface = reinterpret_cast<CyberInterface*>(pcs->lpCreateParams);
            SetWindowLongPtrW(hWnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pInterface));
            pInterface->m_hWnd = hWnd;
            return 0;
        }
        
        CyberInterface* pInterface = reinterpret_cast<CyberInterface*>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));
        if (pInterface) {
            return pInterface->HandleMessage(message, wParam, lParam);
        }
        
        return DefWindowProcW(hWnd, message, wParam, lParam);
    };
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_APPLICATION));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = CreateSolidBrush(CYBER_BACKGROUND);
    wcex.lpszMenuName = nullptr;
    wcex.lpszClassName = LACKYVPN_WINDOW_CLASS;
    wcex.hIconSm = LoadIconW(hInstance, MAKEINTRESOURCEW(IDI_APPLICATION));

    if (!RegisterClassExW(&wcex)) {
        return false;
    }

    // Create window
    m_hWnd = CreateWindowExW(
        WS_EX_APPWINDOW,
        LACKYVPN_WINDOW_CLASS,
        LACKYVPN_WINDOW_TITLE,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        1200, 800,
        nullptr,
        nullptr,
        hInstance,
        this);

    if (!m_hWnd) {
        return false;
    }

    // Initialize Direct2D
    HRESULT hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &m_pD2DFactory);
    if (FAILED(hr)) return false;

    // Initialize DirectWrite  
    hr = DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(m_pWriteFactory),
                            reinterpret_cast<IUnknown**>(&m_pWriteFactory));
    if (FAILED(hr)) return false;

    // Create render target
    RECT rc;
    GetClientRect(m_hWnd, &rc);
    D2D1_SIZE_U size = D2D1::SizeU(rc.right, rc.bottom);

    hr = m_pD2DFactory->CreateHwndRenderTarget(
        D2D1::RenderTargetProperties(),
        D2D1::HwndRenderTargetProperties(m_hWnd, size),
        &m_pRenderTarget);
    if (FAILED(hr)) return false;

    // Create brushes
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 1.0f, 0.25f), &m_pNeonGreenBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.75f, 1.0f), &m_pNeonBlueBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.08f, 0.58f), &m_pNeonPinkBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.65f, 0.0f), &m_pNeonOrangeBrush);
    m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(0.04f, 0.04f, 0.1f), &m_pBackgroundBrush);

    // Create text format
    m_pWriteFactory->CreateTextFormat(
        L"Consolas",
        nullptr,
        DWRITE_FONT_WEIGHT_BOLD,
        DWRITE_FONT_STYLE_NORMAL,
        DWRITE_FONT_STRETCH_NORMAL,
        14.0f,
        L"",
        &m_pTextFormat);

    // Create controls and initialize systems
    CreateControls();
    InitializeLackyVPN();

    // Set up timers
    SetTimer(m_hWnd, 1, 50, nullptr);  // Animation timer

    return true;
}

void CyberInterface::CreateControls() {
    // Status list
    m_hStatusList = CreateWindowExW(
        WS_EX_CLIENTEDGE,
        L"LISTBOX",
        nullptr,
        WS_CHILD | WS_VISIBLE | WS_VSCROLL | LBS_OWNERDRAWFIXED,
        20, 100, 400, 300,
        m_hWnd, 
        reinterpret_cast<HMENU>(ID_STATUS_LIST),
        GetModuleHandleW(nullptr), 
        nullptr);

    // Connect button
    m_hConnectBtn = CreateWindowExW(
        0,
        L"BUTTON",
        L"🚀 ESTABLISH SECURE LINK",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        450, 120, 200, 40,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_CONNECT_BTN),
        GetModuleHandleW(nullptr),
        nullptr);

    // Disconnect button
    m_hDisconnectBtn = CreateWindowExW(
        0,
        L"BUTTON", 
        L"🔌 TERMINATE CONNECTION",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        680, 120, 200, 40,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_DISCONNECT_BTN),
        GetModuleHandleW(nullptr),
        nullptr);

    // Settings button
    m_hSettingsBtn = CreateWindowExW(
        0,
        L"BUTTON",
        L"⚙️ OPERATOR CONTROLS",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        450, 180, 200, 40,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_SETTINGS_BTN),
        GetModuleHandleW(nullptr),
        nullptr);

    // Distress button
    m_hDistressBtn = CreateWindowExW(
        0,
        L"BUTTON",
        L"🚨 DISTRESS PROTOCOL",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        680, 180, 200, 40,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_DISTRESS_BTN),
        GetModuleHandleW(nullptr),
        nullptr);

    // Encryption combo
    m_hEncryptionCombo = CreateWindowExW(
        0,
        L"COMBOBOX",
        nullptr,
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
        450, 240, 430, 100,
        m_hWnd,
        reinterpret_cast<HMENU>(ID_ENCRYPTION_COMBO),
        GetModuleHandleW(nullptr),
        nullptr);

    // Populate encryption options
    SendMessageW(m_hEncryptionCombo, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"🔐 10-LAYER QUANTUM ENCRYPTION"));
    SendMessageW(m_hEncryptionCombo, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"🔥 FIRE SEAL PROTOCOL"));
    SendMessageW(m_hEncryptionCombo, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"⚛️ POST-QUANTUM SAFE"));
    SendMessageW(m_hEncryptionCombo, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"🌊 METAMORPHIC CIPHER"));
    SendMessageW(m_hEncryptionCombo, CB_SETCURSEL, 0, 0);

    // Apply cyber theme font
    HFONT hFont = CreateFontW(
        16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        ANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");

    SendMessageW(m_hStatusList, WM_SETFONT, reinterpret_cast<WPARAM>(hFont), TRUE);
    SendMessageW(m_hConnectBtn, WM_SETFONT, reinterpret_cast<WPARAM>(hFont), TRUE);
    SendMessageW(m_hDisconnectBtn, WM_SETFONT, reinterpret_cast<WPARAM>(hFont), TRUE);
    SendMessageW(m_hSettingsBtn, WM_SETFONT, reinterpret_cast<WPARAM>(hFont), TRUE);
    SendMessageW(m_hDistressBtn, WM_SETFONT, reinterpret_cast<WPARAM>(hFont), TRUE);
    SendMessageW(m_hEncryptionCombo, WM_SETFONT, reinterpret_cast<WPARAM>(hFont), TRUE);
}

void CyberInterface::InitializeLackyVPN() {
    // Initialize core LACKYVPN system
    m_pSystem = static_cast<lackyvpn_system_t*>(malloc(sizeof(lackyvpn_system_t)));
    if (m_pSystem) {
        lackyvpn_config_t config;
        memset(&config, 0, sizeof(config));
        config.default_mode = LACKYVPN_MODE_NORMAL;
        config.encryption_layers = 10;
        config.enable_quantum_crypto = true;
        config.enable_steganography = true;
        config.enable_anti_forensics = true;

        if (lackyvpn_initialize(m_pSystem, &config) == LACKYVPN_SUCCESS) {
            AddStatusMessage(L"🔥 LACKYVPN CORE INITIALIZED", CYBER_NEON_GREEN);
            AddStatusMessage(L"📡 QUANTUM ENCRYPTION ACTIVE", CYBER_NEON_BLUE);
            AddStatusMessage(L"🛡️ FIRE SEAL PROTOCOL LOADED", CYBER_NEON_PINK);
        } else {
            AddStatusMessage(L"❌ CORE INITIALIZATION FAILED", RGB(255, 0, 0));
        }
    }    // Initialize monitoring system
    m_pMonitor = static_cast<system_monitor_t*>(malloc(sizeof(system_monitor_t)));
    if (m_pMonitor) {
        if (init_system_monitor(m_pMonitor)) {
            AddStatusMessage(L"🕵️ THREAT MONITORING ONLINE", CYBER_NEON_GREEN);
            start_monitoring(m_pMonitor);
        }
    }

    // Initialize distress mode
    m_pDistress = static_cast<distress_context_t*>(malloc(sizeof(distress_context_t)));
    if (m_pDistress) {
        distress_config_t distress_config;
        memset(&distress_config, 0, sizeof(distress_config));
        distress_config.trigger_mask = static_cast<distress_trigger_t>(DISTRESS_TRIGGER_PANIC_KEY | DISTRESS_TRIGGER_FORENSIC_TOOL);
        distress_config.response_level = DISTRESS_LEVEL_STEALTH;

        if (distress_initialize(m_pDistress, &distress_config)) {
            AddStatusMessage(L"🚨 DISTRESS PROTOCOLS ARMED", CYBER_NEON_ORANGE);
        }
    }

    AddStatusMessage(L"🌐 LACKYVPN OPERATOR TERMINAL READY", CYBER_NEON_GREEN);
}

LRESULT CyberInterface::HandleMessage(UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_PAINT:
            OnPaint();
            return 0;

        case WM_COMMAND:
            OnCommand(wParam);
            return 0;

        case WM_TIMER:
            OnTimer(wParam);
            return 0;

        case WM_SIZE:
            if (m_pRenderTarget) {
                RECT rc;
                GetClientRect(m_hWnd, &rc);
                D2D1_SIZE_U size = D2D1::SizeU(rc.right, rc.bottom);
                m_pRenderTarget->Resize(size);
            }
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;

        default:
            return DefWindowProcW(m_hWnd, message, wParam, lParam);
    }
}

void CyberInterface::OnPaint() {
    PAINTSTRUCT ps;
    BeginPaint(m_hWnd, &ps);

    if (m_pRenderTarget) {
        m_pRenderTarget->BeginDraw();

        // Clear background
        m_pRenderTarget->Clear(D2D1::ColorF(0.04f, 0.04f, 0.1f));

        // Draw cyber grid
        DrawCyberGrid();

        // Draw neon borders
        DrawNeonBorders();

        // Draw matrix rain
        DrawMatrixRain();

        // Draw status panel
        DrawStatusPanel();

        HRESULT hr = m_pRenderTarget->EndDraw();
        if (hr == D2DERR_RECREATE_TARGET) {
            SafeRelease(&m_pRenderTarget);
        }
    }

    EndPaint(m_hWnd, &ps);
}

void CyberInterface::DrawCyberGrid() {
    if (!m_pRenderTarget) return;

    RECT rect;
    GetClientRect(m_hWnd, &rect);
    float width = static_cast<float>(rect.right);
    float height = static_cast<float>(rect.bottom);

    ID2D1SolidColorBrush* gridBrush = nullptr;
    m_pRenderTarget->CreateSolidColorBrush(
        D2D1::ColorF(0.0f, 0.4f, 0.4f, 0.2f), &gridBrush);

    if (gridBrush) {
        // Draw vertical lines
        for (float x = 0; x < width; x += 40) {
            m_pRenderTarget->DrawLine(
                D2D1::Point2F(x, 0),
                D2D1::Point2F(x, height),
                gridBrush);
        }

        // Draw horizontal lines
        for (float y = 0; y < height; y += 40) {
            m_pRenderTarget->DrawLine(
                D2D1::Point2F(0, y),
                D2D1::Point2F(width, y),
                gridBrush);
        }

        SafeRelease(&gridBrush);
    }
}

void CyberInterface::DrawNeonBorders() {
    if (!m_pRenderTarget || !m_pNeonGreenBrush) return;

    RECT rect;
    GetClientRect(m_hWnd, &rect);
    
    D2D1_RECT_F borderRect = D2D1::RectF(
        5.0f, 5.0f, 
        static_cast<float>(rect.right - 5), 
        static_cast<float>(rect.bottom - 5));

    m_pRenderTarget->DrawRectangle(borderRect, m_pNeonGreenBrush, 2.0f);
}

void CyberInterface::DrawMatrixRain() {
    if (!m_pRenderTarget || !m_pNeonGreenBrush || !m_pTextFormat) return;

    static const wchar_t chars[] = L"0123456789ABCDEF";
    static float positions[20];
    static bool initialized = false;

    if (!initialized) {
        for (int i = 0; i < 20; ++i) {
            positions[i] = static_cast<float>(rand() % 600);
        }
        initialized = true;
    }

    for (int i = 0; i < 20; ++i) {
        positions[i] += 2.0f;
        if (positions[i] > 600) {
            positions[i] = 0;
        }

        wchar_t ch = chars[rand() % (sizeof(chars) / sizeof(wchar_t) - 1)];
        D2D1_RECT_F rect = D2D1::RectF(
            950.0f + i * 15.0f, positions[i],
            965.0f + i * 15.0f, positions[i] + 20.0f);

        m_pRenderTarget->DrawText(&ch, 1, m_pTextFormat, rect, m_pNeonGreenBrush);
    }
}

void CyberInterface::DrawStatusPanel() {
    if (!m_pRenderTarget || !m_pTextFormat) return;

    // Title
    D2D1_RECT_F titleRect = D2D1::RectF(20, 20, 800, 50);    m_pRenderTarget->DrawText(
        L"🌐 LACKYVPN - OPERATOR TERMINAL v1.0 [CYBERNIGHT]",
        wcslen(L"🌐 LACKYVPN - OPERATOR TERMINAL v1.0 [CYBERNIGHT]"),
        m_pTextFormat, titleRect, m_pNeonGreenBrush);

    // Status
    const wchar_t* status = m_connected ? L"🔗 CONNECTED - SECURE TUNNEL ACTIVE" : L"🔌 DISCONNECTED - STANDBY MODE";
    ID2D1SolidColorBrush* statusBrush = m_connected ? m_pNeonGreenBrush : m_pNeonPinkBrush;
    
    D2D1_RECT_F statusRect = D2D1::RectF(20, 60, 600, 80);
    m_pRenderTarget->DrawText(status, wcslen(status), m_pTextFormat, statusRect, statusBrush);

    // Distress indicator
    if (m_distressActive) {
        D2D1_RECT_F distressRect = D2D1::RectF(20, 420, 400, 440);        m_pRenderTarget->DrawText(
            L"🚨 DISTRESS MODE ACTIVE - UI CAMOUFLAGE ENGAGED",
            wcslen(L"🚨 DISTRESS MODE ACTIVE - UI CAMOUFLAGE ENGAGED"),
            m_pTextFormat, distressRect, m_pNeonPinkBrush);
    }
}

void CyberInterface::OnCommand(WPARAM wParam) {
    WORD id = LOWORD(wParam);

    switch (id) {
        case ID_CONNECT_BTN:
            ConnectVPN();
            break;

        case ID_DISCONNECT_BTN:
            DisconnectVPN();
            break;

        case ID_SETTINGS_BTN:
            ShowSettings();
            break;

        case ID_DISTRESS_BTN:
            ActivateDistress();
            break;
    }
}

void CyberInterface::OnTimer(WPARAM timerId) {
    if (timerId == 1) {
        m_animTime += 0.05f;
        InvalidateRect(m_hWnd, nullptr, FALSE);
    }
}

void CyberInterface::ConnectVPN() {
    if (m_connected) return;

    AddStatusMessage(L"🚀 INITIATING VPN CONNECTION...", CYBER_NEON_BLUE);
    
    if (m_pSystem) {        bool result = lackyvpn_establish_tunnel(m_pSystem, "auto", 443, "operator");
        if (result) {
            m_connected = true;
            AddStatusMessage(L"🔗 CONNECTION ESTABLISHED", CYBER_NEON_GREEN);
            AddStatusMessage(L"🔥 FIRE SEAL PROTOCOL ACTIVE", CYBER_NEON_GREEN);
            AddStatusMessage(L"⚡ QUANTUM ENCRYPTION ONLINE", CYBER_NEON_BLUE);
        } else {
            AddStatusMessage(L"❌ CONNECTION FAILED", RGB(255, 0, 0));
        }
    }
    
    InvalidateRect(m_hWnd, nullptr, FALSE);
}

void CyberInterface::DisconnectVPN() {
    if (!m_connected) return;

    AddStatusMessage(L"🔌 TERMINATING VPN CONNECTION...", CYBER_NEON_ORANGE);    if (m_pSystem) {
        // Terminate primary tunnel (assuming tunnel ID 0 for main connection)
        if (lackyvpn_terminate_tunnel(m_pSystem, 0)) {
            m_connected = false;
            AddStatusMessage(L"🔌 CONNECTION TERMINATED", CYBER_NEON_ORANGE);
            AddStatusMessage(L"🛡️ SECURE SHUTDOWN COMPLETE", CYBER_NEON_GREEN);
        } else {
            AddStatusMessage(L"❌ DISCONNECTION FAILED", RGB(255, 0, 0));
        }
    }
    
    InvalidateRect(m_hWnd, nullptr, FALSE);
}

void CyberInterface::ShowSettings() {
    AddStatusMessage(L"⚙️ OPENING OPERATOR CONTROLS...", CYBER_NEON_BLUE);
    
    MessageBoxW(m_hWnd,
        L"LACKYVPN Operator Settings\n\n"
        L"🔐 Encryption: 10-Layer Fire Seal\n"
        L"👻 Ghost Mode: ACTIVE\n"
        L"⚡ Quantum Protocols: ENABLED\n"
        L"🛡️ Anti-Forensics: ENABLED\n"
        L"🚨 Distress Mode: ARMED\n\n"
        L"All systems operating at maximum security.",
        L"Operator Controls - CLASSIFIED",
        MB_OK | MB_ICONINFORMATION);
}

void CyberInterface::ActivateDistress() {
    int result = MessageBoxW(m_hWnd,
        L"⚠️ WARNING: DISTRESS PROTOCOL ACTIVATION ⚠️\n\n"
        L"This will:\n"
        L"• Activate emergency UI camouflage\n"
        L"• Begin evidence destruction protocols\n"
        L"• Enable maximum stealth mode\n"
        L"• Trigger emergency procedures\n\n"
        L"Are you sure you want to proceed?",
        L"🚨 DISTRESS PROTOCOL - AUTHORIZATION REQUIRED",
        MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2);

    if (result == IDYES) {
        m_distressActive = true;
        AddStatusMessage(L"🚨 DISTRESS PROTOCOL ACTIVATED", RGB(255, 0, 0));
        AddStatusMessage(L"🎭 UI CAMOUFLAGE ENGAGED", CYBER_NEON_ORANGE);
        AddStatusMessage(L"🔥 EVIDENCE DESTRUCTION INITIATED", CYBER_NEON_PINK);

        if (m_pDistress) {
            distress_activate(m_pDistress, DISTRESS_LEVEL_STEALTH, DISTRESS_TRIGGER_MANUAL);
        }

        InvalidateRect(m_hWnd, nullptr, FALSE);
    }
}

void CyberInterface::AddStatusMessage(const wchar_t* message, COLORREF color) {
    if (!m_hStatusList) return;

    // Add timestamp
    SYSTEMTIME st;
    GetLocalTime(&st);

    wchar_t timestampedMessage[512];
    swprintf_s(timestampedMessage, L"[%02d:%02d:%02d] %s",
        st.wHour, st.wMinute, st.wSecond, message);

    int index = static_cast<int>(SendMessageW(m_hStatusList, LB_ADDSTRING, 0, 
        reinterpret_cast<LPARAM>(timestampedMessage)));
    SendMessageW(m_hStatusList, LB_SETTOPINDEX, index, 0);
}

void CyberInterface::Cleanup() {
    // Release Direct2D resources
    SafeRelease(&m_pNeonGreenBrush);
    SafeRelease(&m_pNeonBlueBrush);
    SafeRelease(&m_pNeonPinkBrush);
    SafeRelease(&m_pNeonOrangeBrush);
    SafeRelease(&m_pBackgroundBrush);
    SafeRelease(&m_pTextFormat);
    SafeRelease(&m_pWriteFactory);
    SafeRelease(&m_pRenderTarget);
    SafeRelease(&m_pD2DFactory);    // Cleanup LACKYVPN systems
    if (m_pSystem) {
        lackyvpn_stop(m_pSystem);
        lackyvpn_cleanup(m_pSystem);
        free(m_pSystem);
        m_pSystem = nullptr;
    }

    if (m_pMonitor) {
        destroy_system_monitor(m_pMonitor);
        free(m_pMonitor);
        m_pMonitor = nullptr;
    }

    if (m_pDistress) {
        distress_cleanup(m_pDistress);
        free(m_pDistress);
        m_pDistress = nullptr;
    }
}

// ========== ENTRY POINT ==========

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(pCmdLine);

    // Initialize COM
    HRESULT hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    if (FAILED(hr)) return -1;

    // Initialize common controls
    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(icex);
    icex.dwICC = ICC_WIN95_CLASSES;
    InitCommonControlsEx(&icex);

    // Create and initialize interface
    CyberInterface interface;
    g_pInterface = &interface;

    if (!interface.Initialize(hInstance)) {
        CoUninitialize();
        return -1;
    }

    // Show window
    ShowWindow(interface.GetWindow(), nCmdShow);
    UpdateWindow(interface.GetWindow());

    // Message loop
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    CoUninitialize();
    return static_cast<int>(msg.wParam);
}
